"""
MPD Hydraulics Simulator — desktop application.

Run:
    .venv/bin/python gui.py

Requires PySide6 (see requirements.txt). The command-line tool (main.py)
and the simulation engine (mpd_sim/) do not depend on the GUI.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from gui.app import main  # noqa: E402

if __name__ == "__main__":
    sys.exit(main())
