"""
Plotting utilities (Matplotlib, non-interactive "Agg" backend).

Plots are reported in practical field-friendly units (bar, ppg, gpm) for
readability; the data files keep SI columns. Every figure states its data
status in the footer (synthetic demonstration vs. validation data).

Style: one y-axis per panel (multi-quantity figures use stacked panels that
share the time axis), thin lines, recessive grid, colour-blind-checked
categorical palette.
"""

from __future__ import annotations

from pathlib import Path
from typing import Dict, Optional

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

from ..constants import GRAVITY  # noqa: E402
from ..units import BAR_TO_PA, GPM_TO_M3S, PPG_TO_KGM3  # noqa: E402

#: Categorical palette (fixed order; validated for colour-vision deficiency).
COLORS = {"s1": "#2a78d6", "s2": "#eb6834", "s3": "#1baf7a", "s4": "#eda100",
          "s5": "#4a3aa7", "limit": "#52514e", "unsafe": "#e34948",
          "text": "#0b0b0b", "grid": "#d9d8d4"}

DEFAULT_FOOTER = "Synthetic demonstration data — not field or experimental validation."


def _style(ax) -> None:
    ax.grid(True, color=COLORS["grid"], linewidth=0.6)
    for side in ("top", "right"):
        ax.spines[side].set_visible(False)
    ax.tick_params(colors=COLORS["text"], labelsize=9)


def _finish(fig, path: Path, footer: Optional[str] = DEFAULT_FOOTER) -> Path:
    if footer:
        fig.text(0.01, 0.005, footer, fontsize=7.5, color=COLORS["limit"])
    fig.tight_layout(rect=(0, 0.02, 1, 1))
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path, dpi=140)
    plt.close(fig)
    return path


def _shade_unsafe(ax, ts: pd.DataFrame) -> None:
    unsafe = (ts["window_status"] != "safe").to_numpy()
    if not unsafe.any():
        return
    t = ts["time_s"].to_numpy()
    ax.fill_between(t, 0, 1, where=unsafe, transform=ax.get_xaxis_transform(),
                    color=COLORS["unsafe"], alpha=0.12, linewidth=0,
                    label="outside pressure window")


def _limit_lines(ax, ts: pd.DataFrame, scale: float = BAR_TO_PA) -> None:
    pore = ts["pore_pressure_pa"].iloc[0] / scale
    frac = ts["fracture_pressure_pa"].iloc[0] / scale
    ax.axhline(pore, color=COLORS["limit"], linestyle="--", linewidth=1.0)
    ax.axhline(frac, color=COLORS["limit"], linestyle=":", linewidth=1.2)
    x = ts["time_s"].iloc[-1]
    ax.annotate("pore pressure", (x, pore), xytext=(-4, 3), textcoords="offset points",
                ha="right", fontsize=8, color=COLORS["limit"])
    ax.annotate("fracture pressure", (x, frac), xytext=(-4, -11), textcoords="offset points",
                ha="right", fontsize=8, color=COLORS["limit"])


# ---------------------------------------------------------------------------
# Steady state
# ---------------------------------------------------------------------------
def plot_pressure_profile(result, path: Path, window=None,
                          footer: Optional[str] = DEFAULT_FOOTER) -> Path:
    """Pressure vs MD and pressure vs TVD (string and annulus), side by side."""
    fig, axes = plt.subplots(1, 2, figsize=(11, 6.5), sharex=True)
    for ax, depth, label in ((axes[0], "md_m", "Measured depth, MD [m]"),
                             (axes[1], "tvd_m", "True vertical depth, TVD [m]")):
        for prof, color, name in ((result.string_profile, COLORS["s1"], "Drill string (inside)"),
                                  (result.annulus_profile, COLORS["s2"], "Annulus")):
            ax.plot(prof["pressure_pa"] / BAR_TO_PA, prof[depth], color=color,
                    linewidth=1.8, label=name)
        hydro = result.annulus_profile
        ax.plot(hydro["hydrostatic_contribution_pa"] / BAR_TO_PA, hydro[depth],
                color=COLORS["limit"], linewidth=1.0, linestyle="-.", label="Hydrostatic only")
        if window is not None:
            td_depth = hydro[depth].iloc[-1]
            ax.plot([window.pore_pressure / BAR_TO_PA], [td_depth], marker="<",
                    markersize=9, color=COLORS["s5"], linestyle="none", label="Pore pressure @ TD")
            ax.plot([window.fracture_pressure / BAR_TO_PA], [td_depth], marker=">",
                    markersize=9, color=COLORS["unsafe"], linestyle="none",
                    label="Fracture pressure @ TD")
        ax.invert_yaxis()
        ax.set_ylabel(label)
        ax.set_xlabel("Pressure [bar g]")
        _style(ax)
    axes[0].set_title("Pressure vs MD (flow-path length)", fontsize=10)
    axes[1].set_title("Pressure vs TVD (hydrostatic depth)", fontsize=10)
    axes[0].legend(fontsize=8, loc="lower left", frameon=True, framealpha=0.85, edgecolor="none")
    fig.suptitle(f"Steady-state pressure profile — Q = {result.conditions.pump_rate / GPM_TO_M3S:.0f} gpm, "
                 f"SBP = {result.surface_back_pressure / BAR_TO_PA:.1f} bar", fontsize=11)
    return _finish(fig, path, footer)


def plot_pressure_breakdown(result, path: Path,
                            footer: Optional[str] = DEFAULT_FOOTER) -> Path:
    """Horizontal bars of the SPP components (transparent pressure accounting)."""
    items = [("Drill pipe friction", result.losses.drill_pipe),
             ("BHA friction", result.losses.bha),
             ("Bit nozzles", result.losses.bit),
             ("Annulus friction", result.losses.annulus),
             ("Surface back pressure", result.surface_back_pressure)]
    labels = [i[0] for i in items]
    values = np.array([i[1] for i in items]) / BAR_TO_PA
    fig, ax = plt.subplots(figsize=(8, 3.8))
    ax.barh(labels, values, color=COLORS["s1"], height=0.55)
    for y, v in enumerate(values):
        ax.annotate(f"{v:.1f} bar", (v, y), xytext=(4, 0), textcoords="offset points",
                    va="center", fontsize=8.5, color=COLORS["text"])
    ax.invert_yaxis()
    ax.set_xlabel("Pressure [bar]")
    ax.set_title(f"SPP build-up: total SPP = {result.spp / BAR_TO_PA:.1f} bar", fontsize=10)
    ax.set_xlim(0, values.max() * 1.18)
    _style(ax)
    return _finish(fig, path, footer)


# ---------------------------------------------------------------------------
# Dynamic
# ---------------------------------------------------------------------------
def plot_bhp_vs_time(ts: pd.DataFrame, path: Path, title: str = "",
                     footer: Optional[str] = DEFAULT_FOOTER) -> Path:
    """BHP(t) with target and pressure-window limits; unsafe periods shaded."""
    fig, ax = plt.subplots(figsize=(10, 4.5))
    _shade_unsafe(ax, ts)
    t = ts["time_s"]
    ax.plot(t, ts["bhp_pa"] / BAR_TO_PA, color=COLORS["s1"], linewidth=1.8, label="BHP")
    ax.plot(t, ts["target_bhp_pa"] / BAR_TO_PA, color=COLORS["s2"], linewidth=1.2,
            linestyle="--", label="Target BHP")
    _limit_lines(ax, ts)
    ax.set_xlabel("Time [s]")
    ax.set_ylabel("Bottomhole pressure [bar g]")
    ax.set_title(title or "Bottomhole pressure", fontsize=10)
    ax.legend(fontsize=8, frameon=True, framealpha=0.85, edgecolor="none", loc="best")
    _style(ax)
    return _finish(fig, path, footer)


def plot_spp_vs_time(ts: pd.DataFrame, path: Path, title: str = "",
                     footer: Optional[str] = DEFAULT_FOOTER) -> Path:
    """Stand-pipe pressure vs time."""
    fig, ax = plt.subplots(figsize=(10, 4))
    ax.plot(ts["time_s"], ts["spp_pa"] / BAR_TO_PA, color=COLORS["s1"], linewidth=1.8)
    ax.set_xlabel("Time [s]")
    ax.set_ylabel("Stand-pipe pressure [bar g]")
    ax.set_title(title or "Stand-pipe pressure (SPP)", fontsize=10)
    _style(ax)
    return _finish(fig, path, footer)


def plot_ecd_vs_time(ts: pd.DataFrame, path: Path, mud_density: float,
                     td_tvd: float, title: str = "",
                     footer: Optional[str] = DEFAULT_FOOTER) -> Path:
    """ECD (conventional, excl. SBP) and BHP-equivalent mud weight (incl. SBP) in ppg."""
    fig, ax = plt.subplots(figsize=(10, 4.5))
    _shade_unsafe(ax, ts)
    t = ts["time_s"]
    ax.plot(t, ts["emw_bhp_kg_m3"] / PPG_TO_KGM3, color=COLORS["s1"], linewidth=1.8,
            label="EMW of BHP (incl. SBP) — MPD 'ECD'")
    ax.plot(t, ts["ecd_conventional_kg_m3"] / PPG_TO_KGM3, color=COLORS["s3"],
            linewidth=1.6, label="Conventional ECD (MW + annular friction)")
    ax.axhline(mud_density / PPG_TO_KGM3, color=COLORS["limit"], linewidth=1.0,
               linestyle="-.", label="Mud weight")
    _limit_lines(ax, ts, scale=GRAVITY * td_tvd * PPG_TO_KGM3)
    ax.set_xlabel("Time [s]")
    ax.set_ylabel("Equivalent density [ppg]")
    ax.set_title(title or "Equivalent circulating density at TD", fontsize=10)
    ax.legend(fontsize=8, frameon=True, framealpha=0.85, edgecolor="none", loc="best")
    _style(ax)
    return _finish(fig, path, footer)


def plot_pump_rate_vs_bhp(ts: pd.DataFrame, path: Path, title: str = "",
                          footer: Optional[str] = DEFAULT_FOOTER) -> Path:
    """Stacked panels: pump / back-pressure-pump rate, and BHP, on a shared time axis."""
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(10, 6), sharex=True)
    t = ts["time_s"]
    ax1.plot(t, ts["pump_rate_m3_s"] / GPM_TO_M3S, color=COLORS["s1"], linewidth=1.8,
             label="Rig pump rate")
    if ts["backpressure_pump_rate_m3_s"].abs().max() > 0:
        ax1.plot(t, ts["backpressure_pump_rate_m3_s"] / GPM_TO_M3S, color=COLORS["s2"],
                 linewidth=1.4, label="Back-pressure pump rate")
    ax1.plot(t, ts["q_bit_m3_s"] / GPM_TO_M3S, color=COLORS["s3"], linewidth=1.2,
             linestyle="--", label="Flow at bit")
    ax1.set_ylabel("Flow rate [gpm]")
    ax1.legend(fontsize=8, frameon=True, framealpha=0.85, edgecolor="none", loc="best")
    _style(ax1)
    _shade_unsafe(ax2, ts)
    ax2.plot(t, ts["bhp_pa"] / BAR_TO_PA, color=COLORS["s1"], linewidth=1.8, label="BHP")
    _limit_lines(ax2, ts)
    ax2.set_ylabel("BHP [bar g]")
    ax2.set_xlabel("Time [s]")
    _style(ax2)
    ax1.set_title(title or "Pump rate and BHP response", fontsize=10)
    return _finish(fig, path, footer)


def plot_choke_response(ts: pd.DataFrame, path: Path, actuation: str, title: str = "",
                        footer: Optional[str] = DEFAULT_FOOTER) -> Path:
    """Stacked panels: actuator position, SBP, and choke flow."""
    fig, axes = plt.subplots(3, 1, figsize=(10, 7.5), sharex=True)
    t = ts["time_s"]
    if actuation == "choke":
        axes[0].plot(t, ts["choke_opening"] * 100, color=COLORS["s1"], linewidth=1.8,
                     label="Applied opening")
        axes[0].plot(t, ts["actuator_command"] * 100, color=COLORS["s2"], linewidth=1.0,
                     linestyle="--", label="Command")
        axes[0].set_ylabel("Choke opening [%]")
    else:
        axes[0].plot(t, ts["sbp_command_pa"] / BAR_TO_PA, color=COLORS["s1"], linewidth=1.8,
                     label="Applied SBP set-point")
        axes[0].plot(t, ts["actuator_command"] / BAR_TO_PA, color=COLORS["s2"], linewidth=1.0,
                     linestyle="--", label="Command")
        axes[0].set_ylabel("SBP set-point [bar]")
    axes[0].legend(fontsize=8, frameon=True, framealpha=0.85, edgecolor="none", loc="best")
    axes[1].plot(t, ts["sbp_pa"] / BAR_TO_PA, color=COLORS["s1"], linewidth=1.8)
    axes[1].set_ylabel("Surface back pressure [bar g]")
    axes[2].plot(t, ts["q_choke_m3_s"] / GPM_TO_M3S, color=COLORS["s1"], linewidth=1.8)
    axes[2].set_ylabel("Choke flow [gpm]")
    axes[2].set_xlabel("Time [s]")
    for ax in axes:
        _style(ax)
    axes[0].set_title(title or "Choke / back-pressure response", fontsize=10)
    return _finish(fig, path, footer)


def plot_pid_response(ts: pd.DataFrame, path: Path, metrics: Dict[str, float],
                      title: str = "", footer: Optional[str] = DEFAULT_FOOTER) -> Path:
    """Stacked panels: BHP vs target, control error, PID terms."""
    fig, axes = plt.subplots(3, 1, figsize=(10, 8), sharex=True)
    t = ts["time_s"]
    _shade_unsafe(axes[0], ts)
    axes[0].plot(t, ts["bhp_pa"] / BAR_TO_PA, color=COLORS["s1"], linewidth=1.8, label="BHP")
    axes[0].plot(t, ts["target_bhp_pa"] / BAR_TO_PA, color=COLORS["s2"], linewidth=1.2,
                 linestyle="--", label="Target")
    _limit_lines(axes[0], ts)
    axes[0].set_ylabel("BHP [bar g]")
    axes[0].legend(fontsize=8, frameon=True, framealpha=0.85, edgecolor="none", loc="lower left")
    axes[1].plot(t, ts["control_error_pa"] / BAR_TO_PA, color=COLORS["s1"], linewidth=1.4)
    tol = metrics.get("settling_tolerance_pa", 0.0) / BAR_TO_PA
    axes[1].axhspan(-tol, tol, color=COLORS["s3"], alpha=0.12, linewidth=0,
                    label=f"±{tol:.2f} bar settling band")
    axes[1].set_ylabel("Error (target − BHP) [bar]")
    axes[1].legend(fontsize=8, frameon=True, framealpha=0.85, edgecolor="none", loc="best")
    for col, color, name in (("pid_p", COLORS["s1"], "P"), ("pid_i", COLORS["s2"], "I"),
                             ("pid_d", COLORS["s3"], "D")):
        axes[2].plot(t, ts[col], color=color, linewidth=1.3, label=name)
    axes[2].set_ylabel("PID term [output units]")
    axes[2].set_xlabel("Time [s]")
    axes[2].legend(fontsize=8, frameon=True, framealpha=0.85, edgecolor="none", ncol=3, loc="best")
    for ax in axes:
        _style(ax)
    summary = (f"settling {metrics.get('settling_time_s', np.nan):.0f} s · "
               f"max over {metrics.get('max_overshoot_pa', 0) / BAR_TO_PA:.2f} bar · "
               f"max under {metrics.get('max_undershoot_pa', 0) / BAR_TO_PA:.2f} bar · "
               f"outside window {metrics.get('time_outside_window_s', 0):.0f} s")
    axes[0].set_title((title or "Closed-loop PID BHP control") + "\n" + summary, fontsize=10)
    return _finish(fig, path, footer)


def plot_window_status(ts: pd.DataFrame, path: Path, title: str = "",
                       footer: Optional[str] = DEFAULT_FOOTER) -> Path:
    """Pressure-window status timeline (categorical strip with text labels)."""
    codes = {"kick_risk": -1, "safe": 0, "loss_risk": 1}
    y = ts["window_status"].map(codes).to_numpy()
    fig, ax = plt.subplots(figsize=(10, 2.6))
    ax.step(ts["time_s"], y, where="post", color=COLORS["s1"], linewidth=1.8)
    ax.set_yticks([-1, 0, 1])
    ax.set_yticklabels(["kick risk\n(BHP < pore)", "safe", "loss risk\n(BHP > frac)"])
    ax.set_ylim(-1.5, 1.5)
    ax.set_xlabel("Time [s]")
    ax.set_title(title or "Pressure-window status", fontsize=10)
    _style(ax)
    return _finish(fig, path, footer)


def plot_profiles_vs_time(profiles: pd.DataFrame, path: Path, title: str = "",
                          footer: Optional[str] = DEFAULT_FOOTER) -> Path:
    """Annulus pressure minus hydrostatic vs TVD at stored times (sequential colours)."""
    ann = profiles[profiles["flow_path"] == "annulus"]
    times = np.sort(ann["time_s"].unique())
    if times.size > 8:
        times = times[np.linspace(0, times.size - 1, 8).astype(int)]
    fig, ax = plt.subplots(figsize=(7, 6.5))
    cmap = plt.get_cmap("Blues")
    for k, t in enumerate(times):
        p = ann[ann["time_s"] == t]
        shade = 0.35 + 0.65 * k / max(len(times) - 1, 1)
        ax.plot((p["pressure_pa"] - p["hydrostatic_contribution_pa"]) / BAR_TO_PA,
                p["tvd_m"], color=cmap(shade), linewidth=1.5, label=f"t = {t:.0f} s")
    ax.invert_yaxis()
    ax.set_xlabel("Annulus pressure above hydrostatic (SBP + friction) [bar]")
    ax.set_ylabel("TVD [m]")
    ax.set_title(title or "Annulus pressure profile vs time", fontsize=10)
    ax.legend(fontsize=8, frameon=True, framealpha=0.85, edgecolor="none", loc="best")
    _style(ax)
    return _finish(fig, path, footer)


# ---------------------------------------------------------------------------
# Validation & sensitivity
# ---------------------------------------------------------------------------
def plot_parity(df: pd.DataFrame, path: Path, data_label: str, unit_label: str = "",
                footer: Optional[str] = None) -> Path:
    """Model vs reference parity plot with ±5 % / ±10 % bands."""
    fig, ax = plt.subplots(figsize=(6, 6))
    ref, mod = df["reference_value"].to_numpy(), df["model_value"].to_numpy()
    lo, hi = min(ref.min(), mod.min()) * 0.9, max(ref.max(), mod.max()) * 1.1
    xs = np.linspace(lo, hi, 10)
    ax.plot(xs, xs, color=COLORS["limit"], linewidth=1.0, label="1:1")
    for band, ls in ((0.05, "--"), (0.10, ":")):
        ax.plot(xs, xs * (1 + band), color=COLORS["limit"], linewidth=0.8, linestyle=ls,
                label=f"±{band:.0%}")
        ax.plot(xs, xs * (1 - band), color=COLORS["limit"], linewidth=0.8, linestyle=ls)
    for q, color in zip(df["quantity"].unique(), [COLORS["s1"], COLORS["s2"], COLORS["s3"],
                                                    COLORS["s4"], COLORS["s5"]]):
        sub = df[df["quantity"] == q]
        ax.plot(sub["reference_value"], sub["model_value"], marker="o", markersize=8,
                linestyle="none", color=color, markeredgecolor="white", label=q)
    ax.set_xlabel(f"Reference value {unit_label}")
    ax.set_ylabel(f"Model value {unit_label}")
    ax.set_title(f"Model vs reference — {data_label}", fontsize=10)
    ax.legend(fontsize=8, frameon=True, framealpha=0.85, edgecolor="none")
    _style(ax)
    return _finish(fig, path, footer or f"Reference data type: {data_label}")


def plot_series_comparison(time, reference, model, path: Path, data_label: str,
                           ylabel: str, footer: Optional[str] = None) -> Path:
    """Overlay of a model time series on a reference time series."""
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(10, 6), sharex=True)
    ax1.plot(time, reference, color=COLORS["s2"], linewidth=1.6, label="Reference")
    ax1.plot(time, model, color=COLORS["s1"], linewidth=1.4, linestyle="--", label="Model")
    ax1.set_ylabel(ylabel)
    ax1.legend(fontsize=8, frameon=True, framealpha=0.85, edgecolor="none")
    ax2.plot(time, np.asarray(model) - np.asarray(reference), color=COLORS["s1"], linewidth=1.2)
    ax2.set_ylabel("Model − reference")
    ax2.set_xlabel("Time [s]")
    for ax in (ax1, ax2):
        _style(ax)
    ax1.set_title(f"Dynamic comparison — {data_label}", fontsize=10)
    return _finish(fig, path, footer or f"Reference data type: {data_label}")


def plot_tornado(df: pd.DataFrame, output: str, path: Path, unit_scale: float,
                 unit_label: str, footer: Optional[str] = DEFAULT_FOOTER) -> Path:
    """Tornado chart of one output's change for −/+ perturbation of each parameter."""
    si_unit = "kg_m3" if output == "ecd" else "pa"
    sub = df.copy()
    sub["low"] = sub[f"{output}_low_change_{si_unit}"] / unit_scale
    sub["high"] = sub[f"{output}_high_change_{si_unit}"] / unit_scale
    sub["span"] = (sub["high"] - sub["low"]).abs()
    sub = sub.sort_values("span")
    fig, ax = plt.subplots(figsize=(8, 0.45 * len(sub) + 1.5))
    y = np.arange(len(sub))
    ax.barh(y, sub["low"], color=COLORS["s1"], height=0.6, label="parameter −Δ")
    ax.barh(y, sub["high"], color=COLORS["s2"], height=0.6, label="parameter +Δ")
    ax.set_yticks(y)
    ax.set_yticklabels(sub["parameter"])
    ax.axvline(0, color=COLORS["limit"], linewidth=0.8)
    ax.set_xlabel(f"Change in {output.upper()} [{unit_label}]")
    ax.set_title(f"One-at-a-time sensitivity of {output.upper()}", fontsize=10)
    ax.legend(fontsize=8, frameon=True, framealpha=0.85, edgecolor="none", loc="lower right")
    _style(ax)
    return _finish(fig, path, footer)


def plot_sweep(sweep: pd.DataFrame, parameter: str, path: Path, x_label: str,
               footer: Optional[str] = DEFAULT_FOOTER) -> Path:
    """BHP, SPP and ECD vs a swept parameter (stacked panels)."""
    fig, axes = plt.subplots(3, 1, figsize=(7, 8), sharex=True)
    x = sweep["value_display"]
    axes[0].plot(x, sweep["bhp_pa"] / BAR_TO_PA, color=COLORS["s1"], marker="o", markersize=4)
    axes[0].set_ylabel("BHP [bar g]")
    axes[1].plot(x, sweep["spp_pa"] / BAR_TO_PA, color=COLORS["s1"], marker="o", markersize=4)
    axes[1].set_ylabel("SPP [bar g]")
    axes[2].plot(x, sweep["ecd_kg_m3"] / PPG_TO_KGM3, color=COLORS["s1"], marker="o",
                 markersize=4)
    axes[2].set_ylabel("Conventional ECD [ppg]")
    axes[2].set_xlabel(x_label)
    for ax in axes:
        _style(ax)
    axes[0].set_title(f"Steady-state response to {parameter}", fontsize=10)
    return _finish(fig, path, footer)
