"""Matplotlib plotting of steady-state and dynamic results."""
