"""
Bit (nozzle) hydraulics — standard engineering equations (category B).

Equations (Bourgoyne et al. 1986, ADE §4.7):

    TFA      = Σ π d_n² / 4                         [m²]
    v_n      = Q / TFA                              [m/s]  (jet velocity)
    ΔP_bit   = ρ v_n² / (2 C_d²) = ρ Q² / (2 C_d² TFA²)   [Pa]
    HP_bit   = ΔP_bit × Q                           [W]
    F_jet    = ρ Q v_n                              [N]   (jet impact force)

Field equivalent: ΔP[psi] = 8.311e-5 ρ[ppg] q[gpm]² / (C_d² A[in²]²).

C_d is the nozzle discharge coefficient (ADE recommends 0.95; values up to
0.98 are reported). It is an INPUT — not hard-coded — and should be
calibrated against measured stand-pipe pressure.
Assumptions: incompressible flow, equal pressure drop across all nozzles,
no bit-face/junk-slot losses.
"""

from __future__ import annotations

from typing import Sequence

import numpy as np


def total_flow_area(nozzle_diameters: Sequence[float]) -> float:
    """
    Total flow area of the bit nozzles.

    Parameters
    ----------
    nozzle_diameters : sequence of float
        Nozzle diameters [m] (each > 0).

    Returns
    -------
    float
        TFA [m²].
    """
    d = np.asarray(nozzle_diameters, dtype=float)
    if d.size == 0 or np.any(d <= 0):
        raise ValueError("Bit needs at least one nozzle with diameter > 0.")
    return float(np.sum(np.pi * d ** 2 / 4.0))


def nozzle_velocity(flow_rate: float, tfa: float) -> float:
    """Jet velocity v_n = Q / TFA [m/s] (flow_rate [m³/s], tfa [m²])."""
    if tfa <= 0:
        raise ValueError("TFA must be > 0.")
    return flow_rate / tfa


def bit_pressure_drop(density: float, flow_rate: float, tfa: float,
                      discharge_coefficient: float):
    """
    Bit pressure drop ΔP = ρ Q|Q| / (2 C_d² TFA²) [Pa] (sign follows flow).

    Parameters
    ----------
    density : ρ [kg/m³]
    flow_rate : Q [m³/s] (float or array)
    tfa : total flow area [m²]
    discharge_coefficient : C_d [-], 0 < C_d <= 1
    """
    if not 0 < discharge_coefficient <= 1:
        raise ValueError("Discharge coefficient must be in (0, 1].")
    q = np.asarray(flow_rate, dtype=float)
    v_n = q / tfa
    dp = density * v_n * np.abs(v_n) / (2.0 * discharge_coefficient ** 2)
    return float(dp) if dp.ndim == 0 else dp


def bit_hydraulic_power(pressure_drop: float, flow_rate: float) -> float:
    """Hydraulic power expended at the bit, P = ΔP × Q [W]."""
    return pressure_drop * flow_rate


def jet_impact_force(density: float, flow_rate: float, tfa: float) -> float:
    """Jet impact force F = ρ Q v_n [N] (momentum flux of the jets)."""
    return density * flow_rate * nozzle_velocity(flow_rate, tfa)
