"""
Dimensionless groups and flow-regime criterion for Bingham plastics.

Equations
---------
Reynolds number (Bingham, based on plastic viscosity):
    Re = ρ |v| D / μ_p                                     (standard, B)

Hedstrom number:
    He = ρ τ_y D² / μ_p²                                   (Hedstrom 1952, C)

Critical Reynolds number — Hanks (1963) criterion (C):
    x_c / (1 − x_c)³ = He / 16800
    Re_c = He / (8 x_c) · (1 − 4/3 x_c + x_c⁴/3)
  where x_c = τ_y / τ_w at the laminar/turbulent transition.
  Limits: He → 0 gives Re_c → 2100 (Newtonian).

Source: Hanks, R.W. (1963) "The laminar-turbulent transition for fluids with
a yield stress", AIChE J. 9(3), 306-309; also Bourgoyne et al. (1986) ADE
Ch. 4 (Hedstrom-number chart). Developed for pipe flow; applying it to the
annulus with D = D_h is a MODELING CHOICE REQUIRING VALIDATION.
"""

from __future__ import annotations

import numpy as np

from ..constants import HANKS_CONSTANT, NEWTONIAN_CRITICAL_REYNOLDS

#: Bisection iterations for x_c (2^-80 resolution, far below needed accuracy).
_HANKS_BISECTION_STEPS = 80


def reynolds_number(density, velocity, diameter, plastic_viscosity):
    """
    Bingham Reynolds number Re = ρ|v|D/μ_p [-].

    Parameters
    ----------
    density : ρ [kg/m³]; velocity : v [m/s]; diameter : D or D_h [m];
    plastic_viscosity : μ_p [Pa·s] (> 0).
    """
    if np.any(np.asarray(plastic_viscosity) <= 0):
        raise ValueError("Plastic viscosity must be > 0 for Reynolds number.")
    return density * np.abs(velocity) * diameter / plastic_viscosity


def hedstrom_number(density, yield_stress, diameter, plastic_viscosity):
    """
    Hedstrom number He = ρ τ_y D² / μ_p² [-].

    Characterises the relative importance of yield stress; He = 0 for a
    Newtonian fluid.
    """
    if np.any(np.asarray(plastic_viscosity) <= 0):
        raise ValueError("Plastic viscosity must be > 0 for Hedstrom number.")
    return density * yield_stress * diameter ** 2 / plastic_viscosity ** 2


def hanks_critical_yield_ratio(hedstrom):
    """
    Solve x_c / (1 − x_c)³ = He/16800 for x_c ∈ [0, 1) (vectorised bisection).

    The left side increases monotonically from 0 to ∞ on [0, 1), so the
    root is unique.
    """
    he = np.atleast_1d(np.asarray(hedstrom, dtype=float))
    target = he / HANKS_CONSTANT
    lo = np.zeros_like(he)
    hi = np.ones_like(he)
    for _ in range(_HANKS_BISECTION_STEPS):
        mid = 0.5 * (lo + hi)
        value = mid / (1.0 - mid) ** 3
        too_big = value > target
        hi = np.where(too_big, mid, hi)
        lo = np.where(too_big, lo, mid)
    return 0.5 * (lo + hi)


def hanks_critical_reynolds(hedstrom):
    """
    Critical Reynolds number Re_c(He) from the Hanks (1963) criterion.

    Returns 2100 for He = 0 (Newtonian limit).
    """
    he = np.atleast_1d(np.asarray(hedstrom, dtype=float))
    xc = hanks_critical_yield_ratio(he)
    with np.errstate(divide="ignore", invalid="ignore"):
        re_c = he / (8.0 * xc) * (1.0 - 4.0 / 3.0 * xc + xc ** 4 / 3.0)
    re_c = np.where(he <= 0.0, NEWTONIAN_CRITICAL_REYNOLDS, re_c)
    # For tiny He, x_c ≈ He/16800 and the formula is numerically 0/0 → limit.
    return np.where(np.isfinite(re_c), re_c, NEWTONIAN_CRITICAL_REYNOLDS)
