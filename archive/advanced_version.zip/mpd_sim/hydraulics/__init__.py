"""Stage A — steady-state, segment-based well hydraulics."""
