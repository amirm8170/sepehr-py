"""
Hydrostatic pressure and related static-fluid calculations (category B).

Hydrostatic pressure is a function of TRUE VERTICAL depth only:

    ΔP_h = ρ g ΔTVD                    [Pa]

(Field form, for reporting only: P_h[psi] = 0.052 × MW[ppg] × TVD[ft] —
see ``units.field_hydrostatic_psi``.)
"""

from __future__ import annotations

import numpy as np

from ..constants import GRAVITY


def hydrostatic_pressure_increment(density, delta_tvd):
    """
    Hydrostatic pressure increment over a vertical interval.

    Equation:  ΔP = ρ g ΔTVD

    Parameters
    ----------
    density : float or array
        Fluid density ρ [kg/m³].
    delta_tvd : float or array
        True-vertical-depth increment ΔTVD [m] (positive downward).

    Returns
    -------
    float or array
        Hydrostatic pressure increment [Pa].

    Assumptions: incompressible, isothermal fluid column; g = 9.80665 m/s².
    """
    return np.asarray(density, dtype=float) * GRAVITY * np.asarray(delta_tvd, dtype=float)


def gel_breaking_pressure(gel_strength: float, length, hydraulic_diameter):
    """
    Pressure needed to break gelled mud and initiate circulation.

    Equation (force balance on a static gelled plug):
        ΔP_gel = 4 τ_g L / D_h          [Pa]
    (Bourgoyne et al. 1986, Eq. 4.62–4.63; field: τ_g L/(300 d).)

    Parameters
    ----------
    gel_strength : τ_g [Pa]
    length : segment lengths L [m]
    hydraulic_diameter : D (pipe) or D_hole − OD (annulus) [m]

    Returns
    -------
    float or array
        Pressure [Pa]. REPORTED ONLY (not injected into the dynamic model):
        gel-breaking transients are thixotropic and outside the Bingham model.
    """
    return 4.0 * gel_strength * np.asarray(length) / np.asarray(hydraulic_diameter)
