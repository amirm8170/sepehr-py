"""
Friction-factor and wall-shear-stress correlations for Bingham plastics.

All friction factors are FANNING friction factors f, defined by

    τ_w = f ρ v² / 2         and         dP/dL = 4 τ_w / D_h = 2 f ρ v² / D_h

(Darcy factor = 4 f). Velocities are magnitudes (|v|); the sign of the
pressure gradient is applied by the caller.

---------------------------------------------------------------------------
1. Laminar pipe flow — Buckingham–Reiner equation (exact)       [C]
---------------------------------------------------------------------------
    8 μ_p v / D = τ_w (1 − 4/3 ξ + 1/3 ξ⁴),    ξ = τ_y/τ_w ∈ [0,1)
  Equivalent friction-factor form:  f = 16/Re [1 + He/(6Re) − He⁴/(3 f³ Re⁷)]
  Source: Buckingham (1921); Reiner (1926); Bourgoyne et al. (1986) §4.
  Assumptions: steady, isothermal, fully developed, concentric circular pipe,
  no-slip walls, Bingham fluid. Valid for Re < Re_c (Hanks).

---------------------------------------------------------------------------
2. Laminar annular flow — Bingham narrow-slot approximation (exact slot) [C]
---------------------------------------------------------------------------
  The concentric annulus is represented by a slot of gap h = (D_hole−OD)/2,
  i.e. D_h = 2h:
    12 μ_p v / D_h = τ_w (1 − 3/2 ξ + 1/2 ξ³)
  Linearising (dropping ξ³) gives the familiar oilfield equation
    dP/dL = 48 μ_p v / D_h² + 6 τ_y / D_h
  (Bourgoyne et al. 1986, Eq. 4.67, field form μ_p v/(1000 d²) + τ_y/(200 d)).
  Validity: slot approximation good for OD/D_hole > ~0.3. Concentric only.
  MODELING CHOICE REQUIRING VALIDATION (vs. exact annular Bingham solution).

---------------------------------------------------------------------------
3. Turbulent flow — Blasius-type with plastic viscosity            [C]
---------------------------------------------------------------------------
    f = 0.0791 Re^-0.25 ,   Re = ρ v D / μ_p
  Annulus: D replaced by D_eff = 0.816 D_h (Bourgoyne et al. 1986, Eq. 4.73).
  Smooth pipe; best for 4000 < Re < 1e5. Ignores the yield-stress effect on
  turbulence (conservative/practical oilfield approach).

---------------------------------------------------------------------------
4. Turbulent flow — Darby, Mun & Boger (1992) Bingham correlation   [C]
---------------------------------------------------------------------------
    f_T = 10^a Re^-0.193 ,   a = −1.47 [1 + 0.146 exp(−2.9e-5 He)]
  Combined over all regimes:  f = (f_L^m + f_T^m)^(1/m),  m = 1.7 + 40000/Re
  Source: Darby, R., Mun, R., Boger, D.V. (1992) Chem. Eng. 99(9) 116-119;
  Darby, "Chemical Engineering Fluid Mechanics" (2001). Fitted for pipe flow
  of Bingham slurries, roughly 1e3 < He < 1e7 — NOT accurate for Newtonian
  (He → 0) fluids. Alternative model, MODELING CHOICE REQUIRING VALIDATION.
"""

from __future__ import annotations

import numpy as np

from ..constants import (BLASIUS_COEFFICIENT, BLASIUS_EXPONENT, DARBY_A0,
                         DARBY_A1, DARBY_A2, DARBY_BLEND_M0, DARBY_BLEND_M1,
                         DARBY_RE_EXPONENT, FRICTION_MAX_ITERATIONS,
                         FRICTION_TOLERANCE)

#: Geometry tags.
PIPE = "pipe"
ANNULUS = "annulus"

#: Laminar Bingham coefficients for  c μ v / D_h = τ_w P(ξ):
#:   pipe : c = 8,  P = 1 − 4/3 ξ + 1/3 ξ⁴
#:   slot : c = 12, P = 1 − 3/2 ξ + 1/2 ξ³
_LAMINAR_COEFF = {PIPE: 8.0, ANNULUS: 12.0}


def _laminar_profile_factor(xi, geometry: str):
    """Plug-flow correction P(ξ) of the laminar Bingham solution."""
    if geometry == PIPE:
        return 1.0 - 4.0 / 3.0 * xi + xi ** 4 / 3.0
    return 1.0 - 1.5 * xi + 0.5 * xi ** 3


def _laminar_profile_factor_derivative(xi, geometry: str):
    """dP/dξ, used by the Newton iteration."""
    if geometry == PIPE:
        return -4.0 / 3.0 + 4.0 / 3.0 * xi ** 3
    return -1.5 + 1.5 * xi ** 2


def laminar_bingham_wall_stress(velocity, hydraulic_diameter, plastic_viscosity,
                                yield_stress, geometry: str = PIPE):
    """
    Wall shear stress τ_w [Pa] for laminar Bingham flow (exact pipe or slot).

    Solves  g(τ_w) = τ_w P(τ_y/τ_w) − c μ_p |v| / D_h = 0  by Newton's method.

    g is increasing and convex for τ_w > τ_y, g(τ_y) < 0, and the linearised
    estimate τ_w0 = c μ v/D_h + k τ_y (k = 4/3 pipe, 3/2 slot) satisfies
    g(τ_w0) >= 0, so Newton from τ_w0 converges monotonically.

    Parameters
    ----------
    velocity : array [m/s]          mean velocity (magnitude is used)
    hydraulic_diameter : array [m]  D (pipe) or D_h = D_hole − OD (annulus)
    plastic_viscosity : float [Pa·s]
    yield_stress : float [Pa]
    geometry : "pipe" or "annulus"

    Returns
    -------
    np.ndarray
        Wall shear stress [Pa]; 0 where velocity is 0.
    """
    if geometry not in _LAMINAR_COEFF:
        raise ValueError(f"Unknown geometry '{geometry}'.")
    v = np.abs(np.asarray(velocity, dtype=float))
    d = np.asarray(hydraulic_diameter, dtype=float)
    c = _LAMINAR_COEFF[geometry]
    viscous = c * plastic_viscosity * v / d
    k_lin = 4.0 / 3.0 if geometry == PIPE else 1.5
    tau_w = viscous + k_lin * yield_stress
    if yield_stress > 0:
        for _ in range(FRICTION_MAX_ITERATIONS):
            xi = np.clip(yield_stress / np.maximum(tau_w, 1e-300), 0.0, 1.0)
            g = tau_w * _laminar_profile_factor(xi, geometry) - viscous
            # d/dτ_w [τ_w P(τ_y/τ_w)] = P(ξ) − ξ P'(ξ)
            dg = (_laminar_profile_factor(xi, geometry)
                  - xi * _laminar_profile_factor_derivative(xi, geometry))
            step = g / np.maximum(dg, 1e-300)
            tau_w = np.maximum(tau_w - step, yield_stress)
            if np.all(np.abs(step) <= FRICTION_TOLERANCE * np.maximum(tau_w, 1.0)):
                break
    return np.where(v > 0, tau_w, 0.0)


def fanning_from_wall_stress(wall_stress, density, velocity):
    """Fanning friction factor f = 2 τ_w / (ρ v²) [-] (NaN where v = 0)."""
    v = np.abs(np.asarray(velocity, dtype=float))
    with np.errstate(divide="ignore", invalid="ignore"):
        return np.where(v > 0, 2.0 * wall_stress / (density * v ** 2), np.nan)


def laminar_bingham_friction_factor(reynolds, hedstrom, geometry: str = PIPE):
    """
    Laminar Fanning friction factor in dimensionless form.

    Uses the identity τ_y/τ_w = 2 He /(f Re²) and the same exact
    Buckingham–Reiner (pipe) / slot (annulus) solution as
    :func:`laminar_bingham_wall_stress`, evaluated with unit reference
    values (ρ = μ = D = 1) so that f depends only on (Re, He).
    """
    re = np.asarray(reynolds, dtype=float)
    he = np.asarray(hedstrom, dtype=float)
    # With ρ = μ = D = 1: v = Re, τ_y = He.
    re_b, he_b = np.broadcast_arrays(re, he)
    tau_w = np.empty_like(re_b, dtype=float)
    for idx in np.ndindex(re_b.shape):
        tau_w[idx] = laminar_bingham_wall_stress(
            re_b[idx], 1.0, 1.0, float(he_b[idx]), geometry)
    return fanning_from_wall_stress(tau_w, 1.0, re_b)


def blasius_friction_factor(reynolds):
    """
    Smooth-pipe turbulent Fanning factor f = 0.0791 Re^-0.25 (Blasius 1913).

    Valid ≈ 4000 < Re < 1e5 (smooth pipe).
    """
    re = np.asarray(reynolds, dtype=float)
    with np.errstate(divide="ignore"):
        return np.where(re > 0, BLASIUS_COEFFICIENT * re ** (-BLASIUS_EXPONENT), np.nan)


def darby_turbulent_friction_factor(reynolds, hedstrom):
    """
    Darby–Mun–Boger (1992) turbulent Fanning factor for Bingham plastics.

        f_T = 10^a Re^-0.193,  a = −1.47 [1 + 0.146 exp(−2.9e-5 He)]
    """
    re = np.asarray(reynolds, dtype=float)
    he = np.asarray(hedstrom, dtype=float)
    a = DARBY_A0 * (1.0 + DARBY_A1 * np.exp(-DARBY_A2 * he))
    with np.errstate(divide="ignore"):
        return np.where(re > 0, 10.0 ** a * re ** (-DARBY_RE_EXPONENT), np.nan)


def darby_blended_friction_factor(f_laminar, f_turbulent, reynolds):
    """
    Darby et al. (1992) all-regime blending:

        f = (f_L^m + f_T^m)^(1/m),   m = 1.7 + 40000 / Re

    Computed as f_max (1 + (f_min/f_max)^m)^(1/m) to avoid overflow at
    large m (low Re).
    """
    re = np.asarray(reynolds, dtype=float)
    m = DARBY_BLEND_M0 + DARBY_BLEND_M1 / np.maximum(re, 1e-12)
    f_max = np.maximum(f_laminar, f_turbulent)
    f_min = np.minimum(f_laminar, f_turbulent)
    ratio = np.where(f_max > 0, f_min / f_max, 0.0)
    return f_max * (1.0 + ratio ** m) ** (1.0 / m)


def colebrook_smooth_fanning(reynolds, iterations: int = 50):
    """
    Colebrook (1939) smooth-pipe friction factor (Fanning), by fixed-point
    iteration of 1/√f_D = −2 log10(2.51/(Re √f_D)).

    Used as an INDEPENDENT reference in tests and as a Newtonian check.
    """
    re = np.asarray(reynolds, dtype=float)
    f_d = np.full_like(re, 0.02, dtype=float)
    for _ in range(iterations):
        f_d = (-2.0 * np.log10(2.51 / (re * np.sqrt(f_d)))) ** -2
    return f_d / 4.0
