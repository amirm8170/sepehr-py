"""
Rheology models (Strategy pattern).

The hydraulic solver never evaluates a constitutive equation directly; it asks
the pressure-loss model, which asks the rheology object. New rheologies are
added by subclassing :class:`RheologyModel` and registering them in
``RHEOLOGY_REGISTRY`` — the solver itself does not change.

Status
------
* BinghamPlastic  — fully implemented and used by the friction models
                    (initial model specified by the thesis proposal, category A).
* PowerLaw        — constitutive equation implemented; NO pressure-loss
                    correlation is wired yet (future extension, category F).
* HerschelBulkley — constitutive equation implemented; NO pressure-loss
                    correlation is wired yet (future extension, category F).

Units: shear stress τ [Pa], shear rate γ̇ [1/s], viscosities [Pa·s].
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Dict, Type

import numpy as np

from ..units import CP_TO_PAS, LBF100FT2_TO_PA

#: Fann VG-meter: rotor speed 300 rpm ↔ 511 s⁻¹, 600 rpm ↔ 1022 s⁻¹ (API RP 13B-1).
FANN_SHEAR_RATE_PER_RPM: float = 1.7023


class RheologyModel(ABC):
    """Abstract constitutive model τ = τ(γ̇) for a time-independent fluid."""

    name: str = "abstract"

    @abstractmethod
    def shear_stress(self, shear_rate):
        """Shear stress τ [Pa] at shear rate γ̇ [1/s] (γ̇ >= 0)."""

    def apparent_viscosity(self, shear_rate):
        """
        Apparent viscosity μ_a = τ / γ̇ [Pa·s].

        Defined for γ̇ > 0 only; infinite at γ̇ → 0 for yield-stress fluids.
        """
        g = np.asarray(shear_rate, dtype=float)
        if np.any(g <= 0):
            raise ValueError("Apparent viscosity requires shear rate > 0.")
        return self.shear_stress(g) / g

    @property
    def yield_stress_value(self) -> float:
        """Yield stress [Pa] (0 for fluids without a yield stress)."""
        return 0.0


@dataclass
class BinghamPlastic(RheologyModel):
    """
    Bingham Plastic model (thesis-proposal initial model).

    Equation (for γ̇ > 0):
        τ = τ_y + μ_p γ̇

    Attributes
    ----------
    plastic_viscosity : float
        μ_p [Pa·s]  (field PV [cP] × 1e-3)
    yield_stress : float
        τ_y [Pa]    (field YP [lbf/100 ft²] × 0.4788)

    Assumptions / validity
    ----------------------
    * Two-parameter idealisation of the drilling-fluid flow curve; fits
      the 300–600 rpm range well and usually OVER-predicts stress at low
      shear rates (annulus), which is why Herschel–Bulkley is a planned
      extension (API RP 13D recommends HB for modern hydraulics).
    * Time-independent (no thixotropy), isothermal.
    """

    plastic_viscosity: float
    yield_stress: float
    name: str = "bingham_plastic"

    def __post_init__(self) -> None:
        if self.plastic_viscosity < 0:
            raise ValueError("Plastic viscosity must be >= 0.")
        if self.yield_stress < 0:
            raise ValueError("Yield stress must be >= 0.")

    def shear_stress(self, shear_rate):
        g = np.asarray(shear_rate, dtype=float)
        if np.any(g < 0):
            raise ValueError("Shear rate must be >= 0.")
        return self.yield_stress + self.plastic_viscosity * g

    @property
    def yield_stress_value(self) -> float:
        return self.yield_stress

    @classmethod
    def from_fann(cls, theta_600: float, theta_300: float) -> "BinghamPlastic":
        """
        Bingham parameters from Fann 600/300 rpm dial readings (API RP 13B-1).

            PV [cP]           = θ600 − θ300
            YP [lbf/100 ft²]  = θ300 − PV

        Dial readings are in "degrees" ≈ lbf/100 ft² (the 1.0678 dial factor
        is conventionally ignored in the PV/YP definition).
        """
        if theta_600 < theta_300 or theta_300 < 0:
            raise ValueError("Fann readings must satisfy θ600 >= θ300 >= 0.")
        pv_cp = theta_600 - theta_300
        yp_field = theta_300 - pv_cp
        if yp_field < 0:
            raise ValueError("Readings give negative YP; Bingham model not appropriate.")
        return cls(plastic_viscosity=pv_cp * CP_TO_PAS,
                   yield_stress=yp_field * LBF100FT2_TO_PA)


@dataclass
class PowerLaw(RheologyModel):
    """
    Power-law (Ostwald–de Waele) model — FUTURE EXTENSION (category F).

        τ = K γ̇^n

    K : consistency index [Pa·sⁿ];  n : flow-behaviour index [-].
    Constitutive equation implemented; a matching friction model
    (e.g. Dodge & Metzner 1959 / API RP 13D) must be added in
    ``pressure_loss.py`` before it can be used by the solver.
    """

    consistency_index: float
    flow_behavior_index: float
    name: str = "power_law"

    def __post_init__(self) -> None:
        if self.consistency_index <= 0 or self.flow_behavior_index <= 0:
            raise ValueError("Power-law K and n must be > 0.")

    def shear_stress(self, shear_rate):
        g = np.asarray(shear_rate, dtype=float)
        if np.any(g < 0):
            raise ValueError("Shear rate must be >= 0.")
        return self.consistency_index * g ** self.flow_behavior_index


@dataclass
class HerschelBulkley(RheologyModel):
    """
    Herschel–Bulkley model — FUTURE EXTENSION (category F).

        τ = τ_y + K γ̇^n

    Reduces to Bingham for n = 1 (K = μ_p) and to power law for τ_y = 0.
    Constitutive equation implemented; friction model not yet wired.
    """

    yield_stress: float
    consistency_index: float
    flow_behavior_index: float
    name: str = "herschel_bulkley"

    def __post_init__(self) -> None:
        if self.yield_stress < 0:
            raise ValueError("Yield stress must be >= 0.")
        if self.consistency_index <= 0 or self.flow_behavior_index <= 0:
            raise ValueError("HB K and n must be > 0.")

    def shear_stress(self, shear_rate):
        g = np.asarray(shear_rate, dtype=float)
        if np.any(g < 0):
            raise ValueError("Shear rate must be >= 0.")
        return self.yield_stress + self.consistency_index * g ** self.flow_behavior_index

    @property
    def yield_stress_value(self) -> float:
        return self.yield_stress


RHEOLOGY_REGISTRY: Dict[str, Type[RheologyModel]] = {
    "bingham_plastic": BinghamPlastic,
    "power_law": PowerLaw,
    "herschel_bulkley": HerschelBulkley,
}


def build_rheology(name: str, **params) -> RheologyModel:
    """
    Factory: create a rheology model by name.

    For "bingham_plastic" the parameters are ``plastic_viscosity`` [Pa·s] and
    ``yield_stress`` [Pa]. Other models take their own keyword arguments.
    """
    key = name.lower()
    if key not in RHEOLOGY_REGISTRY:
        raise ValueError(f"Unknown rheology model '{name}'. "
                         f"Available: {sorted(RHEOLOGY_REGISTRY)}")
    return RHEOLOGY_REGISTRY[key](**params)
