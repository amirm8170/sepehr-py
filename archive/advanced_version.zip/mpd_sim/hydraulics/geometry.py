"""
Flow-geometry calculations (standard engineering equations, category B).

Diameter vocabulary used everywhere in the code:

* ``inner_diameter``  — pipe internal diameter, ID [m]  (flow inside string)
* ``outer_diameter``  — pipe outer diameter, OD [m]     (annulus inner wall)
* ``hole_diameter``   — wellbore / casing ID [m]        (annulus outer wall)
* ``hydraulic_diameter`` — D_h = 4A/P_wetted [m]
      pipe:                 D_h = ID
      concentric annulus:   D_h = D_hole − OD

All functions accept floats or NumPy arrays (vectorised).
"""

from __future__ import annotations

import numpy as np

ArrayLike = "float | np.ndarray"


def pipe_area(inner_diameter):
    """
    Internal flow area of a circular pipe.

    Equation:  A = π D² / 4

    Parameters
    ----------
    inner_diameter : float or array
        Pipe internal diameter D [m], must be > 0.

    Returns
    -------
    float or array
        Flow area [m²].
    """
    d = np.asarray(inner_diameter, dtype=float)
    if np.any(d <= 0):
        raise ValueError("Pipe inner diameter must be > 0.")
    return np.pi * d ** 2 / 4.0


def annulus_area(hole_diameter, pipe_outer_diameter):
    """
    Flow area of a concentric annulus.

    Equation:  A = π/4 (D_hole² − D_pipe,OD²)

    Parameters
    ----------
    hole_diameter : float or array
        Hole (or casing ID) diameter [m].
    pipe_outer_diameter : float or array
        Pipe outer diameter [m]; 0 means open hole without pipe.

    Returns
    -------
    float or array
        Annular flow area [m²].

    Raises
    ------
    ValueError
        If D_hole <= D_pipe (pipe would not fit in the hole).
    """
    dh = np.asarray(hole_diameter, dtype=float)
    dp = np.asarray(pipe_outer_diameter, dtype=float)
    if np.any(dh <= dp):
        raise ValueError("Hole diameter must be larger than pipe OD.")
    if np.any(dp < 0):
        raise ValueError("Pipe OD must be >= 0.")
    return np.pi / 4.0 * (dh ** 2 - dp ** 2)


def annulus_hydraulic_diameter(hole_diameter, pipe_outer_diameter):
    """
    Hydraulic diameter of a concentric annulus.

    Equation:  D_h = 4A / P_wetted = D_hole − D_pipe,OD

    Assumption: concentric pipe (no eccentricity correction).
    """
    dh = np.asarray(hole_diameter, dtype=float)
    dp = np.asarray(pipe_outer_diameter, dtype=float)
    if np.any(dh <= dp):
        raise ValueError("Hole diameter must be larger than pipe OD.")
    return dh - dp


def mean_velocity(flow_rate, area):
    """
    Cross-section-averaged velocity.

    Equation:  v = Q / A

    Parameters
    ----------
    flow_rate : float or array
        Volumetric flow rate Q [m³/s] (sign = direction).
    area : float or array
        Flow area A [m²], > 0.

    Returns
    -------
    float or array
        Mean velocity [m/s].
    """
    a = np.asarray(area, dtype=float)
    if np.any(a <= 0):
        raise ValueError("Flow area must be > 0.")
    return np.asarray(flow_rate, dtype=float) / a


def pipe_closed_end_area(outer_diameter):
    """Closed-end (displacement) area of a pipe, π OD²/4 [m²]."""
    return np.pi * np.asarray(outer_diameter, dtype=float) ** 2 / 4.0


def pipe_steel_area(outer_diameter, inner_diameter):
    """Steel (metal) cross-section of a pipe, π/4 (OD² − ID²) [m²]."""
    od = np.asarray(outer_diameter, dtype=float)
    idd = np.asarray(inner_diameter, dtype=float)
    if np.any(od <= idd):
        raise ValueError("Pipe OD must be larger than pipe ID.")
    return np.pi / 4.0 * (od ** 2 - idd ** 2)
