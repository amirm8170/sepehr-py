"""
Steady-state well hydraulics solver (Stage A).

Pressure reference and boundary conditions (EXPLICIT CONVENTION)
================================================================
* All pressures are GAUGE pressures [Pa] (atmosphere = 0).
* Circulation path: mud pump → (surface lines, neglected) → drill-string
  interior (drill pipe, BHA) → bit nozzles → annulus → wellhead → MPD choke
  → separator/atmosphere.
* Boundary condition: the annulus pressure at the wellhead, immediately
  upstream of the choke, equals the surface back pressure SBP. In
  "specified" mode SBP is an input; in "choke" mode
      SBP = P_0 + ΔP_choke(u, Q_choke),  Q_choke = Q_pump + Q_bpp + Q_disp.
* BHP reference point: annulus pressure at the well TD (bottom of hole).
  If the bit is off bottom the mud between bit and TD is static.

Definitions implemented
-----------------------
    P_h,TD          = ρ g TVD_TD                          hydrostatic at TD
    ΔP_ann          = Σ_annulus segments (dP/dL)_i L_i    annular friction
    BHP_static      = ρ g TVD_TD                          pumps off, SBP = 0
    BHP_static,SBP  = ρ g TVD_TD + SBP                    pumps off, SBP held
    BHP (circulating)= SBP + ρ g TVD_TD + ΔP_ann
    SPP             = SBP + ΔP_ann + ΔP_bit + ΔP_bha + ΔP_dp
                      + (ρ_ann − ρ_string) g TVD_bit  (= 0, single mud)
      (from walking the U-tube: pressure at the bit is identical approached
       from inside the string and from the annulus, hydrostatic columns
       cancel for a single mud density.)
    ECD_conventional = ρ + ΔP_ann / (g TVD_TD)            excludes SBP
    EMW_BHP          = BHP / (g TVD_TD)                   includes SBP
                       (the "ECD" figure usually quoted in MPD operations)
    ESD              = (ρ g TVD_TD + SBP) / (g TVD_TD)    static equivalent

Swab/surge (simplified, MODELING CHOICE REQUIRING VALIDATION)
-------------------------------------------------------------
Pipe moving down at v_p displaces fluid upward through every annulus
cross-section at a rate v_p·A_disp(z) (A_disp = π OD²/4 closed end,
π(OD²−ID²)/4 open end, all displaced fluid assumed to go to the annulus).
The effective annular velocity used for friction is (Burkhardt 1961;
Bourgoyne et al. 1986 §4.13):

    v_eff(z) = [Q_bit + v_p A_disp(z)] / A_ann(z) + K_c v_p

Steady-state only: fluid inertia, compressibility and string elasticity
are neglected (the lumped dynamic model adds inertia/compressibility).
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Dict, List, Optional

import numpy as np
import pandas as pd

from ..constants import GRAVITY
from ..dynamics.choke import ChokeModel
from ..dynamics.pressure_window import classify_bhp, margin_flags
from ..models.mud import MudProperties
from ..models.operations import OperatingConditions, PressureWindow
from ..models.segment import (ANNULUS_PATH, STRING_PATH, FlowPathGrid,
                              WellSegment, discretize_well)
from ..models.well import WellGeometry
from .bit import bit_hydraulic_power, jet_impact_force, nozzle_velocity
from .hydrostatics import gel_breaking_pressure, hydrostatic_pressure_increment
from .pressure_loss import (REGIME_TURBULENT, AnnulusPressureLoss,
                            BitPressureLoss, BourgoyneBinghamFriction,
                            FrictionModel, FrictionResult, PipePressureLoss)

logger = logging.getLogger(__name__)


@dataclass
class SegmentHydraulics:
    """Hydraulic state of one segment (geometry + flow results, SI units)."""

    segment: WellSegment
    flow_rate: float              # [m³/s] local volumetric flow (signed)
    velocity: float               # [m/s] mean (effective) velocity, signed
    reynolds: float
    hedstrom: float
    critical_reynolds: float
    flow_regime: str
    friction_factor: float        # Fanning [-]
    pressure_gradient: float      # [Pa/m] frictional
    friction_pressure_loss: float  # [Pa]
    hydrostatic_pressure: float   # [Pa]  ρ g ΔTVD of the segment
    plastic_viscosity: float      # [Pa·s] (rheology used for this segment)
    yield_stress: float           # [Pa]


@dataclass
class CirculatingLosses:
    """Frictional pressure-loss breakdown of the circulating system [Pa]."""

    drill_pipe: float
    bha: float
    bit: float
    annulus: float
    annulus_by_section: Dict[str, float] = field(default_factory=dict)

    @property
    def drill_string(self) -> float:
        """Drill pipe + BHA [Pa]."""
        return self.drill_pipe + self.bha

    @property
    def total(self) -> float:
        """All circulating frictional losses [Pa] (excl. choke)."""
        return self.drill_pipe + self.bha + self.bit + self.annulus


@dataclass
class HydraulicsResult:
    """Complete steady-state solution."""

    conditions: OperatingConditions
    losses: CirculatingLosses
    surface_back_pressure: float
    choke_flow_rate: float
    density: float
    td_tvd: float
    bit_tvd: float
    hydrostatic_td: float
    bhp: float
    bhp_static: float
    bhp_static_with_sbp: float
    spp: float
    ecd_conventional: float
    emw_bhp: float
    esd: float
    bit_details: Dict[str, float]
    gel_breaking_pressure: float
    string_profile: pd.DataFrame
    annulus_profile: pd.DataFrame
    segments: List[SegmentHydraulics]
    window_status: Optional[str] = None
    near_pore: bool = False
    near_fracture: bool = False

    def pressure_breakdown(self) -> pd.DataFrame:
        """SPP accounting table (transparent pressure bookkeeping)."""
        rows = [
            ("drill_pipe_friction", self.losses.drill_pipe),
            ("bha_friction", self.losses.bha),
            ("bit_pressure_drop", self.losses.bit),
            ("annulus_friction", self.losses.annulus),
            ("surface_back_pressure", self.surface_back_pressure),
            ("total_circulating_friction", self.losses.total),
            ("spp", self.spp),
        ]
        return pd.DataFrame(rows, columns=["component", "pressure_pa"])

    def summary(self) -> Dict[str, float]:
        """Flat dictionary of the headline results (SI)."""
        out = {
            "pump_rate_m3_s": self.conditions.pump_rate,
            "choke_flow_rate_m3_s": self.choke_flow_rate,
            "surface_back_pressure_pa": self.surface_back_pressure,
            "drill_pipe_loss_pa": self.losses.drill_pipe,
            "bha_loss_pa": self.losses.bha,
            "bit_loss_pa": self.losses.bit,
            "annulus_loss_pa": self.losses.annulus,
            "total_friction_pa": self.losses.total,
            "hydrostatic_td_pa": self.hydrostatic_td,
            "bhp_pa": self.bhp,
            "bhp_static_pa": self.bhp_static,
            "bhp_static_with_sbp_pa": self.bhp_static_with_sbp,
            "spp_pa": self.spp,
            "ecd_conventional_kg_m3": self.ecd_conventional,
            "emw_bhp_kg_m3": self.emw_bhp,
            "esd_kg_m3": self.esd,
            "mud_density_kg_m3": self.density,
            "td_tvd_m": self.td_tvd,
            "gel_breaking_pressure_pa": self.gel_breaking_pressure,
        }
        out.update({f"bit_{k}": v for k, v in self.bit_details.items()})
        if self.window_status is not None:
            out["window_status"] = self.window_status
        return out

    def segment_table(self) -> pd.DataFrame:
        """One row per segment (both flow paths) with all segment-level data."""
        rows = []
        for s in self.segments:
            g = s.segment
            rows.append({
                "flow_path": g.flow_path, "index": g.index, "section": g.section,
                "category": g.category, "md_top_m": g.md_top, "md_bottom_m": g.md_bottom,
                "tvd_top_m": g.tvd_top, "tvd_bottom_m": g.tvd_bottom,
                "inclination_deg": g.inclination, "azimuth_deg": g.azimuth,
                "length_m": g.length, "inner_diameter_m": g.inner_diameter,
                "outer_diameter_m": g.outer_diameter, "flow_area_m2": g.flow_area,
                "hydraulic_diameter_m": g.hydraulic_diameter,
                "flow_rate_m3_s": s.flow_rate, "velocity_m_s": s.velocity,
                "plastic_viscosity_pa_s": s.plastic_viscosity,
                "yield_stress_pa": s.yield_stress,
                "reynolds": s.reynolds, "hedstrom": s.hedstrom,
                "critical_reynolds": s.critical_reynolds, "flow_regime": s.flow_regime,
                "fanning_friction_factor": s.friction_factor,
                "friction_gradient_pa_m": s.pressure_gradient,
                "friction_loss_pa": s.friction_pressure_loss,
                "hydrostatic_pa": s.hydrostatic_pressure,
            })
        return pd.DataFrame(rows)

    @property
    def profile(self) -> pd.DataFrame:
        """String and annulus pressure profiles stacked."""
        return pd.concat([self.string_profile, self.annulus_profile], ignore_index=True)


class SteadyStateHydraulicsSolver:
    """
    Segment-based steady-state hydraulics for a single-density mud system.

    Parameters
    ----------
    well : WellGeometry
    mud : MudProperties
    friction_model : FrictionModel, optional (default Bourgoyne Bingham)
    segment_length : float [m]  target segment length
    choke : ChokeModel, optional (required for back_pressure_mode = "choke")
    """

    def __init__(self, well: WellGeometry, mud: MudProperties,
                 friction_model: Optional[FrictionModel] = None,
                 segment_length: float = 30.0,
                 choke: Optional[ChokeModel] = None) -> None:
        self.well = well
        self.mud = mud
        self.rheology = mud.rheology()
        self.friction_model = friction_model or BourgoyneBinghamFriction()
        self.friction_model.check_rheology(self.rheology)
        self.grid: FlowPathGrid = discretize_well(well, segment_length)
        self.choke = choke
        self.pipe_loss = PipePressureLoss(self.friction_model)
        self.annulus_loss = AnnulusPressureLoss(self.friction_model)
        self.bit_loss = BitPressureLoss()
        self._string_segments = self.grid.string_segments()
        self._annulus_segments = self.grid.annulus_segments()

    # ------------------------------------------------------------------
    # Geometry-derived quantities used by the dynamic model
    # ------------------------------------------------------------------
    @property
    def string_volume(self) -> float:
        """Internal drill-string volume [m³]."""
        return float(np.sum(self.grid.string_area * self.grid.length))

    @property
    def annulus_volume(self) -> float:
        """Annulus volume surface→bit plus open rathole bit→TD [m³]."""
        rathole = 0.0
        if self.well.total_depth > self.well.bit_depth:
            d = self.well.hole_sections[-1].diameter
            rathole = np.pi * d ** 2 / 4.0 * (self.well.total_depth - self.well.bit_depth)
        return float(np.sum(self.grid.annulus_area * self.grid.length) + rathole)

    def displacement_area(self, pipe_end: str):
        """Per-segment pipe displacement area [m²] for swab/surge."""
        return (self.grid.displacement_area_closed if pipe_end == "closed"
                else self.grid.displacement_area_open)

    # ------------------------------------------------------------------
    # Flow-path evaluations
    # ------------------------------------------------------------------
    def string_hydraulics(self, flow_rate: float):
        """Friction inside the string for flow Q [m³/s] (+ downward)."""
        return self.pipe_loss.segment_losses(self.rheology, self.mud.density, flow_rate,
                                             self.grid.pipe_id, self.grid.length)

    def annulus_flow(self, bit_flow_rate: float, pipe_velocity: float = 0.0,
                     pipe_end: str = "closed", clinging_constant: float = 0.45):
        """
        Local annular flow and effective velocity per segment.

        Returns
        -------
        (q_local [m³/s], v_eff [m/s]) arrays, positive upward.
        """
        q_local = bit_flow_rate + pipe_velocity * self.displacement_area(pipe_end)
        v_eff = q_local / self.grid.annulus_area + clinging_constant * pipe_velocity
        return q_local, v_eff

    def annulus_hydraulics(self, bit_flow_rate: float, pipe_velocity: float = 0.0,
                           pipe_end: str = "closed", clinging_constant: float = 0.45):
        """Friction in the annulus; returns (FrictionResult, ΔP per segment, q_local)."""
        q_local, v_eff = self.annulus_flow(bit_flow_rate, pipe_velocity, pipe_end,
                                           clinging_constant)
        result, dp = self.annulus_loss.segment_losses(
            self.rheology, self.mud.density, v_eff, self.grid.hole_diameter,
            self.grid.pipe_od, self.grid.length)
        return result, dp, q_local

    def bit_pressure_drop(self, flow_rate: float) -> float:
        """Bit nozzle pressure drop [Pa] (signed with flow)."""
        bit = self.well.bit
        return self.bit_loss.pressure_loss(self.mud.density, flow_rate,
                                           bit.total_flow_area, bit.discharge_coefficient)

    def circulating_losses(self, flow_rate: float, pipe_velocity: float = 0.0,
                           pipe_end: str = "closed",
                           clinging_constant: float = 0.45) -> CirculatingLosses:
        """Frictional loss breakdown for bit flow Q [m³/s] and pipe velocity v_p."""
        _, dp_string = self.string_hydraulics(flow_rate)
        _, dp_ann, _ = self.annulus_hydraulics(flow_rate, pipe_velocity, pipe_end,
                                               clinging_constant)
        return self._losses_from(flow_rate, dp_string, dp_ann)

    def _losses_from(self, flow_rate: float, dp_string: np.ndarray,
                     dp_ann: np.ndarray) -> CirculatingLosses:
        """Aggregate per-segment losses into the component breakdown."""
        is_bha = self.grid.string_category == "bha"
        by_section = (pd.Series(dp_ann).groupby(self.grid.annulus_section).sum().to_dict())
        return CirculatingLosses(
            drill_pipe=float(np.sum(dp_string[~is_bha])),
            bha=float(np.sum(dp_string[is_bha])),
            bit=self.bit_pressure_drop(flow_rate),
            annulus=float(np.sum(dp_ann)),
            annulus_by_section={k: float(v) for k, v in by_section.items()})

    # ------------------------------------------------------------------
    # Boundary condition and headline results
    # ------------------------------------------------------------------
    def choke_flow_rate(self, conditions: OperatingConditions) -> float:
        """Flow through the choke Q_choke = Q_pump + Q_bpp + v_p A_disp,surface [m³/s]."""
        surface_disp = self.displacement_area(conditions.pipe_end)[0]
        return max(conditions.pump_rate + conditions.backpressure_pump_rate
                   + conditions.pipe_velocity * surface_disp, 0.0)

    def surface_back_pressure(self, conditions: OperatingConditions) -> float:
        """SBP [Pa] according to the back-pressure mode."""
        if conditions.back_pressure_mode == "specified":
            return conditions.surface_back_pressure
        if self.choke is None:
            raise ValueError("back_pressure_mode='choke' requires a choke model.")
        dp = self.choke.pressure_drop(conditions.choke_opening,
                                      self.choke_flow_rate(conditions), self.mud.density)
        return conditions.choke_downstream_pressure + dp

    def hydrostatic_at_td(self) -> float:
        """ρ g TVD_TD [Pa]."""
        return float(hydrostatic_pressure_increment(self.mud.density, self.well.td_tvd))

    def required_back_pressure(self, target_bhp: float,
                               conditions: OperatingConditions) -> float:
        """SBP [Pa] needed to reach ``target_bhp`` at the current flow conditions."""
        losses = self.circulating_losses(conditions.pump_rate, conditions.pipe_velocity,
                                         conditions.pipe_end, conditions.clinging_constant)
        return target_bhp - self.hydrostatic_at_td() - losses.annulus

    def bhp_from(self, surface_back_pressure: float, annulus_friction: float) -> float:
        """BHP = SBP + ρ g TVD_TD + ΔP_ann  [Pa]."""
        return surface_back_pressure + self.hydrostatic_at_td() + annulus_friction

    def equivalent_density(self, pressure: float) -> float:
        """Pressure at TD → equivalent density P/(g TVD_TD) [kg/m³]."""
        return pressure / (GRAVITY * self.well.td_tvd)

    def gel_break_pressure(self) -> float:
        """Estimated pressure to break gels in string + annulus [Pa] (reported only)."""
        gel = self.mud.gel_10min if self.mud.gel_10min is not None else self.mud.gel_10s
        if gel is None:
            return 0.0
        g = self.grid
        return float(np.sum(gel_breaking_pressure(gel, g.length, g.pipe_id))
                     + np.sum(gel_breaking_pressure(gel, g.length, g.annulus_dh)))

    # ------------------------------------------------------------------
    # Full solution
    # ------------------------------------------------------------------
    def solve(self, conditions: OperatingConditions,
              window: Optional[PressureWindow] = None) -> HydraulicsResult:
        """
        Solve the steady-state circulating system.

        Parameters
        ----------
        conditions : OperatingConditions
        window : PressureWindow, optional — if given, BHP is classified.
        """
        rho = self.mud.density
        q = conditions.pump_rate
        sbp = self.surface_back_pressure(conditions)
        res_s, dp_s = self.string_hydraulics(q)
        res_a, dp_a, q_ann = self.annulus_hydraulics(q, conditions.pipe_velocity,
                                                     conditions.pipe_end,
                                                     conditions.clinging_constant)
        losses = self._losses_from(q, dp_s, dp_a)
        hydro_td = self.hydrostatic_at_td()
        bhp = self.bhp_from(sbp, losses.annulus)
        spp = sbp + losses.total
        string_profile = self._string_profile(spp, dp_s, res_s, q)
        annulus_profile = self._annulus_profile(sbp, dp_a, res_a, q_ann)
        segments = (self._segment_objects(self._string_segments, res_s, dp_s,
                                          np.full(self.grid.n_segments, q))
                    + self._segment_objects(self._annulus_segments, res_a, dp_a, q_ann))

        tfa = self.well.bit.total_flow_area
        bit_details = {
            "total_flow_area_m2": tfa,
            "nozzle_velocity_m_s": nozzle_velocity(q, tfa),
            "hydraulic_power_w": bit_hydraulic_power(losses.bit, q),
            "impact_force_n": jet_impact_force(rho, q, tfa),
            "discharge_coefficient": self.well.bit.discharge_coefficient,
        }
        result = HydraulicsResult(
            conditions=conditions, losses=losses, surface_back_pressure=sbp,
            choke_flow_rate=self.choke_flow_rate(conditions), density=rho,
            td_tvd=self.well.td_tvd, bit_tvd=self.well.bit_tvd,
            hydrostatic_td=hydro_td, bhp=bhp, bhp_static=hydro_td,
            bhp_static_with_sbp=hydro_td + sbp, spp=spp,
            ecd_conventional=rho + losses.annulus / (GRAVITY * self.well.td_tvd),
            emw_bhp=self.equivalent_density(bhp),
            esd=self.equivalent_density(hydro_td + sbp),
            bit_details=bit_details, gel_breaking_pressure=self.gel_break_pressure(),
            string_profile=string_profile, annulus_profile=annulus_profile,
            segments=segments)
        if window is not None:
            result.window_status = classify_bhp(bhp, window)
            result.near_pore, result.near_fracture = margin_flags(bhp, window)
            self._log_window(result)
        self._log_regimes(res_s, res_a)
        return result

    # ------------------------------------------------------------------
    # Profile construction
    # ------------------------------------------------------------------
    def annulus_pressure_profile(self, surface_pressure: float, dp_annulus: np.ndarray
                                 ) -> pd.DataFrame:
        """
        Annulus pressure at every node (wellhead → bit [→ TD]).

        P(z_j) = SBP + ρ g TVD(z_j) + Σ_{segments above z_j} ΔP_ann
        """
        g = self.grid
        md = np.append(g.md_top, g.md_bottom[-1])
        tvd = np.append(g.tvd_top, g.tvd_bottom[-1])
        friction = np.concatenate([[0.0], np.cumsum(dp_annulus)])
        if self.well.total_depth > self.well.bit_depth + 1e-6:
            md = np.append(md, self.well.total_depth)
            tvd = np.append(tvd, self.well.td_tvd)
            friction = np.append(friction, friction[-1])   # static rathole
        hydro = hydrostatic_pressure_increment(self.mud.density, tvd)
        return pd.DataFrame({
            "flow_path": ANNULUS_PATH, "md_m": md, "tvd_m": tvd,
            "pressure_pa": surface_pressure + hydro + friction,
            "surface_contribution_pa": surface_pressure,
            "hydrostatic_contribution_pa": hydro,
            "friction_contribution_pa": friction})

    def string_pressure_profile(self, surface_pressure: float, dp_string: np.ndarray
                                ) -> pd.DataFrame:
        """
        Drill-string internal pressure at every node (surface → bit, above nozzles).

        P(z_j) = SPP + ρ g TVD(z_j) − Σ_{segments above z_j} ΔP_string
        """
        g = self.grid
        md = np.append(g.md_top, g.md_bottom[-1])
        tvd = np.append(g.tvd_top, g.tvd_bottom[-1])
        friction = -np.concatenate([[0.0], np.cumsum(dp_string)])
        hydro = hydrostatic_pressure_increment(self.mud.density, tvd)
        return pd.DataFrame({
            "flow_path": STRING_PATH, "md_m": md, "tvd_m": tvd,
            "pressure_pa": surface_pressure + hydro + friction,
            "surface_contribution_pa": surface_pressure,
            "hydrostatic_contribution_pa": hydro,
            "friction_contribution_pa": friction})

    def _node_attributes(self, profile: pd.DataFrame, res: FrictionResult,
                         sections: np.ndarray) -> pd.DataFrame:
        """Attach segment properties to nodes (node j uses the segment ending at j)."""
        n_nodes = len(profile)
        idx = np.clip(np.arange(n_nodes) - 1, 0, self.grid.n_segments - 1)
        profile["section"] = sections[idx]
        profile["velocity_m_s"] = res.velocity[idx]
        profile["flow_regime"] = res.regime[idx]
        profile["reynolds"] = res.reynolds[idx]
        profile["friction_factor"] = res.friction_factor[idx]
        if n_nodes > self.grid.n_segments + 1:          # rathole node
            profile.loc[n_nodes - 1, ["section", "flow_regime"]] = ["rathole", "static"]
            profile.loc[n_nodes - 1, "velocity_m_s"] = 0.0
        return profile

    def _string_profile(self, spp, dp_s, res_s, q) -> pd.DataFrame:
        prof = self.string_pressure_profile(spp, dp_s)
        return self._node_attributes(prof, res_s, self.grid.string_section)

    def _annulus_profile(self, sbp, dp_a, res_a, q_ann) -> pd.DataFrame:
        prof = self.annulus_pressure_profile(sbp, dp_a)
        return self._node_attributes(prof, res_a, self.grid.annulus_section)

    def _segment_objects(self, segments: List[WellSegment], res: FrictionResult,
                         dp: np.ndarray, q_local: np.ndarray) -> List[SegmentHydraulics]:
        hydro = hydrostatic_pressure_increment(self.mud.density, self.grid.delta_tvd)
        return [SegmentHydraulics(
            segment=seg, flow_rate=float(q_local[i]), velocity=float(res.velocity[i]),
            reynolds=float(res.reynolds[i]), hedstrom=float(res.hedstrom[i]),
            critical_reynolds=float(res.critical_reynolds[i]),
            flow_regime=str(res.regime[i]), friction_factor=float(res.friction_factor[i]),
            pressure_gradient=float(res.pressure_gradient[i]),
            friction_pressure_loss=float(dp[i]), hydrostatic_pressure=float(hydro[i]),
            plastic_viscosity=self.rheology.plastic_viscosity,
            yield_stress=self.rheology.yield_stress)
            for i, seg in enumerate(segments)]

    # ------------------------------------------------------------------
    # Logging helpers
    # ------------------------------------------------------------------
    @staticmethod
    def _log_regimes(res_s: FrictionResult, res_a: FrictionResult) -> None:
        for name, res in (("drill string", res_s), ("annulus", res_a)):
            turbulent = np.mean(res.regime == REGIME_TURBULENT)
            logger.debug("%s: %.0f %% of segments turbulent.", name, 100 * turbulent)
            if 0.0 < turbulent < 1.0:
                logger.info("Mixed laminar/turbulent flow along the %s.", name)

    @staticmethod
    def _log_window(result: HydraulicsResult) -> None:
        if result.window_status == "kick_risk":
            logger.warning("BHP below pore pressure: kick risk / underbalance.")
        elif result.window_status == "loss_risk":
            logger.warning("BHP above fracture pressure: loss / fracture risk.")
        elif result.near_fracture:
            logger.warning("BHP approaching fracture pressure.")
        elif result.near_pore:
            logger.warning("BHP approaching pore pressure.")
