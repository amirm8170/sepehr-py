"""
Pressure-loss models.

Two layers:

1. ``FrictionModel`` (strategy) — turns (rheology, ρ, v, D_h, geometry) into
   Reynolds/Hedstrom numbers, regime, Fanning factor and frictional pressure
   gradient. Interchangeable implementations:

   * ``BourgoyneBinghamFriction`` (DEFAULT)
       laminar : exact Buckingham–Reiner (pipe) / Bingham slot (annulus)
       regime  : Hanks (1963) critical Reynolds number
       turbulent: Blasius-type f = 0.0791 Re^-0.25 on μ_p (Bourgoyne et al. 1986),
                  annulus with D_eff = 0.816 D_h
       continuity: in the turbulent regime f = max(f_L, f_T) so the friction
                  never drops discontinuously at Re_c.
     Why selected: the standard Bingham procedure of the SPE textbook
     "Applied Drilling Engineering" — familiar, traceable, and the natural
     reference for a drilling-hydraulics thesis.
     Status: MODELING CHOICE REQUIRING VALIDATION (the proposal names the
     Bingham model but not the friction correlation).

   * ``DarbyBinghamFriction`` (ALTERNATIVE)
       laminar as above; turbulent Darby–Mun–Boger (1992); smooth all-regime
       blending. Useful as a second opinion / sensitivity on correlation choice.

2. Component pressure-loss classes that the solver uses —
   ``PipePressureLoss``, ``AnnulusPressureLoss``, ``BitPressureLoss``,
   ``ChokePressureLoss`` — all derived from ``PressureLossModel``.

Sign convention: a returned frictional pressure loss is positive when the
flow is in the path's positive direction (down the string, up the annulus)
and negative for reversed flow. Zero velocity gives zero friction (gels are
handled separately by ``hydrostatics.gel_breaking_pressure``).

How to add a correlation: subclass ``FrictionModel``, implement
``_turbulent_and_combined`` (or ``evaluate``), list supported rheologies,
and register it in ``FRICTION_MODELS``. No solver change is needed.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Dict, Tuple, Type

import numpy as np

from ..constants import ANNULUS_TURBULENT_DIAMETER_FACTOR, ZERO_VELOCITY_TOLERANCE
from . import bit as bit_hydraulics
from .friction import (ANNULUS, PIPE, blasius_friction_factor,
                       darby_blended_friction_factor,
                       darby_turbulent_friction_factor,
                       fanning_from_wall_stress, laminar_bingham_wall_stress)
from .geometry import annulus_area, annulus_hydraulic_diameter, pipe_area
from .reynolds import hanks_critical_reynolds, hedstrom_number, reynolds_number
from .rheology import BinghamPlastic, RheologyModel

REGIME_STATIC = "static"
REGIME_LAMINAR = "laminar"
REGIME_TURBULENT = "turbulent"


@dataclass
class FrictionResult:
    """
    Segment-wise friction evaluation (all arrays share one shape).

    velocity            : signed mean velocity [m/s]
    reynolds            : Re on D_h [-]
    hedstrom            : He on D_h [-]
    critical_reynolds   : Hanks Re_c [-]
    regime              : "static" | "laminar" | "turbulent"
    friction_factor     : Fanning f [-] (NaN when static)
    pressure_gradient   : signed frictional gradient dP/dL [Pa/m]
    """

    velocity: np.ndarray
    reynolds: np.ndarray
    hedstrom: np.ndarray
    critical_reynolds: np.ndarray
    regime: np.ndarray
    friction_factor: np.ndarray
    pressure_gradient: np.ndarray


class FrictionModel(ABC):
    """Strategy interface for frictional pressure-gradient correlations."""

    name: str = "abstract"
    supported_rheologies: Tuple[Type[RheologyModel], ...] = ()

    def check_rheology(self, rheology: RheologyModel) -> None:
        """Raise a clear error if this correlation does not support the rheology."""
        if not isinstance(rheology, self.supported_rheologies):
            raise NotImplementedError(
                f"Friction model '{self.name}' supports "
                f"{[c.__name__ for c in self.supported_rheologies]}, not "
                f"{type(rheology).__name__}. Add a FrictionModel for this rheology "
                f"(see README: 'How to add a new pressure-loss correlation').")

    def evaluate(self, rheology: RheologyModel, density: float, velocity,
                 hydraulic_diameter, geometry: str) -> FrictionResult:
        """
        Evaluate friction for a set of segments.

        Parameters
        ----------
        rheology : RheologyModel
        density : float [kg/m³]
        velocity : array [m/s]  signed mean velocity
        hydraulic_diameter : array [m]
        geometry : "pipe" | "annulus"
        """
        self.check_rheology(rheology)
        mu_p = rheology.plastic_viscosity
        tau_y = rheology.yield_stress
        if mu_p <= 0:
            raise ValueError("Bingham friction models require PV > 0.")
        v = np.asarray(velocity, dtype=float)
        d_h = np.broadcast_to(np.asarray(hydraulic_diameter, dtype=float), v.shape)
        speed = np.abs(v)
        flowing = speed > ZERO_VELOCITY_TOLERANCE

        re = reynolds_number(density, speed, d_h, mu_p)
        he = hedstrom_number(density, tau_y, d_h, mu_p)
        re_c = hanks_critical_reynolds(he).reshape(v.shape)

        tau_w_lam = laminar_bingham_wall_stress(speed, d_h, mu_p, tau_y, geometry)
        f_lam = fanning_from_wall_stress(tau_w_lam, density, speed)
        f = self._combine(f_lam, density, speed, d_h, re, he, re_c, geometry)

        turbulent = flowing & (re >= re_c)
        regime = np.where(~flowing, REGIME_STATIC,
                          np.where(turbulent, REGIME_TURBULENT, REGIME_LAMINAR))
        f = np.where(flowing, f, np.nan)
        gradient = np.where(flowing,
                            np.sign(v) * 2.0 * np.nan_to_num(f) * density * speed ** 2 / d_h,
                            0.0)
        return FrictionResult(velocity=v, reynolds=re, hedstrom=he,
                              critical_reynolds=re_c, regime=regime,
                              friction_factor=f, pressure_gradient=gradient)

    @abstractmethod
    def _combine(self, f_laminar, density, speed, d_h, re, he, re_c,
                 geometry: str):
        """Return the Fanning factor used for the pressure gradient."""


class BourgoyneBinghamFriction(FrictionModel):
    """Default Bingham friction model (see module docstring)."""

    name = "bourgoyne"
    supported_rheologies = (BinghamPlastic,)

    def _combine(self, f_laminar, density, speed, d_h, re, he, re_c, geometry):
        # Turbulent: Blasius on μ_p with an effective diameter for the annulus.
        # Fanning f is referred to D_h by:  2 f_T ρ v²/D_eff = 2 f ρ v²/D_h.
        factor = ANNULUS_TURBULENT_DIAMETER_FACTOR if geometry == ANNULUS else 1.0
        re_eff = re * factor
        f_turb_eff = blasius_friction_factor(np.maximum(re_eff, 1e-12))
        f_turb = f_turb_eff / factor
        turbulent = re >= re_c
        return np.where(turbulent, np.fmax(f_laminar, f_turb), f_laminar)


class DarbyBinghamFriction(FrictionModel):
    """Alternative Bingham friction model, Darby–Mun–Boger (1992)."""

    name = "darby"
    supported_rheologies = (BinghamPlastic,)

    def _combine(self, f_laminar, density, speed, d_h, re, he, re_c, geometry):
        f_turb = darby_turbulent_friction_factor(np.maximum(re, 1e-12), he)
        return darby_blended_friction_factor(np.nan_to_num(f_laminar), f_turb, re)


FRICTION_MODELS: Dict[str, Type[FrictionModel]] = {
    BourgoyneBinghamFriction.name: BourgoyneBinghamFriction,
    DarbyBinghamFriction.name: DarbyBinghamFriction,
}


def build_friction_model(name: str) -> FrictionModel:
    """Factory for friction models by name ("bourgoyne" or "darby")."""
    key = name.lower()
    if key not in FRICTION_MODELS:
        raise ValueError(f"Unknown friction model '{name}'. Available: {sorted(FRICTION_MODELS)}")
    return FRICTION_MODELS[key]()


# ---------------------------------------------------------------------------
# Component pressure-loss models
# ---------------------------------------------------------------------------
class PressureLossModel(ABC):
    """Base class for a component of the circulating system."""

    component: str = "abstract"


class PipePressureLoss(PressureLossModel):
    """
    Frictional loss inside drill pipe / BHA segments.

        ΔP_i = (dP/dL)_i × L_i ,   v_i = Q / (π ID_i² / 4)
    """

    component = "pipe"

    def __init__(self, friction_model: FrictionModel) -> None:
        self.friction_model = friction_model

    def segment_losses(self, rheology: RheologyModel, density: float, flow_rate: float,
                       inner_diameter, length) -> Tuple[FrictionResult, np.ndarray]:
        """
        Parameters
        ----------
        flow_rate : float [m³/s], positive = down the string
        inner_diameter, length : arrays [m]

        Returns
        -------
        (FrictionResult, ΔP_friction per segment [Pa])
        """
        velocity = flow_rate / pipe_area(inner_diameter)
        result = self.friction_model.evaluate(rheology, density, velocity,
                                              inner_diameter, PIPE)
        return result, result.pressure_gradient * np.asarray(length)


class AnnulusPressureLoss(PressureLossModel):
    """
    Frictional loss in concentric annulus segments.

        ΔP_i = (dP/dL)_i × L_i ,  D_h = D_hole − OD,  v = effective velocity

    The caller supplies the (possibly swab/surge-corrected) effective
    velocity; positive = upward flow.
    """

    component = "annulus"

    def __init__(self, friction_model: FrictionModel) -> None:
        self.friction_model = friction_model

    def segment_losses(self, rheology: RheologyModel, density: float, velocity,
                       hole_diameter, outer_diameter, length
                       ) -> Tuple[FrictionResult, np.ndarray]:
        d_h = annulus_hydraulic_diameter(hole_diameter, outer_diameter)
        result = self.friction_model.evaluate(rheology, density, velocity, d_h, ANNULUS)
        return result, result.pressure_gradient * np.asarray(length)

    @staticmethod
    def flow_area(hole_diameter, outer_diameter):
        """Annular flow area [m²] (re-exported for convenience)."""
        return annulus_area(hole_diameter, outer_diameter)


class BitPressureLoss(PressureLossModel):
    """Pressure drop across bit nozzles (see ``hydraulics.bit``)."""

    component = "bit"

    def pressure_loss(self, density: float, flow_rate: float, total_flow_area: float,
                      discharge_coefficient: float) -> float:
        return bit_hydraulics.bit_pressure_drop(density, flow_rate, total_flow_area,
                                                discharge_coefficient)


class ChokePressureLoss(PressureLossModel):
    """Pressure drop across the MPD choke (delegates to a ChokeModel)."""

    component = "choke"

    def __init__(self, choke_model) -> None:
        self.choke_model = choke_model

    def pressure_loss(self, density: float, flow_rate: float, opening: float) -> float:
        return self.choke_model.pressure_drop(opening, flow_rate, density)
