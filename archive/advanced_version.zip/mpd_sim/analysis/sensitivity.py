"""
One-at-a-time (OAT) steady-state sensitivity analysis.

Each parameter is perturbed by ±``relative_change`` (default ±10 %) around
the base case while all others are held fixed; BHP, SPP and conventional
ECD are recomputed with the Stage-A solver. For "target_bhp" the reported
outputs are the REQUIRED surface back pressure and choke opening (the
target does not change the open-loop hydraulics).

Parameters
----------
pump_rate, mud_weight, plastic_viscosity, yield_point, hole_diameter
(all hole sections scaled), pipe_od (all components scaled; ID kept, so
the OD perturbation must stay above ID), back_pressure (choke mode:
interpreted as SBP in "specified" mode), choke_opening, target_bhp.

OAT analysis ignores interactions between parameters (a limitation); a
global method (e.g. Sobol) is a possible extension.
"""

from __future__ import annotations

import copy
import logging
from dataclasses import replace
from typing import Callable, Dict, List, Sequence

import numpy as np
import pandas as pd

from ..hydraulics.hydraulics import SteadyStateHydraulicsSolver
from ..io.loaders import SimulationSetup
from ..models.operations import OperatingConditions
from ..models.well import WellGeometry

logger = logging.getLogger(__name__)

#: Outputs and their SI unit suffix in the result table.
OUTPUT_UNITS = {"bhp": "pa", "spp": "pa", "ecd": "kg_m3"}

PARAMETERS = ("pump_rate", "mud_weight", "plastic_viscosity", "yield_point",
              "hole_diameter", "pipe_od", "back_pressure", "choke_opening", "target_bhp")


def _scaled_well(well: WellGeometry, hole_factor: float = 1.0,
                 od_factor: float = 1.0) -> WellGeometry:
    holes = [replace(h, diameter=h.diameter * hole_factor) for h in well.hole_sections]
    string = [replace(c, outer_diameter=c.outer_diameter * od_factor) for c in well.drill_string]
    return WellGeometry(trajectory=well.trajectory, hole_sections=holes,
                        drill_string=string, bit=well.bit)


def _evaluate(setup: SimulationSetup, parameter: str, factor: float) -> Dict[str, float]:
    """Solve the steady state with one parameter multiplied by ``factor``."""
    base_solver = setup.solver
    seg_len = float(np.max(base_solver.grid.length))
    well, mud, cond = setup.well, setup.mud, setup.conditions
    if parameter == "mud_weight":
        mud = mud.with_changes(density=mud.density * factor)
    elif parameter == "plastic_viscosity":
        mud = mud.with_changes(plastic_viscosity=mud.plastic_viscosity * factor)
    elif parameter == "yield_point":
        mud = mud.with_changes(yield_point=mud.yield_point * factor)
    elif parameter == "hole_diameter":
        well = _scaled_well(well, hole_factor=factor)
    elif parameter == "pipe_od":
        well = _scaled_well(well, od_factor=factor)
    elif parameter == "pump_rate":
        cond = cond.with_changes(pump_rate=cond.pump_rate * factor)
    elif parameter == "back_pressure":
        sbp = base_solver.surface_back_pressure(cond)
        cond = cond.with_changes(back_pressure_mode="specified",
                                 surface_back_pressure=sbp * factor)
    elif parameter == "choke_opening":
        cond = cond.with_changes(back_pressure_mode="choke",
                                 choke_opening=float(np.clip(cond.choke_opening * factor, 0, 1)))
    elif parameter != "target_bhp":
        raise ValueError(f"Unknown sensitivity parameter '{parameter}'.")

    solver = (base_solver if (well is setup.well and mud is setup.mud) else
              SteadyStateHydraulicsSolver(well, mud, base_solver.friction_model, seg_len,
                                          base_solver.choke))
    if parameter == "target_bhp":
        target = setup.window.target_bhp * factor
        sbp_req = solver.required_back_pressure(target, cond)
        q = solver.choke_flow_rate(cond)
        opening = solver.choke.opening_for(q, max(sbp_req, 0.0), mud.density)
        res = solver.solve(cond.with_changes(back_pressure_mode="specified",
                                             surface_back_pressure=max(sbp_req, 0.0)))
        return {"bhp_pa": res.bhp, "spp_pa": res.spp, "ecd_kg_m3": res.ecd_conventional,
                "required_sbp_pa": sbp_req, "required_choke_opening": opening}
    res = solver.solve(cond)
    return {"bhp_pa": res.bhp, "spp_pa": res.spp, "ecd_kg_m3": res.ecd_conventional,
            "sbp_pa": res.surface_back_pressure}


def one_at_a_time(setup: SimulationSetup, relative_change: float = 0.10,
                  parameters: Sequence[str] = PARAMETERS) -> pd.DataFrame:
    """
    OAT sensitivity table.

    Returns one row per parameter with base, low (−Δ) and high (+Δ) values of
    BHP, SPP and ECD, their changes, and normalised sensitivity
    S = (ΔY/Y) / (ΔX/X) from the central difference.
    """
    if not 0 < relative_change < 0.5:
        raise ValueError("relative_change must be in (0, 0.5).")
    base = _evaluate(setup, "pump_rate", 1.0)
    rows: List[Dict] = []
    for p in parameters:
        low = _evaluate(setup, p, 1.0 - relative_change)
        high = _evaluate(setup, p, 1.0 + relative_change)
        row: Dict = {"parameter": p, "relative_change": relative_change}
        ref = _evaluate(setup, p, 1.0) if p == "target_bhp" else base
        for out, unit in OUTPUT_UNITS.items():
            key = f"{out}_{unit}"
            row[f"{out}_base_{unit}"] = ref[key]
            row[f"{out}_low_{unit}"] = low[key]
            row[f"{out}_high_{unit}"] = high[key]
            row[f"{out}_low_change_{unit}"] = low[key] - ref[key]
            row[f"{out}_high_change_{unit}"] = high[key] - ref[key]
            row[f"{out}_normalised_sensitivity"] = (
                (high[key] - low[key]) / ref[key] / (2 * relative_change))
        if p == "target_bhp":
            row["required_sbp_low_pa"] = low["required_sbp_pa"]
            row["required_sbp_high_pa"] = high["required_sbp_pa"]
            row["required_choke_opening_low"] = low["required_choke_opening"]
            row["required_choke_opening_high"] = high["required_choke_opening"]
        rows.append(row)
        logger.info("Sensitivity %-18s BHP %+8.2f / %+8.2f bar", p,
                    row["bhp_low_change_pa"] / 1e5, row["bhp_high_change_pa"] / 1e5)
    return pd.DataFrame(rows)


def sweep(setup: SimulationSetup, parameter: str, factors: Sequence[float],
          display: Callable[[float], float] = lambda f: f) -> pd.DataFrame:
    """
    Evaluate BHP/SPP/ECD over a range of multiplicative factors of one parameter.

    ``display`` maps a factor to the x-axis value shown in plots (e.g. gpm).
    """
    rows = []
    for f in factors:
        r = _evaluate(setup, parameter, float(f))
        rows.append({"parameter": parameter, "factor": float(f),
                     "value_display": display(float(f)), **r})
    return pd.DataFrame(rows)
