"""
Configuration and input-data loading.

Every numeric configuration key carries its unit as a suffix
(``density_ppg``, ``hole_diameter_in``...). :func:`read_quantity` finds the
key, checks that exactly one unit variant is present, and converts to SI.
This is the ONLY place where field units enter the program.
"""

from __future__ import annotations

import copy
import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd
import yaml

from ..dynamics.choke import SimpleCvChoke, build_choke
from ..hydraulics.hydraulics import SteadyStateHydraulicsSolver
from ..hydraulics.pressure_loss import build_friction_model
from ..models.mud import MudProperties
from ..models.operations import OperatingConditions, PressureWindow
from ..models.trajectory import Trajectory
from ..models.well import BitNozzles, DrillStringComponent, HoleSection, WellGeometry
from ..units import UNIT_TABLE, emw_to_pressure, to_si

logger = logging.getLogger(__name__)

PROJECT_ROOT = Path(__file__).resolve().parents[2]


class ConfigError(ValueError):
    """Raised for missing/ambiguous configuration entries."""


# ---------------------------------------------------------------------------
# Generic helpers
# ---------------------------------------------------------------------------
def load_yaml(path) -> Dict[str, Any]:
    """Read a YAML file into a dictionary."""
    with open(path, "r", encoding="utf-8") as fh:
        return yaml.safe_load(fh) or {}


def deep_merge(base: Dict[str, Any], override: Dict[str, Any]) -> Dict[str, Any]:
    """Recursively merge ``override`` into a copy of ``base``."""
    out = copy.deepcopy(base)
    for key, value in (override or {}).items():
        if isinstance(value, dict) and isinstance(out.get(key), dict):
            out[key] = deep_merge(out[key], value)
        else:
            out[key] = copy.deepcopy(value)
    return out


def find_unit_key(section: Dict[str, Any], base: str, kind: str) -> Optional[str]:
    """
    Return the unit tag used for ``base`` in ``section`` (None if absent).

    Raises ConfigError if the quantity is given in more than one unit.
    """
    found = [u for u in UNIT_TABLE[kind] if f"{base}_{u}" in section]
    if len(found) > 1:
        raise ConfigError(f"'{base}' given in several units {found}; keep one.")
    return found[0] if found else None


def read_quantity(section: Dict[str, Any], base: str, kind: str,
                  default: Optional[float] = None, required: bool = True):
    """
    Read ``base_<unit>`` from a config section and convert to SI.

    Works for scalars and lists (e.g. nozzle sizes).
    """
    unit = find_unit_key(section, base, kind)
    if unit is None:
        if default is not None or not required:
            return default
        raise ConfigError(f"Missing '{base}_<unit>' ({kind}); allowed units: "
                          f"{sorted(UNIT_TABLE[kind])}.")
    value = section[f"{base}_{unit}"]
    if isinstance(value, (list, tuple)):
        return [to_si(float(v), unit, kind) for v in value]
    return to_si(float(value), unit, kind)


def read_pressure_or_emw(section: Dict[str, Any], base: str, tvd: float,
                         required: bool = True) -> Optional[float]:
    """Read a pressure given directly (``base_psi``) or as EMW (``base_emw_ppg``)."""
    direct = read_quantity(section, base, "pressure", required=False)
    emw = read_quantity(section, f"{base}_emw", "density", required=False)
    if direct is not None and emw is not None:
        raise ConfigError(f"'{base}' given both as pressure and as EMW.")
    if emw is not None:
        return emw_to_pressure(emw, tvd)
    if direct is None and required:
        raise ConfigError(f"Missing '{base}_<pressure unit>' or '{base}_emw_<density unit>'.")
    return direct


def resolve_path(path: str, base_dir: Optional[Path] = None) -> Path:
    """Resolve a relative data path against the project root."""
    p = Path(path)
    if p.is_absolute():
        return p
    for root in (base_dir, PROJECT_ROOT):
        if root is not None and (Path(root) / p).exists():
            return Path(root) / p
    return PROJECT_ROOT / p


# ---------------------------------------------------------------------------
# Domain builders
# ---------------------------------------------------------------------------
def load_trajectory_csv(path) -> Trajectory:
    """
    Load survey stations from CSV.

    Required columns: ``md_<length unit>``, ``inclination_deg``,
    ``azimuth_deg``; optional ``tvd_<length unit>``. Lines starting with
    '#' are comments.
    """
    df = pd.read_csv(path, comment="#")
    cols = {c: None for c in df.columns}
    md = read_quantity_column(df, "md")
    tvd = read_quantity_column(df, "tvd", required=False)
    for col in ("inclination_deg", "azimuth_deg"):
        if col not in cols:
            raise ConfigError(f"Trajectory file needs column '{col}'.")
    return Trajectory.from_stations(md, df["inclination_deg"].to_numpy(),
                                    df["azimuth_deg"].to_numpy(), tvd)


def read_quantity_column(df: pd.DataFrame, base: str, required: bool = True):
    """Find a ``base_<length unit>`` column and return it in metres."""
    for unit in UNIT_TABLE["length"]:
        col = f"{base}_{unit}"
        if col in df.columns:
            return df[col].to_numpy(dtype=float) * to_si(1.0, unit, "length")
    if required:
        raise ConfigError(f"Missing column '{base}_<length unit>'.")
    return None


def build_trajectory(cfg: Dict[str, Any], base_dir: Optional[Path] = None) -> Trajectory:
    """Trajectory from a CSV file or from inline ``stations``."""
    if "file" in cfg:
        return load_trajectory_csv(resolve_path(cfg["file"], base_dir))
    stations = cfg.get("stations")
    if not stations:
        raise ConfigError("Trajectory needs 'file' or 'stations'.")
    md = [read_quantity(s, "md", "length") for s in stations]
    inc = [float(s.get("inclination_deg", 0.0)) for s in stations]
    azi = [float(s.get("azimuth_deg", 0.0)) for s in stations]
    tvd_list = [read_quantity(s, "tvd", "length", required=False) for s in stations]
    tvd = None if any(t is None for t in tvd_list) else tvd_list
    return Trajectory.from_stations(md, inc, azi, tvd)


def build_well(cfg: Dict[str, Any], base_dir: Optional[Path] = None) -> WellGeometry:
    """WellGeometry from the ``well`` config section."""
    trajectory = build_trajectory(cfg["trajectory"], base_dir)
    holes: List[HoleSection] = [
        HoleSection(name=h["name"], kind=h.get("kind", "open_hole"),
                    top_md=read_quantity(h, "top_md", "length"),
                    bottom_md=read_quantity(h, "bottom_md", "length"),
                    diameter=read_quantity(h, "diameter", "length"))
        for h in cfg["hole_sections"]]
    string = [
        DrillStringComponent(name=c["name"], category=c.get("category", "drill_pipe"),
                             length=read_quantity(c, "length", "length"),
                             outer_diameter=read_quantity(c, "outer_diameter", "length"),
                             inner_diameter=read_quantity(c, "inner_diameter", "length"))
        for c in cfg["drill_string"]]
    bit_cfg = cfg["bit"]
    bit = BitNozzles(nozzle_diameters=read_quantity(bit_cfg, "nozzle_diameters", "length"),
                     discharge_coefficient=float(bit_cfg.get("discharge_coefficient", 0.95)))
    return WellGeometry(trajectory=trajectory, hole_sections=holes,
                        drill_string=string, bit=bit)


def build_mud(cfg: Dict[str, Any]) -> MudProperties:
    """MudProperties from the ``mud`` config section."""
    return MudProperties(
        density=read_quantity(cfg, "density", "density"),
        plastic_viscosity=read_quantity(cfg, "plastic_viscosity", "viscosity"),
        yield_point=read_quantity(cfg, "yield_point", "stress"),
        gel_10s=read_quantity(cfg, "gel_10s", "stress", required=False),
        gel_10min=read_quantity(cfg, "gel_10min", "stress", required=False),
        rheology_model=cfg.get("rheology_model", "bingham_plastic"),
        bulk_modulus=read_quantity(cfg, "bulk_modulus", "pressure", default=1.5e9))


def build_choke_model(cfg: Dict[str, Any]) -> SimpleCvChoke:
    """Choke model from the ``choke`` config section."""
    return build_choke(
        characteristic=cfg.get("characteristic", "linear"),
        cv_max=float(cfg["cv_max"]), cv_leak=float(cfg.get("cv_leak", 0.0)),
        rangeability=float(cfg.get("rangeability", 50.0)),
        table_openings=cfg.get("table_openings_frac"), table_cvs=cfg.get("table_cvs"),
        min_opening=float(cfg.get("min_opening_frac", 0.0)),
        max_opening=float(cfg.get("max_opening_frac", 1.0)),
        linearization_dp=float(cfg.get("linearization_dp_pa", 1.0e4)))


def build_window(cfg: Dict[str, Any], tvd: float) -> PressureWindow:
    """PressureWindow from the ``pressure_window`` section (at TVD of TD)."""
    return PressureWindow(
        pore_pressure=read_pressure_or_emw(cfg, "pore_pressure", tvd),
        fracture_pressure=read_pressure_or_emw(cfg, "fracture_pressure", tvd),
        target_bhp=read_pressure_or_emw(cfg, "target_bhp", tvd),
        reference_tvd=tvd,
        warning_margin=read_quantity(cfg, "warning_margin", "pressure", default=0.0),
        allow_target_outside_window=bool(cfg.get("allow_target_outside_window", False)))


def build_conditions(cfg: Dict[str, Any], choke_opening: Optional[float] = None
                     ) -> OperatingConditions:
    """
    OperatingConditions from the ``operations`` section.

    ``choke_opening`` overrides the config value (used when it is "auto").
    """
    opening = cfg.get("choke_opening_frac", 1.0)
    if choke_opening is not None:
        opening = choke_opening
    elif isinstance(opening, str):
        opening = 1.0   # placeholder until resolved by resolve_auto_choke_opening
    return OperatingConditions(
        pump_rate=read_quantity(cfg, "pump_rate", "flow_rate"),
        back_pressure_mode=cfg.get("back_pressure_mode", "specified"),
        surface_back_pressure=read_quantity(cfg, "surface_back_pressure", "pressure", default=0.0),
        choke_opening=float(opening),
        backpressure_pump_rate=read_quantity(cfg, "backpressure_pump_rate", "flow_rate",
                                             default=0.0),
        pipe_velocity=read_quantity(cfg, "pipe_velocity", "velocity", default=0.0),
        pipe_end=cfg.get("pipe_end", "closed"),
        clinging_constant=float(cfg.get("clinging_constant", 0.45)),
        choke_downstream_pressure=read_quantity(cfg, "choke_downstream_pressure", "pressure",
                                                default=0.0))


@dataclass
class SimulationSetup:
    """Everything built from one configuration (SI objects)."""

    config: Dict[str, Any]
    well: WellGeometry
    mud: MudProperties
    choke: SimpleCvChoke
    solver: SteadyStateHydraulicsSolver
    conditions: OperatingConditions
    window: PressureWindow


def resolve_auto_choke_opening(solver: SteadyStateHydraulicsSolver,
                               conditions: OperatingConditions,
                               target_bhp: float) -> float:
    """
    Choke opening that gives the target BHP at the given flow (inverse choke curve).

    Logs a warning when the target cannot be reached within the actuator range.
    """
    sbp_needed = solver.required_back_pressure(target_bhp, conditions)
    if sbp_needed < 0:
        logger.warning("Target BHP is below the circulating BHP with zero back "
                       "pressure; choke set fully open.")
        return solver.choke.max_opening
    dp_needed = sbp_needed - conditions.choke_downstream_pressure
    q = solver.choke_flow_rate(conditions)
    opening = solver.choke.opening_for(q, dp_needed, solver.mud.density)
    logger.info("Auto choke opening %.3f for SBP %.2f bar at %.4f m³/s.",
                opening, sbp_needed / 1e5, q)
    return opening


def build_setup(config: Dict[str, Any], base_dir: Optional[Path] = None) -> SimulationSetup:
    """Build well, mud, choke, solver, operating conditions and window from a config dict."""
    well = build_well(config["well"], base_dir)
    mud = build_mud(config["mud"])
    choke = build_choke_model(config["choke"])
    numerics = config.get("numerics", {})
    solver = SteadyStateHydraulicsSolver(
        well, mud, friction_model=build_friction_model(numerics.get("friction_model", "bourgoyne")),
        segment_length=read_quantity(numerics, "segment_length", "length", default=30.0),
        choke=choke)
    window = build_window(config["pressure_window"], well.td_tvd)
    ops = config["operations"]
    conditions = build_conditions(ops)
    if str(ops.get("choke_opening_frac", "")).lower() == "auto":
        opening = resolve_auto_choke_opening(solver, conditions, window.target_bhp)
        conditions = conditions.with_changes(choke_opening=opening)
    return SimulationSetup(config=config, well=well, mud=mud, choke=choke, solver=solver,
                           conditions=conditions, window=window)


def load_setup(path, overrides: Optional[Dict[str, Any]] = None) -> SimulationSetup:
    """Load a YAML config (optionally merged with overrides) and build the setup."""
    config = load_yaml(path)
    if overrides:
        config = deep_merge(config, overrides)
    return build_setup(config, Path(path).resolve().parent.parent)


def load_reference_csv(path) -> pd.DataFrame:
    """
    Load a validation reference dataset.

    Expected columns: ``quantity``, ``reference_value``, ``unit``,
    ``data_type`` (synthetic_demonstration | literature | laboratory | field),
    ``source``; optional ``md_m`` / ``time_s`` and case parameters.
    """
    df = pd.read_csv(path, comment="#")
    required = {"quantity", "reference_value", "unit", "data_type", "source"}
    missing = required - set(df.columns)
    if missing:
        raise ConfigError(f"Reference file missing columns: {sorted(missing)}")
    return df


def schedule_points(values: List[List[float]], unit: str, kind: str) -> np.ndarray:
    """Convert [[t, v], ...] (v in ``unit``) to an SI (N, 2) array."""
    arr = np.asarray(values, dtype=float).reshape(-1, 2)
    arr[:, 1] = arr[:, 1] * to_si(1.0, unit, kind)
    return arr
