"""
Result export (CSV / JSON).

CSV files keep the SI columns produced by the engine and ADD clearly named
field-unit columns (``*_psi``, ``*_bar``, ``*_ppg``, ``*_gpm``) — the SI
columns are never overwritten, so units are never mixed in one column.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Dict

import numpy as np
import pandas as pd

from ..units import BAR_TO_PA, GPM_TO_M3S, PPG_TO_KGM3, PSI_TO_PA

#: (SI suffix, field suffix, factor SI→field)
FIELD_COLUMN_RULES = [
    ("_pa", "_psi", 1.0 / PSI_TO_PA),
    ("_pa", "_bar", 1.0 / BAR_TO_PA),
    ("_kg_m3", "_ppg", 1.0 / PPG_TO_KGM3),
    ("_m3_s", "_gpm", 1.0 / GPM_TO_M3S),
]


def add_field_unit_columns(df: pd.DataFrame) -> pd.DataFrame:
    """Return a copy with field-unit columns appended for every SI column."""
    out = df.copy()
    for col in df.columns:
        if not np.issubdtype(df[col].dtype, np.number):
            continue
        for si, field, factor in FIELD_COLUMN_RULES:
            if col.endswith(si) and not col.endswith("_pa_s"):
                out[col[: -len(si)] + field] = df[col] * factor
    return out


def export_dataframe(df: pd.DataFrame, path: Path, field_units: bool = True,
                     header_note: str = "") -> Path:
    """Write a DataFrame to CSV (optionally with field-unit columns and a # note line)."""
    path.parent.mkdir(parents=True, exist_ok=True)
    data = add_field_unit_columns(df) if field_units else df
    with open(path, "w", encoding="utf-8", newline="") as fh:
        if header_note:
            fh.write(f"# {header_note}\n")
        data.to_csv(fh, index=False)
    return path


def _jsonable(value):
    if isinstance(value, (np.floating, np.integer)):
        return value.item()
    if isinstance(value, np.bool_):
        return bool(value)
    if isinstance(value, float) and not np.isfinite(value):
        return None
    return value


def export_json(data: Dict, path: Path) -> Path:
    """Write a flat dictionary to pretty JSON (NaN → null)."""
    path.parent.mkdir(parents=True, exist_ok=True)
    clean = {k: _jsonable(v) for k, v in data.items()}
    path.write_text(json.dumps(clean, indent=2), encoding="utf-8")
    return path


def export_steady_state(result, output_dir: Path, note: str) -> Dict[str, Path]:
    """Export all steady-state tables: summary, breakdown, profile, segments."""
    output_dir.mkdir(parents=True, exist_ok=True)
    summary = result.summary()
    paths = {
        "summary": export_json({**summary, "data_status": note}, output_dir / "steady_state_summary.json"),
        "breakdown": export_dataframe(result.pressure_breakdown(),
                                      output_dir / "pressure_breakdown.csv", header_note=note),
        "profile": export_dataframe(result.profile, output_dir / "pressure_profile.csv",
                                    header_note=note),
        "segments": export_dataframe(result.segment_table(), output_dir / "segments.csv",
                                     header_note=note),
    }
    return paths


def export_simulation(result, output_dir: Path) -> Dict[str, Path]:
    """Export a dynamic run: time series, profiles vs time, metrics."""
    output_dir.mkdir(parents=True, exist_ok=True)
    note = f"{result.name}: {result.description} | {result.data_label}"
    paths = {
        "timeseries": export_dataframe(result.timeseries, output_dir / "timeseries.csv",
                                       header_note=note),
        "metrics": export_json({**result.metrics, "scenario": result.name,
                                "controller_enabled": result.controller_enabled,
                                "actuation": result.actuation,
                                "data_status": result.data_label},
                               output_dir / "metrics.json"),
    }
    if not result.profiles.empty:
        paths["profiles"] = export_dataframe(result.profiles,
                                             output_dir / "pressure_profiles_vs_time.csv",
                                             field_units=False, header_note=note)
    if result.events:
        (output_dir / "events.log").write_text("\n".join(result.events) + "\n", encoding="utf-8")
    return paths
