"""Configuration loading and result export."""
