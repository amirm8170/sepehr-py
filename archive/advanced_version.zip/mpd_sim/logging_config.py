"""Central logging configuration for the simulator."""

from __future__ import annotations

import logging
from typing import Optional

LOG_FORMAT = "%(levelname)-7s %(name)s: %(message)s"


def setup_logging(level: str = "INFO", log_file: Optional[str] = None) -> None:
    """
    Configure root logging once for CLI/example scripts.

    Parameters
    ----------
    level : str
        Logging level name ("DEBUG", "INFO", "WARNING", ...).
    log_file : str, optional
        If given, log messages are also written to this file.
    """
    handlers = [logging.StreamHandler()]
    if log_file:
        handlers.append(logging.FileHandler(log_file, mode="w"))
    logging.basicConfig(level=getattr(logging, level.upper(), logging.INFO),
                        format=LOG_FORMAT, handlers=handlers, force=True)
    # Matplotlib is chatty at DEBUG level.
    logging.getLogger("matplotlib").setLevel(logging.WARNING)
