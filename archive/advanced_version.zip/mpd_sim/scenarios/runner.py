"""
Scenario assembly and execution.

Builds, from ``base_case.yaml`` + one entry of ``scenarios.yaml``:
the steady-state solver, operational schedules, dynamic model, actuator and
(optionally) the PID controller; runs the simulation; exports CSV/JSON and
plots.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Dict, List, Optional

from ..dynamics.dynamic_model import (FrictionTable, LumpedMPDModel,
                                      QuasiSteadyModel)
from ..dynamics.pid import PIDController
from ..dynamics.schedules import (ConstantSchedule, OffsetSchedule,
                                  OperationalSchedule, PiecewiseLinearSchedule,
                                  Schedule, make_schedule)
from ..dynamics.simulator import Actuator, DynamicSimulator, SimulationResult
from ..io import exporters
from ..io.loaders import (SimulationSetup, build_setup, deep_merge,
                          find_unit_key, load_yaml, read_quantity)
from ..units import emw_to_pressure, to_si
from ..visualization import plots

logger = logging.getLogger(__name__)

STEADY_STATE = "steady_state"
DATA_NOTE = "Synthetic demonstration data — not field or experimental validation."


# ---------------------------------------------------------------------------
# Configuration helpers
# ---------------------------------------------------------------------------
def load_scenario_catalog(path) -> Dict[str, Any]:
    """Read scenarios.yaml → {'aliases': {...}, 'scenarios': {...}}."""
    cat = load_yaml(path)
    cat.setdefault("aliases", {})
    cat.setdefault("scenarios", {})
    return cat


def resolve_scenario_names(name: str, catalog: Dict[str, Any]) -> List[str]:
    """Map a CLI name (scenario, alias, 'all') to scenario names."""
    if name == "all":
        return [STEADY_STATE] + list(catalog["scenarios"])
    name = catalog["aliases"].get(name, name)
    if name != STEADY_STATE and name not in catalog["scenarios"]:
        raise KeyError(f"Unknown scenario '{name}'. Available: "
                       f"{[STEADY_STATE] + list(catalog['scenarios'])} "
                       f"and aliases {list(catalog['aliases'])}.")
    return [name]


def scenario_config(base: Dict[str, Any], scenario: Dict[str, Any]) -> Dict[str, Any]:
    """Merge the scenario's section overrides into the base configuration."""
    overrides = {k: v for k, v in scenario.items()
                 if k in ("operations", "dynamics", "controller", "mud", "choke",
                          "pressure_window", "numerics", "back_pressure_actuator")}
    return deep_merge(base, overrides)


def _schedule_from(cfg: Dict[str, Any], base: str, kind: str, default: float) -> Schedule:
    unit = find_unit_key(cfg, base, kind)
    if unit is None:
        return ConstantSchedule(default)
    points = [[float(t), to_si(float(v), unit, kind)] for t, v in cfg[f"{base}_{unit}"]]
    return make_schedule(points, default)


def build_schedule(setup: SimulationSetup, sched_cfg: Dict[str, Any]) -> OperationalSchedule:
    """Operational schedules (SI) from the scenario 'schedules' block."""
    c = setup.conditions
    sbp0 = (c.surface_back_pressure if c.back_pressure_mode == "specified"
            else setup.solver.surface_back_pressure(c))
    if "choke_opening_delta_frac" in sched_cfg:
        choke: Schedule = OffsetSchedule(
            c.choke_opening, PiecewiseLinearSchedule.from_points(sched_cfg["choke_opening_delta_frac"]))
    else:
        choke = make_schedule(sched_cfg.get("choke_opening_frac"), c.choke_opening)
    if "target_bhp_emw_ppg" in sched_cfg or "target_bhp_emw_kg_m3" in sched_cfg:
        unit = "ppg" if "target_bhp_emw_ppg" in sched_cfg else "kg_m3"
        tvd = setup.well.td_tvd
        points = [[float(t), emw_to_pressure(to_si(float(v), unit, "density"), tvd)]
                  for t, v in sched_cfg[f"target_bhp_emw_{unit}"]]
        target: Schedule = PiecewiseLinearSchedule.from_points(points)
    else:
        target = _schedule_from(sched_cfg, "target_bhp", "pressure", setup.window.target_bhp)
    return OperationalSchedule(
        pump_rate=_schedule_from(sched_cfg, "pump_rate", "flow_rate", c.pump_rate),
        choke_opening=choke,
        surface_back_pressure=_schedule_from(sched_cfg, "surface_back_pressure", "pressure", sbp0),
        backpressure_pump_rate=_schedule_from(sched_cfg, "backpressure_pump_rate", "flow_rate",
                                              c.backpressure_pump_rate),
        pipe_velocity=_schedule_from(sched_cfg, "pipe_velocity", "velocity", c.pipe_velocity),
        target_bhp=target)


def build_dynamic_model(setup: SimulationSetup, schedule: OperationalSchedule):
    """Friction table + dynamic model (lumped or quasi-steady) from config."""
    dyn = setup.config.get("dynamics", {})
    actuation = dyn.get("actuation", "choke")
    c = setup.conditions
    q_max = max(schedule.max_flow(), c.pump_rate, 1e-3) * float(
        dyn.get("friction_table_max_factor", 2.0))
    table = FrictionTable(setup.solver, q_max, int(dyn.get("friction_table_points", 161)),
                          schedule.pipe_velocities(), c.pipe_end, c.clinging_constant)
    bp_cfg = setup.config.get("back_pressure_actuator", {})
    tau = read_quantity(bp_cfg, "time_constant", "time", default=2.0)
    kind = dyn.get("model", "lumped")
    if kind == "quasi_steady":
        return QuasiSteadyModel(setup.solver, setup.choke, table, actuation, c.pipe_end,
                                c.choke_downstream_pressure, tau)
    if kind == "lumped":
        params = LumpedMPDModel.parameters_from(
            setup.solver, read_quantity(dyn, "surface_line_volume", "volume", default=0.0),
            c.choke_downstream_pressure, tau)
        return LumpedMPDModel(setup.solver, setup.choke, table, params, actuation,
                              c.pipe_end, dyn.get("ode_method", "LSODA"))
    raise ValueError("dynamics.model must be 'lumped' or 'quasi_steady' "
                     "(the distributed transient model is a future extension).")


def build_actuator(setup: SimulationSetup, actuation: str) -> Actuator:
    """Choke-opening or SBP actuator with range and rate limits from config."""
    if actuation == "choke":
        ch = setup.config["choke"]
        return Actuator(minimum=setup.choke.min_opening, maximum=setup.choke.max_opening,
                        rate_limit=ch.get("max_rate_frac_per_s"))
    bp = setup.config.get("back_pressure_actuator", {})
    return Actuator(minimum=read_quantity(bp, "min", "pressure", default=0.0),
                    maximum=read_quantity(bp, "max", "pressure", default=1.0e8),
                    rate_limit=read_quantity(bp, "max_rate", "pressure_rate", required=False))


def build_controller(setup: SimulationSetup, actuator: Actuator,
                     actuation: str) -> Optional[PIDController]:
    """PID controller from config (None when disabled)."""
    cfg = setup.config.get("controller", {})
    if not cfg.get("enabled", False):
        return None
    error_scale = to_si(1.0, cfg.get("error_unit", "bar"), "pressure")
    gains = cfg if actuation == "choke" else cfg.get("back_pressure_gains", cfg)
    # For SBP actuation the gains are given as "bar of SBP per bar of error";
    # the output is in Pa, hence the multiplication by error_scale.
    out_scale = 1.0 if actuation == "choke" else error_scale
    reverse = cfg.get("reverse_acting", "auto")
    reverse_acting = (actuation == "choke") if reverse == "auto" else bool(reverse)
    return PIDController(
        kp=float(gains["kp"]) * out_scale, ki=float(gains.get("ki", 0.0)) * out_scale,
        kd=float(gains.get("kd", 0.0)) * out_scale,
        output_min=actuator.minimum, output_max=actuator.maximum,
        rate_limit=actuator.rate_limit, reverse_acting=reverse_acting,
        error_scale=error_scale,
        derivative_filter_time=float(cfg.get("derivative_filter_time_s", 0.0)),
        derivative_on=cfg.get("derivative_on", "measurement"),
        anti_windup=cfg.get("anti_windup", "clamping"))


# ---------------------------------------------------------------------------
# Execution
# ---------------------------------------------------------------------------
def run_steady_state(setup: SimulationSetup, output_dir: Path):
    """Solve and export the steady-state base case."""
    result = setup.solver.solve(setup.conditions, setup.window)
    out = Path(output_dir) / STEADY_STATE
    exporters.export_steady_state(result, out, DATA_NOTE)
    plots.plot_pressure_profile(result, out / "pressure_profile.png", setup.window)
    plots.plot_pressure_breakdown(result, out / "pressure_breakdown.png")
    logger.info("Steady state: BHP %.2f bar, SPP %.2f bar, SBP %.2f bar, status %s.",
                result.bhp / 1e5, result.spp / 1e5, result.surface_back_pressure / 1e5,
                result.window_status)
    return result


def build_simulator(base_config: Dict[str, Any], name: str, scenario: Dict[str, Any],
                    base_dir: Optional[Path] = None) -> DynamicSimulator:
    """Assemble a DynamicSimulator for one scenario."""
    config = scenario_config(base_config, scenario)
    setup = build_setup(config, base_dir)
    schedule = build_schedule(setup, scenario.get("schedules", {}))
    model = build_dynamic_model(setup, schedule)
    actuator = build_actuator(setup, model.actuation)
    controller = build_controller(setup, actuator, model.actuation)
    dyn = config.get("dynamics", {})
    tol = read_quantity(config.get("controller", {}), "settling_tolerance", "pressure",
                        default=1.0e5)
    return DynamicSimulator(
        model=model, schedule=schedule, window=setup.window, actuator=actuator,
        dt=read_quantity(dyn, "dt", "time", default=0.1),
        duration=float(scenario["duration_s"]), controller=controller,
        profile_interval=read_quantity(dyn, "profile_interval", "time", default=10.0),
        settling_tolerance=tol, event_time=scenario.get("event_time_s", 0.0),
        name=name, description=scenario.get("description", ""))


def plot_simulation(result: SimulationResult, sim: DynamicSimulator, out: Path) -> None:
    """Write the standard set of dynamic plots for one run."""
    ts, title = result.timeseries, result.description
    plots.plot_bhp_vs_time(ts, out / "bhp_vs_time.png", title)
    plots.plot_spp_vs_time(ts, out / "spp_vs_time.png", title)
    plots.plot_ecd_vs_time(ts, out / "ecd_vs_time.png", sim.model.density,
                           sim.model.td_tvd, title)
    plots.plot_pump_rate_vs_bhp(ts, out / "pump_rate_vs_bhp.png", title)
    plots.plot_choke_response(ts, out / "choke_response.png", result.actuation, title)
    plots.plot_window_status(ts, out / "window_status.png", title)
    if result.controller_enabled:
        plots.plot_pid_response(ts, out / "pid_response.png", result.metrics, title)
    if not result.profiles.empty:
        plots.plot_profiles_vs_time(result.profiles, out / "pressure_profile_vs_time.png", title)


def run_dynamic_scenario(base_config: Dict[str, Any], name: str, scenario: Dict[str, Any],
                         output_dir: Path, base_dir: Optional[Path] = None,
                         make_plots: bool = True) -> SimulationResult:
    """Build, run, export and plot one dynamic scenario."""
    sim = build_simulator(base_config, name, scenario, base_dir)
    result = sim.run()
    out = Path(output_dir) / name
    exporters.export_simulation(result, out)
    if make_plots:
        plot_simulation(result, sim, out)
    return result


def run_named(name: str, config_path, scenarios_path, output_dir,
              make_plots: bool = True) -> Dict[str, Any]:
    """Run 'steady_state', a dynamic scenario, an alias or 'all'."""
    base_config = load_yaml(config_path)
    base_dir = Path(config_path).resolve().parent.parent
    catalog = load_scenario_catalog(scenarios_path)
    results: Dict[str, Any] = {}
    for scen in resolve_scenario_names(name, catalog):
        if scen == STEADY_STATE:
            results[scen] = run_steady_state(build_setup(base_config, base_dir), Path(output_dir))
        else:
            results[scen] = run_dynamic_scenario(base_config, scen, catalog["scenarios"][scen],
                                                 Path(output_dir), base_dir, make_plots)
    return results
