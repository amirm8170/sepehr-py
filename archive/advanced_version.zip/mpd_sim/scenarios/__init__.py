"""Ready-to-run steady-state and dynamic scenarios."""
