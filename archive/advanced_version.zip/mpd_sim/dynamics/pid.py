"""
Discrete PID controller for BHP control.

Control law (positional form, sample time dt):

    e_k   = s · (BHP_target − BHP_measured) / e_scale
            s = +1 direct acting, −1 reverse acting
    P_k   = Kp e_k
    I_k   = Ki Σ e dt                       (with anti-windup)
    D_k   = Kd de/dt  (filtered)            (on measurement by default)
    u_k   = bias + P_k + I_k + D_k
    u_k  ← clip(u_k, u_min, u_max)          output saturation
    u_k  ← clip(u_k, u_{k-1} − r dt, u_{k-1} + r dt)   actuator rate limit

Action direction
----------------
* Choke actuation: closing the choke (u ↓) RAISES BHP → reverse acting.
* Back-pressure actuation: raising SBP raises BHP → direct acting.

Error scaling
-------------
``error_scale`` [Pa] expresses the error in engineering units (e.g. 1e5 to
tune gains "per bar"); the controller is otherwise unit-agnostic.

Anti-windup options
-------------------
* "clamping"         (conditional integration): the integral is frozen
                     while the output is limited and the error would drive it
                     further into the limit.
* "back_calculation" : dI/dt = e + (u_applied − u_unlimited)/(Ki·T_t).
* "none"             : plain integrator (for comparison only).

Derivative protection
---------------------
* derivative on measurement avoids the "derivative kick" on setpoint steps;
* first-order filter with time constant T_f limits noise amplification;
* derivative is zero on the first sample after reset.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import numpy as np

ANTI_WINDUP_MODES = ("clamping", "back_calculation", "none")
DERIVATIVE_MODES = ("measurement", "error")


@dataclass
class PIDTerms:
    """Diagnostics of the last update."""

    error: float = 0.0
    proportional: float = 0.0
    integral: float = 0.0
    derivative: float = 0.0
    unlimited_output: float = 0.0
    output: float = 0.0
    saturated: bool = False


class PIDController:
    """
    Discrete PID with saturation, rate limit, anti-windup and derivative filter.

    Parameters
    ----------
    kp, ki, kd : float
        Gains in output units per (scaled) error unit, per (unit·s), and
        per (unit/s).
    output_min, output_max : float
        Output saturation limits.
    rate_limit : float, optional
        Maximum output change per second (actuator stroke rate).
    bias : float
        Output when all terms are zero (operating point; set for bumpless start).
    reverse_acting : bool
    error_scale : float
        Divide the raw error by this value (e.g. 1e5 Pa → gains per bar).
    derivative_filter_time : float [s]
    derivative_on : "measurement" | "error"
    anti_windup : "clamping" | "back_calculation" | "none"
    tracking_time : float, optional
        T_t for back-calculation (default Kp/Ki, i.e. the integral time).
    """

    def __init__(self, kp: float, ki: float = 0.0, kd: float = 0.0,
                 output_min: float = -np.inf, output_max: float = np.inf,
                 rate_limit: Optional[float] = None, bias: float = 0.0,
                 reverse_acting: bool = False, error_scale: float = 1.0,
                 derivative_filter_time: float = 0.0,
                 derivative_on: str = "measurement", anti_windup: str = "clamping",
                 tracking_time: Optional[float] = None) -> None:
        if anti_windup not in ANTI_WINDUP_MODES:
            raise ValueError(f"anti_windup must be one of {ANTI_WINDUP_MODES}.")
        if derivative_on not in DERIVATIVE_MODES:
            raise ValueError(f"derivative_on must be one of {DERIVATIVE_MODES}.")
        if error_scale <= 0:
            raise ValueError("error_scale must be > 0.")
        if derivative_filter_time < 0:
            raise ValueError("derivative_filter_time must be >= 0.")
        self.kp, self.ki, self.kd = float(kp), float(ki), float(kd)
        self.bias = float(bias)
        self.reverse_acting = reverse_acting
        self.error_scale = float(error_scale)
        self.derivative_filter_time = float(derivative_filter_time)
        self.derivative_on = derivative_on
        self.anti_windup = anti_windup
        self.tracking_time = tracking_time
        self.set_limits(output_min, output_max, rate_limit)
        self.reset()

    # ------------------------------------------------------------------
    def set_limits(self, output_min: float, output_max: float,
                   rate_limit: Optional[float] = None) -> None:
        """Set output saturation and (optional) rate limit [output units/s]."""
        if output_min >= output_max:
            raise ValueError("output_min must be < output_max.")
        if rate_limit is not None and rate_limit <= 0:
            raise ValueError("rate_limit must be > 0.")
        self.output_min, self.output_max = float(output_min), float(output_max)
        self.rate_limit = rate_limit

    def set_gains(self, kp: float, ki: float, kd: float) -> None:
        """Change gains (integral state is kept)."""
        self.kp, self.ki, self.kd = float(kp), float(ki), float(kd)

    def reset(self, bias: Optional[float] = None) -> None:
        """Clear integral/derivative memory; optionally set a new bias."""
        if bias is not None:
            self.bias = float(bias)
        self.integral = 0.0
        self._previous_error: Optional[float] = None
        self._previous_measurement: Optional[float] = None
        self._filtered_derivative = 0.0
        self._previous_output = float(np.clip(self.bias, self.output_min, self.output_max))
        self.terms = PIDTerms(output=self._previous_output)

    # ------------------------------------------------------------------
    def _scaled_error(self, setpoint: float, measurement: float) -> float:
        sign = -1.0 if self.reverse_acting else 1.0
        return sign * (setpoint - measurement) / self.error_scale

    def _raw_derivative(self, error: float, measurement: float, dt: float) -> float:
        if self.derivative_on == "error":
            if self._previous_error is None:
                return 0.0
            return (error - self._previous_error) / dt
        if self._previous_measurement is None:
            return 0.0
        sign = -1.0 if self.reverse_acting else 1.0
        # d(e)/dt = −d(measurement)/dt for a constant setpoint
        return -sign * (measurement - self._previous_measurement) / (self.error_scale * dt)

    def _filter(self, raw: float, dt: float) -> float:
        if self.derivative_filter_time <= 0:
            return raw
        alpha = self.derivative_filter_time / (self.derivative_filter_time + dt)
        return alpha * self._filtered_derivative + (1.0 - alpha) * raw

    def _limit(self, value: float, dt: float) -> float:
        out = float(np.clip(value, self.output_min, self.output_max))
        if self.rate_limit is not None:
            step = self.rate_limit * dt
            out = float(np.clip(out, self._previous_output - step, self._previous_output + step))
        return out

    def update(self, setpoint: float, measurement: float, dt: float) -> float:
        """
        Compute the new controller output.

        Parameters
        ----------
        setpoint : float      target (e.g. BHP target [Pa])
        measurement : float   measured/calculated value [Pa]
        dt : float            sample time [s] (> 0)

        Returns
        -------
        float
            Limited controller output (e.g. choke opening or SBP command).
        """
        if dt <= 0:
            raise ValueError("dt must be > 0.")
        error = self._scaled_error(setpoint, measurement)
        derivative = self._filter(self._raw_derivative(error, measurement, dt), dt)
        candidate_integral = self.integral + error * dt
        p_term, d_term = self.kp * error, self.kd * derivative
        unlimited = self.bias + p_term + self.ki * candidate_integral + d_term
        output = self._limit(unlimited, dt)
        limited = not np.isclose(output, unlimited)
        self.integral = self._anti_windup(candidate_integral, error, unlimited, output,
                                          limited, dt)

        self._previous_error = error
        self._previous_measurement = measurement
        self._filtered_derivative = derivative
        self._previous_output = output
        self.terms = PIDTerms(error=error, proportional=p_term,
                              integral=self.ki * self.integral, derivative=d_term,
                              unlimited_output=unlimited, output=output, saturated=limited)
        return output

    def _anti_windup(self, candidate: float, error: float, unlimited: float,
                     output: float, limited: bool, dt: float) -> float:
        if self.anti_windup == "none" or not limited or self.ki == 0:
            return candidate
        if self.anti_windup == "clamping":
            pushing_further = np.sign(error) == np.sign(unlimited - output)
            return self.integral if pushing_further else candidate
        # back-calculation
        tt = self.tracking_time or (self.kp / self.ki if self.kp > 0 else 1.0)
        return candidate + (output - unlimited) / (self.ki * tt) * dt
