"""
Time-stepping simulation driver.

Per time step (dt):
    1. read scheduled operational inputs (pump, choke, SBP, BPP, pipe velocity)
    2. if control is enabled: error = target − measured BHP → PID → command
    3. apply actuator limits (range, stroke rate)
    4. advance the dynamic hydraulic model (solve hydraulics)
    5. compute BHP, SPP, ECD; classify against the pressure window
    6. store results (and full depth profiles every ``profile_interval``)

Measurement assumption: the controller sees the model BHP of the previous
step (ideal downhole measurement, one-sample delay). PWD telemetry delay
and sensor noise are not modelled (future extension).
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional

import numpy as np
import pandas as pd

from .dynamic_model import DynamicHydraulicModel, DynamicOutput
from .performance import compute_control_metrics
from .pid import PIDController
from .pressure_window import STATUS_SAFE, classify_bhp, margin_flags
from .schedules import DynamicInputs, OperationalSchedule
from ..models.operations import PressureWindow

logger = logging.getLogger(__name__)


@dataclass
class Actuator:
    """
    Position-limited, rate-limited actuator (choke opening or SBP command).

    position is moved toward the command by at most ``rate_limit × dt``.
    """

    minimum: float
    maximum: float
    rate_limit: Optional[float]
    position: float = 0.0

    def __post_init__(self) -> None:
        if self.minimum >= self.maximum:
            raise ValueError("Actuator minimum must be < maximum.")
        self.position = float(np.clip(self.position, self.minimum, self.maximum))

    def move(self, command: float, dt: float) -> float:
        target = float(np.clip(command, self.minimum, self.maximum))
        if self.rate_limit is not None and dt > 0:
            step = self.rate_limit * dt
            target = float(np.clip(target, self.position - step, self.position + step))
        self.position = target
        return target


@dataclass
class SimulationResult:
    """Results of one dynamic run."""

    name: str
    description: str
    timeseries: pd.DataFrame
    profiles: pd.DataFrame
    metrics: Dict[str, float]
    controller_enabled: bool
    actuation: str
    data_label: str = "Synthetic demonstration — not field data"
    events: List[str] = field(default_factory=list)


class DynamicSimulator:
    """
    Runs a dynamic scenario with an optional closed-loop controller.

    Parameters
    ----------
    model : DynamicHydraulicModel
    schedule : OperationalSchedule
    window : PressureWindow
    actuator : Actuator     choke opening [-] or SBP command [Pa]
    dt, duration : float [s]
    controller : PIDController, optional
    profile_interval : float [s]
    settling_tolerance : float [Pa]
    event_time : float or list of float [s]
        Disturbance / setpoint-change times. Overall metrics use the first;
        with several events, metrics are also computed for every interval
        [event_k, event_k+1) and stored as ``event<k>_<metric>``.
    """

    def __init__(self, model: DynamicHydraulicModel, schedule: OperationalSchedule,
                 window: PressureWindow, actuator: Actuator, dt: float, duration: float,
                 controller: Optional[PIDController] = None,
                 profile_interval: float = 10.0, settling_tolerance: float = 1.0e5,
                 event_time=0.0, name: str = "scenario",
                 description: str = "") -> None:
        if dt <= 0 or duration <= 0:
            raise ValueError("dt and duration must be > 0.")
        self.model = model
        self.schedule = schedule
        self.window = window
        self.actuator = actuator
        self.dt = dt
        self.duration = duration
        self.controller = controller
        self.profile_interval = profile_interval
        self.settling_tolerance = settling_tolerance
        events = np.atleast_1d(np.asarray(event_time, dtype=float))
        self.event_times = np.sort(events)
        self.event_time = float(self.event_times[0])
        self.name = name
        self.description = description
        self._rows: List[Dict] = []
        self._profiles: List[pd.DataFrame] = []
        self._events: List[str] = []
        self._last_status = STATUS_SAFE
        self._last_regime: Optional[str] = None
        self._near_frac_logged = False

    # ------------------------------------------------------------------
    @property
    def actuation(self) -> str:
        return self.model.actuation

    def _scheduled_command(self, inputs: DynamicInputs) -> float:
        return inputs.choke_opening if self.actuation == "choke" else inputs.sbp_command

    def _with_command(self, inputs: DynamicInputs, value: float) -> DynamicInputs:
        if self.actuation == "choke":
            inputs.choke_opening = value
        else:
            inputs.sbp_command = value
        return inputs

    def _command(self, t: float, inputs: DynamicInputs, measured_bhp: float,
                 target: float) -> float:
        """Controller output (closed loop) or scheduled value (open loop)."""
        if self.controller is None:
            return self._scheduled_command(inputs)
        return self.controller.update(target, measured_bhp, self.dt)

    # ------------------------------------------------------------------
    def run(self, on_progress: Optional[Callable[[float], None]] = None) -> SimulationResult:
        """
        Execute the simulation loop and return results.

        Parameters
        ----------
        on_progress : callable, optional
            Called with the completed fraction (0–1) about 100 times per run
            (used by the UI progress bar).
        """
        n_steps = int(round(self.duration / self.dt))
        times = np.arange(n_steps + 1) * self.dt
        logger.info("Simulation started: '%s' (%d steps, dt = %.3g s, model %s, "
                    "actuation %s, control %s).", self.name, n_steps, self.dt,
                    type(self.model).__name__, self.actuation,
                    "ON" if self.controller else "OFF")
        inputs = self.schedule.inputs_at(0.0)
        self.actuator.position = self._scheduled_command(inputs)
        if self.controller is not None:
            self.controller.reset(bias=self.actuator.position)
        out = self.model.initialize(self._with_command(inputs, self.actuator.position))
        self._record(0.0, inputs, out)
        next_profile = 0.0
        next_profile = self._maybe_store_profile(0.0, inputs, out, next_profile)

        report_every = max(1, n_steps // 100)
        for k, t in enumerate(times[1:], start=1):
            if on_progress is not None and k % report_every == 0:
                on_progress(k / n_steps)
            inputs = self.schedule.inputs_at(t)
            target = self.schedule.target_bhp(t)
            command = self._command(t, inputs, out.bhp, target)
            applied = self.actuator.move(command, self.dt)
            inputs = self._with_command(inputs, applied)
            out = self.model.step(inputs, self.dt)
            self._record(t, inputs, out, command)
            next_profile = self._maybe_store_profile(t, inputs, out, next_profile)

        ts = pd.DataFrame(self._rows)
        metrics = self._metrics(ts)
        logger.info("Simulation finished: '%s' — BHP range %.1f–%.1f bar, time outside "
                    "window %.1f s.", self.name, metrics["min_bhp_pa"] / 1e5,
                    metrics["max_bhp_pa"] / 1e5, metrics["time_outside_window_s"])
        profiles = (pd.concat(self._profiles, ignore_index=True)
                    if self._profiles else pd.DataFrame())
        return SimulationResult(name=self.name, description=self.description,
                                timeseries=ts, profiles=profiles, metrics=metrics,
                                controller_enabled=self.controller is not None,
                                actuation=self.actuation, events=self._events)

    # ------------------------------------------------------------------
    def _metrics(self, ts: pd.DataFrame) -> Dict[str, float]:
        """Overall metrics from the first event plus per-event-interval metrics."""
        def window_metrics(frame: pd.DataFrame, t0: float) -> Dict[str, float]:
            return compute_control_metrics(
                frame["time_s"], frame["bhp_pa"], frame["target_bhp_pa"],
                frame["window_status"], self.settling_tolerance, t0,
                initial_bhp=float(np.interp(t0, frame["time_s"], frame["bhp_pa"])))

        metrics = window_metrics(ts, self.event_time)
        if self.event_times.size > 1:
            bounds = np.append(self.event_times, np.inf)
            for k, (t0, t1) in enumerate(zip(bounds[:-1], bounds[1:]), start=1):
                frame = ts[(ts["time_s"] >= t0) & (ts["time_s"] < t1)]
                if len(frame) < 2:
                    continue
                for key, value in window_metrics(frame, t0).items():
                    metrics[f"event{k}_{key}"] = value
                metrics[f"event{k}_time_s"] = float(t0)
        return metrics

    def _record(self, t: float, inputs: DynamicInputs, out: DynamicOutput,
                command: Optional[float] = None) -> None:
        target = self.schedule.target_bhp(t)
        status = classify_bhp(out.bhp, self.window)
        near_pore, near_frac = margin_flags(out.bhp, self.window)
        terms = self.controller.terms if self.controller is not None else None
        self._rows.append({
            "time_s": t,
            "pump_rate_m3_s": inputs.pump_rate,
            "backpressure_pump_rate_m3_s": inputs.backpressure_pump_rate,
            "pipe_velocity_m_s": inputs.pipe_velocity,
            "choke_opening": inputs.choke_opening if self.actuation == "choke" else np.nan,
            "sbp_command_pa": inputs.sbp_command if self.actuation == "back_pressure" else np.nan,
            "actuator_command": self.actuator.position if command is None else command,
            "q_bit_m3_s": out.q_bit, "q_choke_m3_s": out.q_choke,
            "sbp_pa": out.sbp, "spp_pa": out.spp, "bhp_pa": out.bhp,
            "annulus_friction_pa": out.annulus_friction,
            "string_friction_pa": out.string_friction,
            "bit_pressure_drop_pa": out.bit_pressure_drop,
            "ecd_conventional_kg_m3": out.ecd_conventional,
            "emw_bhp_kg_m3": out.emw_bhp,
            "target_bhp_pa": target,
            "pore_pressure_pa": self.window.pore_pressure,
            "fracture_pressure_pa": self.window.fracture_pressure,
            "window_status": status, "near_pore": near_pore, "near_fracture": near_frac,
            "control_error_pa": target - out.bhp,
            "pid_p": terms.proportional if terms else np.nan,
            "pid_i": terms.integral if terms else np.nan,
            "pid_d": terms.derivative if terms else np.nan,
            "pid_saturated": terms.saturated if terms else False,
            "annulus_turbulent_fraction": out.annulus_turbulent_fraction,
            "string_turbulent_fraction": out.string_turbulent_fraction,
        })
        self._log_events(t, status, near_frac, near_pore, out)

    def _log_events(self, t: float, status: str, near_frac: bool, near_pore: bool,
                    out: DynamicOutput) -> None:
        if status != self._last_status:
            msg = f"t={t:.1f} s: pressure-window status {self._last_status} -> {status}"
            (logger.warning if status != STATUS_SAFE else logger.info)(msg)
            self._events.append(msg)
            self._last_status = status
        if near_frac and not self._near_frac_logged:
            logger.warning("t=%.1f s: BHP approaching fracture pressure.", t)
            self._near_frac_logged = True
        elif not near_frac:
            self._near_frac_logged = False
        regime = "turbulent" if out.annulus_turbulent_fraction >= 0.5 else "laminar"
        if self._last_regime is not None and regime != self._last_regime:
            msg = f"t={t:.1f} s: Flow regime transition detected in annulus ({self._last_regime} -> {regime})"
            logger.warning(msg)
            self._events.append(msg)
        self._last_regime = regime

    def _maybe_store_profile(self, t: float, inputs: DynamicInputs, out: DynamicOutput,
                             next_time: float) -> float:
        """Store quasi-steady depth profiles reconstructed at the current state."""
        if t + 1e-9 < next_time:
            return next_time
        solver = self.model.solver
        _, dp_a, _ = solver.annulus_hydraulics(out.q_bit, inputs.pipe_velocity)
        _, dp_s = solver.string_hydraulics(out.q_bit)
        ann = solver.annulus_pressure_profile(out.sbp, dp_a)
        st = solver.string_pressure_profile(out.spp, dp_s)
        prof = pd.concat([st, ann], ignore_index=True)
        prof.insert(0, "time_s", t)
        self._profiles.append(prof)
        return next_time + self.profile_interval
