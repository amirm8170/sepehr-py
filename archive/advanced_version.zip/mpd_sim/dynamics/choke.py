"""
MPD choke model.

Relationship used (incompressible orifice/valve equation, category B form;
the specific characteristic curve is a MODELING CHOICE REQUIRING VALIDATION):

    Q = K(u) · sqrt(ΔP / ρ)        ⇔        ΔP = ρ (Q / K(u))²

    Q  : volumetric flow through the choke [m³/s]
    ΔP : P_upstream − P_downstream [Pa]
    ρ  : mud density [kg/m³]
    u  : choke opening [-], 0 = closed, 1 = fully open
    K  : SI flow coefficient [m²]  (K = C_d A_eff √2)

Industry Cv convention (US units)  Q[gpm] = Cv · sqrt(ΔP[psi] / SG)
converts to SI as   K = Cv × CV_US_TO_SI,
    CV_US_TO_SI = (gpm→m³/s) × sqrt(1000 / (psi→Pa)) ≈ 2.4027e-5 m².

The choke characteristic K(u) is NOT universal. Three interchangeable curves
are provided:
    LinearCharacteristic          Cv = Cv_leak + (Cv_max − Cv_leak) u
    EqualPercentageCharacteristic Cv = Cv_max R^(u−1)
    TabulatedCharacteristic       user / measured (u, Cv) table, linear interp.
A physically based choke model (e.g. two-phase or cavitating flow, trim
geometry) can be added by subclassing ``ChokeModel``.

Numerical regularisation: √ΔP has infinite slope at ΔP = 0, which makes the
ODE stiff when pumps stop. Below ``linearization_dp`` the relation is
replaced by a linear one through the same end point (documented assumption).
Reverse flow through the choke is not allowed (Q >= 0; a non-return is
assumed).
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Sequence

import numpy as np

from ..units import GPM_TO_M3S, PSI_TO_PA

#: Conversion of US Cv [gpm/sqrt(psi)] to SI K [m²] for Q = K sqrt(ΔP/ρ).
CV_US_TO_SI: float = GPM_TO_M3S * np.sqrt(1000.0 / PSI_TO_PA)


def cv_us_to_si(cv: float) -> float:
    """US flow coefficient Cv [gpm/√psi] → SI K [m²]."""
    return cv * CV_US_TO_SI


class ChokeCharacteristic(ABC):
    """Maps choke opening u ∈ [0, 1] to the US flow coefficient Cv."""

    @abstractmethod
    def cv(self, opening: float) -> float:
        """Flow coefficient Cv(u) [gpm/√psi]."""

    def flow_coefficient(self, opening: float) -> float:
        """SI flow coefficient K(u) [m²]."""
        return cv_us_to_si(self.cv(opening))


@dataclass
class LinearCharacteristic(ChokeCharacteristic):
    """Linear trim: Cv(u) = Cv_leak + (Cv_max − Cv_leak) u."""

    cv_max: float
    cv_leak: float = 0.0

    def __post_init__(self) -> None:
        if self.cv_max <= 0 or self.cv_leak < 0 or self.cv_leak >= self.cv_max:
            raise ValueError("Require 0 <= cv_leak < cv_max.")

    def cv(self, opening: float) -> float:
        u = float(np.clip(opening, 0.0, 1.0))
        return self.cv_leak + (self.cv_max - self.cv_leak) * u


@dataclass
class EqualPercentageCharacteristic(ChokeCharacteristic):
    """Equal-percentage trim: Cv(u) = Cv_max R^(u−1), rangeability R > 1."""

    cv_max: float
    rangeability: float = 50.0

    def __post_init__(self) -> None:
        if self.cv_max <= 0 or self.rangeability <= 1:
            raise ValueError("Require cv_max > 0 and rangeability > 1.")

    def cv(self, opening: float) -> float:
        u = float(np.clip(opening, 0.0, 1.0))
        return self.cv_max * self.rangeability ** (u - 1.0)


class TabulatedCharacteristic(ChokeCharacteristic):
    """User-defined or measured characteristic, linear interpolation of Cv(u)."""

    def __init__(self, openings: Sequence[float], cvs: Sequence[float]) -> None:
        u = np.asarray(openings, dtype=float)
        c = np.asarray(cvs, dtype=float)
        if u.size < 2 or u.size != c.size:
            raise ValueError("Choke table needs >= 2 (opening, Cv) pairs of equal length.")
        if np.any(np.diff(u) <= 0) or u[0] < 0 or u[-1] > 1:
            raise ValueError("Choke table openings must increase within [0, 1].")
        if np.any(c < 0) or np.any(np.diff(c) < 0):
            raise ValueError("Choke table Cv must be >= 0 and non-decreasing.")
        self.openings = u
        self.cvs = c

    def cv(self, opening: float) -> float:
        return float(np.interp(opening, self.openings, self.cvs))


class ChokeModel(ABC):
    """Interface of a choke model used by the hydraulics and dynamic models."""

    min_opening: float = 0.0
    max_opening: float = 1.0

    @abstractmethod
    def flow_rate(self, opening: float, pressure_drop: float, density: float) -> float:
        """Flow through the choke Q [m³/s] for a given ΔP [Pa]."""

    @abstractmethod
    def pressure_drop(self, opening: float, flow_rate: float, density: float) -> float:
        """ΔP [Pa] required to pass flow Q [m³/s]."""

    def clamp_opening(self, opening: float) -> float:
        """Limit an opening command to the actuator range."""
        return float(np.clip(opening, self.min_opening, self.max_opening))


class SimpleCvChoke(ChokeModel):
    """
    Valve-equation choke with a configurable characteristic.

    Parameters
    ----------
    characteristic : ChokeCharacteristic
    min_opening, max_opening : float [-]  actuator range
    linearization_dp : float [Pa]          see module docstring
    """

    def __init__(self, characteristic: ChokeCharacteristic, min_opening: float = 0.0,
                 max_opening: float = 1.0, linearization_dp: float = 1.0e4) -> None:
        if not 0 <= min_opening < max_opening <= 1:
            raise ValueError("Require 0 <= min_opening < max_opening <= 1.")
        if linearization_dp <= 0:
            raise ValueError("linearization_dp must be > 0.")
        self.characteristic = characteristic
        self.min_opening = min_opening
        self.max_opening = max_opening
        self.linearization_dp = linearization_dp

    def _k(self, opening: float) -> float:
        k = self.characteristic.flow_coefficient(self.clamp_opening(opening))
        if k <= 0:
            raise ValueError("Choke flow coefficient is zero (fully closed, no leakage): "
                             "pressure would be unbounded. Set cv_leak or min_opening > 0.")
        return k

    def flow_rate(self, opening: float, pressure_drop: float, density: float) -> float:
        dp = max(pressure_drop, 0.0)   # no reverse flow through the choke
        k = self._k(opening)
        if dp >= self.linearization_dp:
            return k * np.sqrt(dp / density)
        return k * np.sqrt(self.linearization_dp / density) * dp / self.linearization_dp

    def pressure_drop(self, opening: float, flow_rate: float, density: float) -> float:
        q = max(flow_rate, 0.0)
        k = self._k(opening)
        q_lin = k * np.sqrt(self.linearization_dp / density)
        if q >= q_lin:
            return density * (q / k) ** 2
        return self.linearization_dp * q / q_lin

    def opening_for(self, flow_rate: float, pressure_drop: float, density: float) -> float:
        """
        Opening that gives ΔP at flow Q (inverse characteristic, by bisection).

        Returns the actuator limit if the request is out of range.
        """
        lo, hi = self.min_opening, self.max_opening
        if self.pressure_drop(hi, flow_rate, density) >= pressure_drop:
            return hi
        if self.pressure_drop(lo, flow_rate, density) <= pressure_drop:
            return lo
        for _ in range(60):
            mid = 0.5 * (lo + hi)
            if self.pressure_drop(mid, flow_rate, density) > pressure_drop:
                lo = mid
            else:
                hi = mid
        return 0.5 * (lo + hi)


def build_choke(characteristic: str, cv_max: float, cv_leak: float = 0.0,
                rangeability: float = 50.0, table_openings=None, table_cvs=None,
                min_opening: float = 0.0, max_opening: float = 1.0,
                linearization_dp: float = 1.0e4) -> SimpleCvChoke:
    """Factory used by the configuration loader."""
    key = characteristic.lower()
    if key == "linear":
        curve: ChokeCharacteristic = LinearCharacteristic(cv_max, cv_leak)
    elif key == "equal_percentage":
        curve = EqualPercentageCharacteristic(cv_max, rangeability)
    elif key == "table":
        if table_openings is None or table_cvs is None:
            raise ValueError("Tabulated choke needs 'table_openings' and 'table_cvs'.")
        curve = TabulatedCharacteristic(table_openings, table_cvs)
    else:
        raise ValueError("Choke characteristic must be 'linear', 'equal_percentage' or 'table'.")
    return SimpleCvChoke(curve, min_opening, max_opening, linearization_dp)
