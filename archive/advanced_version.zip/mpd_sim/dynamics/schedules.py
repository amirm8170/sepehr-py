"""
Time schedules of operational inputs.

A schedule is a function of time. Scenarios define piecewise-linear
schedules ``[[t0, v0], [t1, v1], ...]``: linear between points, held
constant before the first and after the last point. This represents
operator ramps (pump ramp-up, choke stroke) without hidden smoothing.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Optional, Sequence

import numpy as np


class Schedule(ABC):
    """A scalar input as a function of time."""

    @abstractmethod
    def __call__(self, t: float) -> float:
        """Value at time t [s] (SI)."""

    @abstractmethod
    def values(self) -> np.ndarray:
        """All breakpoint values (used to size friction tables)."""


class ConstantSchedule(Schedule):
    """Constant value for the whole simulation."""

    def __init__(self, value: float) -> None:
        self.value = float(value)

    def __call__(self, t: float) -> float:
        return self.value

    def values(self) -> np.ndarray:
        return np.array([self.value])


class PiecewiseLinearSchedule(Schedule):
    """Piecewise-linear schedule through (time, value) points."""

    def __init__(self, times: Sequence[float], values: Sequence[float]) -> None:
        t = np.asarray(times, dtype=float)
        v = np.asarray(values, dtype=float)
        if t.size == 0 or t.size != v.size:
            raise ValueError("Schedule needs equal, non-empty time and value lists.")
        if np.any(np.diff(t) < 0):
            raise ValueError("Schedule times must be non-decreasing.")
        self.times = t
        self.vals = v

    @classmethod
    def from_points(cls, points) -> "PiecewiseLinearSchedule":
        arr = np.asarray(points, dtype=float).reshape(-1, 2)
        return cls(arr[:, 0], arr[:, 1])

    def __call__(self, t: float) -> float:
        return float(np.interp(t, self.times, self.vals))

    def values(self) -> np.ndarray:
        return self.vals.copy()


class OffsetSchedule(Schedule):
    """base_value + delta(t) — e.g. choke opening relative to the initial opening."""

    def __init__(self, base_value: float, delta: Schedule) -> None:
        self.base_value = float(base_value)
        self.delta = delta

    def __call__(self, t: float) -> float:
        return self.base_value + self.delta(t)

    def values(self) -> np.ndarray:
        return self.base_value + self.delta.values()


@dataclass
class DynamicInputs:
    """
    Operational inputs at one instant (SI).

    pump_rate              [m³/s]
    choke_opening          [-]      (used in choke actuation)
    sbp_command            [Pa]     (used in back-pressure actuation)
    backpressure_pump_rate [m³/s]
    pipe_velocity          [m/s] (+ down)
    """

    pump_rate: float
    choke_opening: float
    sbp_command: float
    backpressure_pump_rate: float = 0.0
    pipe_velocity: float = 0.0

    def __post_init__(self) -> None:
        if self.pump_rate < -1e-12:
            raise ValueError("Invalid negative flow rate in schedule.")
        self.pump_rate = max(self.pump_rate, 0.0)
        self.backpressure_pump_rate = max(self.backpressure_pump_rate, 0.0)


@dataclass
class OperationalSchedule:
    """All scheduled inputs of a scenario."""

    pump_rate: Schedule
    choke_opening: Schedule
    surface_back_pressure: Schedule
    backpressure_pump_rate: Schedule
    pipe_velocity: Schedule
    target_bhp: Schedule

    def inputs_at(self, t: float) -> DynamicInputs:
        """Scheduled (open-loop) inputs at time t."""
        return DynamicInputs(pump_rate=self.pump_rate(t),
                             choke_opening=self.choke_opening(t),
                             sbp_command=self.surface_back_pressure(t),
                             backpressure_pump_rate=self.backpressure_pump_rate(t),
                             pipe_velocity=self.pipe_velocity(t))

    def max_flow(self) -> float:
        """Largest scheduled pump + back-pressure-pump flow [m³/s]."""
        return float(np.max(self.pump_rate.values()) + np.max(self.backpressure_pump_rate.values()))

    def pipe_velocities(self) -> np.ndarray:
        """All scheduled pipe velocities [m/s]."""
        return self.pipe_velocity.values()


def make_schedule(points: Optional[Sequence], default: float) -> Schedule:
    """Piecewise-linear schedule from points, or a constant default."""
    if points is None:
        return ConstantSchedule(default)
    return PiecewiseLinearSchedule.from_points(points)
