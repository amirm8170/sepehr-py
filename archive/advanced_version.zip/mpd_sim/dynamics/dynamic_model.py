"""
Dynamic hydraulic models (Stage B).

Two interchangeable models share the interface ``DynamicHydraulicModel``:

1. ``QuasiSteadyModel`` — time marching through a sequence of steady states.
   At each step the steady-state hydraulics are evaluated for the current
   inputs; pressures respond instantly (no inertia, no compressibility).
   This is the "first dynamic version" in the sense of the proposal.

2. ``LumpedMPDModel`` — control-oriented lumped-parameter model of the
   type widely used for MPD controller design:
       Kaasa, G.-O., Stamnes, Ø.N., Aamo, O.M., Imsland, L.S. (2012)
       "Simplified hydraulics model used for intelligent estimation of
       downhole pressure for a managed-pressure-drilling control system",
       SPE Drilling & Completion 27(1), SPE-143097-PA.
   States: pump pressure p_p, choke (wellhead annulus) pressure p_c,
   bit flow q_b.

       (V_d/β) dp_p/dt = q_pump − q_b
       (V_a/β) dp_c/dt = q_b + q_bpp + v_p A_disp,surf − q_choke(u, p_c)
       M dq_b/dt       = p_p − p_c − ΔP_ds(q_b) − ΔP_bit(q_b) − ΔP_ann(q_b, v_p)
       BHP             = p_c + ρ g TVD_TD + ΔP_ann(q_b, v_p) + M_a dq_b/dt
       SPP             = p_p

   V_d, V_a : string (+ surface line) and annulus volumes [m³]
   β        : effective bulk modulus [Pa]
   M        = ρ (Σ L/A_string + Σ L/A_annulus)  [kg/m⁴]  fluid inertia
   Friction terms are QUASI-STEADY: they come from the Stage-A segment
   solver (pre-tabulated as functions of q_b and v_p).

   In "back_pressure" actuation the choke is treated as an ideal pressure
   regulator: dp_c/dt = (SBP_cmd − p_c)/τ_bp, and the required choke flow
   is reported from the annulus mass balance.

   Assumptions (D/E): single-phase, single-density, isothermal mud; one
   lumped pressure node per flow path (no pressure-wave propagation — wave
   transit time ≈ 2–3 s for 3 km); constant β; quasi-steady friction; no
   free-fall/U-tubing level dynamics (p_p and p_c are not allowed below
   atmospheric/downstream pressure).

A distributed transient solver (continuity + momentum PDEs) is a future
extension — see ``dynamics.transient``.
"""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Optional

import numpy as np
from scipy.integrate import solve_ivp

from ..constants import GRAVITY
from ..hydraulics.hydraulics import SteadyStateHydraulicsSolver
from ..hydraulics.pressure_loss import REGIME_TURBULENT
from .choke import ChokeModel
from .schedules import DynamicInputs

logger = logging.getLogger(__name__)

ACTUATIONS = ("choke", "back_pressure")


# ---------------------------------------------------------------------------
# Pre-tabulated quasi-steady friction
# ---------------------------------------------------------------------------
class FrictionTable:
    """
    Quasi-steady friction curves precomputed with the Stage-A solver.

    string(q)        Σ drill-string friction [Pa]   (q = bit flow, signed)
    bit(q)           bit pressure drop [Pa]
    annulus(q, v_p)  Σ annular friction [Pa]
    annulus_turbulent_fraction(q, v_p), string_turbulent_fraction(q)

    Linear interpolation between grid points. Note: linear interpolation
    between q = 0 (zero friction) and the first grid point smooths the
    Bingham yield-stress discontinuity at q → 0; this regularisation is
    intentional and its width is set by the grid resolution.
    """

    def __init__(self, solver: SteadyStateHydraulicsSolver, q_max: float,
                 n_points: int = 161, pipe_velocities: Optional[np.ndarray] = None,
                 pipe_end: str = "closed", clinging_constant: float = 0.45) -> None:
        if q_max <= 0:
            raise ValueError("Friction-table q_max must be > 0.")
        n_points = int(n_points) | 1                     # odd → q = 0 is a grid point
        self.q_grid = np.linspace(-q_max, q_max, n_points)
        vp = np.zeros(1) if pipe_velocities is None else np.asarray(pipe_velocities, float)
        if np.ptp(vp) > 0:
            vp = np.unique(np.concatenate([vp, np.linspace(vp.min(), vp.max(), 9), [0.0]]))
        self.vp_grid = np.unique(vp)
        self.q_max = q_max
        self._warned = False

        self.string_dp = np.empty(n_points)
        self.string_turb = np.empty(n_points)
        self.bit_dp = np.empty(n_points)
        self.annulus_dp = np.empty((self.vp_grid.size, n_points))
        self.annulus_turb = np.empty((self.vp_grid.size, n_points))
        for j, q in enumerate(self.q_grid):
            res_s, dp_s = solver.string_hydraulics(q)
            self.string_dp[j] = dp_s.sum()
            self.string_turb[j] = np.mean(res_s.regime == REGIME_TURBULENT)
            self.bit_dp[j] = solver.bit_pressure_drop(q)
            for i, v in enumerate(self.vp_grid):
                res_a, dp_a, _ = solver.annulus_hydraulics(q, v, pipe_end, clinging_constant)
                self.annulus_dp[i, j] = dp_a.sum()
                self.annulus_turb[i, j] = np.mean(res_a.regime == REGIME_TURBULENT)
        logger.info("Friction table built: %d flow points x %d pipe velocities "
                    "(|q| <= %.4f m³/s).", n_points, self.vp_grid.size, q_max)

    def _check(self, q: float) -> None:
        if abs(q) > self.q_max and not self._warned:
            logger.warning("Flow %.4f m³/s outside friction table (±%.4f); value clamped. "
                           "Increase dynamics.friction_table_max_factor.", q, self.q_max)
            self._warned = True

    def _interp_2d(self, table: np.ndarray, q: float, v_p: float) -> float:
        self._check(q)
        if self.vp_grid.size == 1:
            return float(np.interp(q, self.q_grid, table[0]))
        k = int(np.clip(np.searchsorted(self.vp_grid, v_p) - 1, 0, self.vp_grid.size - 2))
        v0, v1 = self.vp_grid[k], self.vp_grid[k + 1]
        w = float(np.clip((v_p - v0) / (v1 - v0), 0.0, 1.0))
        return float((1 - w) * np.interp(q, self.q_grid, table[k])
                     + w * np.interp(q, self.q_grid, table[k + 1]))

    def string(self, q: float) -> float:
        self._check(q)
        return float(np.interp(q, self.q_grid, self.string_dp))

    def bit(self, q: float) -> float:
        return float(np.interp(q, self.q_grid, self.bit_dp))

    def annulus(self, q: float, v_p: float = 0.0) -> float:
        return self._interp_2d(self.annulus_dp, q, v_p)

    def annulus_turbulent_fraction(self, q: float, v_p: float = 0.0) -> float:
        return self._interp_2d(self.annulus_turb, q, v_p)

    def string_turbulent_fraction(self, q: float) -> float:
        return float(np.interp(q, self.q_grid, self.string_turb))


# ---------------------------------------------------------------------------
# Outputs and base class
# ---------------------------------------------------------------------------
@dataclass
class DynamicOutput:
    """Hydraulic state reported at the end of a time step (SI)."""

    bhp: float
    spp: float
    sbp: float
    pump_pressure: float
    q_bit: float
    q_choke: float
    annulus_friction: float
    string_friction: float
    bit_pressure_drop: float
    ecd_conventional: float
    emw_bhp: float
    annulus_turbulent_fraction: float
    string_turbulent_fraction: float


@dataclass
class LumpedParameters:
    """Lumped-model parameters derived from geometry and mud (SI)."""

    bulk_modulus: float
    string_volume: float
    annulus_volume: float
    string_inertia: float
    annulus_inertia: float
    downstream_pressure: float = 0.0
    back_pressure_time_constant: float = 2.0

    @property
    def inertia(self) -> float:
        """Total fluid inertia M [kg/m⁴]."""
        return self.string_inertia + self.annulus_inertia


class DynamicHydraulicModel(ABC):
    """Interface of a time-domain hydraulic model."""

    def __init__(self, solver: SteadyStateHydraulicsSolver, choke: ChokeModel,
                 table: FrictionTable, actuation: str = "choke",
                 pipe_end: str = "closed", downstream_pressure: float = 0.0,
                 back_pressure_time_constant: float = 2.0) -> None:
        if actuation not in ACTUATIONS:
            raise ValueError(f"actuation must be one of {ACTUATIONS}.")
        if back_pressure_time_constant <= 0:
            raise ValueError("Back-pressure actuator time constant must be > 0.")
        self.solver = solver
        self.choke = choke
        self.table = table
        self.actuation = actuation
        self.density = solver.mud.density
        self.hydrostatic_td = solver.hydrostatic_at_td()
        self.td_tvd = solver.well.td_tvd
        self.surface_displacement_area = float(solver.displacement_area(pipe_end)[0])
        self.downstream_pressure = downstream_pressure
        self.bp_time_constant = back_pressure_time_constant

    @abstractmethod
    def initialize(self, inputs: DynamicInputs) -> DynamicOutput:
        """Set the initial (steady) state for the inputs at t = 0."""

    @abstractmethod
    def step(self, inputs: DynamicInputs, dt: float) -> DynamicOutput:
        """Advance the model by dt [s] with inputs held constant (zero-order hold)."""

    # Shared helpers --------------------------------------------------------
    def surface_inflow(self, q_bit: float, inputs: DynamicInputs) -> float:
        """Flow arriving at the wellhead: q_b + q_bpp + v_p A_disp,surf [m³/s]."""
        return (q_bit + inputs.backpressure_pump_rate
                + inputs.pipe_velocity * self.surface_displacement_area)

    def choke_pressure_steady(self, q_choke: float, opening: float) -> float:
        """p_c = P_0 + ΔP_choke(u, Q) [Pa]."""
        return self.downstream_pressure + self.choke.pressure_drop(
            opening, max(q_choke, 0.0), self.density)

    def _output(self, p_pump: float, p_choke: float, q_bit: float, q_choke: float,
                inputs: DynamicInputs, annulus_acceleration_term: float = 0.0
                ) -> DynamicOutput:
        f_a = self.table.annulus(q_bit, inputs.pipe_velocity)
        f_s = self.table.string(q_bit)
        f_b = self.table.bit(q_bit)
        bhp = p_choke + self.hydrostatic_td + f_a + annulus_acceleration_term
        return DynamicOutput(
            bhp=bhp, spp=p_pump, sbp=p_choke, pump_pressure=p_pump, q_bit=q_bit,
            q_choke=q_choke, annulus_friction=f_a, string_friction=f_s,
            bit_pressure_drop=f_b,
            ecd_conventional=self.density + f_a / (GRAVITY * self.td_tvd),
            emw_bhp=bhp / (GRAVITY * self.td_tvd),
            annulus_turbulent_fraction=self.table.annulus_turbulent_fraction(
                q_bit, inputs.pipe_velocity),
            string_turbulent_fraction=self.table.string_turbulent_fraction(q_bit))


# ---------------------------------------------------------------------------
# Quasi-steady model
# ---------------------------------------------------------------------------
class QuasiSteadyModel(DynamicHydraulicModel):
    """
    Sequence of steady states (no inertia, no compressibility).

    q_b = q_pump instantly; p_c from the choke equation (choke actuation) or
    from the first-order back-pressure actuator; SPP = p_c + Σ friction.
    """

    def initialize(self, inputs: DynamicInputs) -> DynamicOutput:
        self._p_choke = (inputs.sbp_command if self.actuation == "back_pressure"
                         else None)
        return self.step(inputs, 0.0)

    def step(self, inputs: DynamicInputs, dt: float) -> DynamicOutput:
        q_b = inputs.pump_rate
        q_choke = max(self.surface_inflow(q_b, inputs), 0.0)
        if self.actuation == "choke":
            p_c = self.choke_pressure_steady(q_choke, inputs.choke_opening)
        else:
            lag = 1.0 - np.exp(-dt / self.bp_time_constant) if dt > 0 else 0.0
            self._p_choke += (inputs.sbp_command - self._p_choke) * lag
            p_c = self._p_choke
        p_p = (p_c + self.table.annulus(q_b, inputs.pipe_velocity)
               + self.table.bit(q_b) + self.table.string(q_b))
        return self._output(p_p, p_c, q_b, q_choke, inputs)


# ---------------------------------------------------------------------------
# Lumped compressible model (Kaasa et al. 2012 type)
# ---------------------------------------------------------------------------
class LumpedMPDModel(DynamicHydraulicModel):
    """Three-state lumped MPD hydraulics model (see module docstring)."""

    def __init__(self, solver: SteadyStateHydraulicsSolver, choke: ChokeModel,
                 table: FrictionTable, params: LumpedParameters,
                 actuation: str = "choke", pipe_end: str = "closed",
                 ode_method: str = "LSODA") -> None:
        super().__init__(solver, choke, table, actuation, pipe_end,
                         params.downstream_pressure, params.back_pressure_time_constant)
        self.params = params
        self.ode_method = ode_method
        self.state = np.zeros(3)     # [p_pump, p_choke, q_bit]

    @classmethod
    def parameters_from(cls, solver: SteadyStateHydraulicsSolver,
                        surface_line_volume: float = 0.0,
                        downstream_pressure: float = 0.0,
                        back_pressure_time_constant: float = 2.0) -> LumpedParameters:
        """Derive V_d, V_a, M from the discretised geometry."""
        g = solver.grid
        rho = solver.mud.density
        return LumpedParameters(
            bulk_modulus=solver.mud.bulk_modulus,
            string_volume=solver.string_volume + surface_line_volume,
            annulus_volume=solver.annulus_volume,
            string_inertia=rho * float(np.sum(g.length / g.string_area)),
            annulus_inertia=rho * float(np.sum(g.length / g.annulus_area)),
            downstream_pressure=downstream_pressure,
            back_pressure_time_constant=back_pressure_time_constant)

    # ----------------------------------------------------------------- ODE
    def _choke_flow(self, p_c: float, inputs: DynamicInputs) -> float:
        return self.choke.flow_rate(inputs.choke_opening, p_c - self.downstream_pressure,
                                    self.density)

    def _bit_flow_derivative(self, p_p: float, p_c: float, q_b: float,
                             inputs: DynamicInputs) -> float:
        driving = (p_p - p_c - self.table.string(q_b) - self.table.bit(q_b)
                   - self.table.annulus(q_b, inputs.pipe_velocity))
        return driving / self.params.inertia

    def _rhs(self, t: float, y: np.ndarray, inputs: DynamicInputs) -> np.ndarray:
        p_p, p_c, q_b = y
        prm = self.params
        dp_p = prm.bulk_modulus / prm.string_volume * (inputs.pump_rate - q_b)
        if self.actuation == "choke":
            q_out = self._choke_flow(p_c, inputs)
            dp_c = prm.bulk_modulus / prm.annulus_volume * (
                self.surface_inflow(q_b, inputs) - q_out)
        else:
            dp_c = (inputs.sbp_command - p_c) / prm.back_pressure_time_constant
        # No sub-atmospheric pressures: column free-fall is not modelled.
        if p_p <= 0.0 and dp_p < 0.0:
            dp_p = 0.0
        if p_c <= self.downstream_pressure and dp_c < 0.0:
            dp_c = 0.0
        dq_b = self._bit_flow_derivative(p_p, p_c, q_b, inputs)
        return np.array([dp_p, dp_c, dq_b])

    # ------------------------------------------------------------ interface
    def initialize(self, inputs: DynamicInputs) -> DynamicOutput:
        """Steady equilibrium: q_b = q_pump, p_c from choke/command, p_p from friction."""
        q_b = inputs.pump_rate
        if self.actuation == "choke":
            p_c = self.choke_pressure_steady(self.surface_inflow(q_b, inputs),
                                             inputs.choke_opening)
        else:
            p_c = inputs.sbp_command
        p_p = (p_c + self.table.string(q_b) + self.table.bit(q_b)
               + self.table.annulus(q_b, inputs.pipe_velocity))
        self.state = np.array([p_p, p_c, q_b])
        logger.info("Lumped model initialised: V_d=%.1f m³, V_a=%.1f m³, β=%.2e Pa, "
                    "M=%.3e kg/m⁴.", self.params.string_volume, self.params.annulus_volume,
                    self.params.bulk_modulus, self.params.inertia)
        return self._report(inputs)

    def step(self, inputs: DynamicInputs, dt: float) -> DynamicOutput:
        sol = solve_ivp(self._rhs, (0.0, dt), self.state, method=self.ode_method,
                        args=(inputs,), rtol=1e-6, atol=[10.0, 10.0, 1e-7], max_step=dt)
        if not sol.success:
            raise RuntimeError(f"ODE integration failed: {sol.message}")
        y = sol.y[:, -1]
        y[0] = max(y[0], 0.0)
        y[1] = max(y[1], self.downstream_pressure)
        self.state = y
        return self._report(inputs)

    def _report(self, inputs: DynamicInputs) -> DynamicOutput:
        p_p, p_c, q_b = self.state
        dq_dt = self._bit_flow_derivative(p_p, p_c, q_b, inputs)
        accel = self.params.annulus_inertia * dq_dt
        if self.actuation == "choke":
            q_choke = self._choke_flow(p_c, inputs)
        else:
            dp_c = (inputs.sbp_command - p_c) / self.params.back_pressure_time_constant
            q_choke = max(self.surface_inflow(q_b, inputs)
                          - self.params.annulus_volume / self.params.bulk_modulus * dp_c, 0.0)
        return self._output(p_p, p_c, q_b, q_choke, inputs, accel)
