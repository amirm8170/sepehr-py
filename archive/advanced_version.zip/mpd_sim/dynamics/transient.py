"""
FUTURE EXTENSION — distributed transient (water-hammer type) solver.

NOT IMPLEMENTED and NOT VALIDATED. This module only fixes the interface so a
full transient model can replace ``LumpedMPDModel`` without changing the
simulator, controller, plotting or validation code.

Target formulation (1-D, per flow path, z along MD):

    Continuity:   ∂(ρA)/∂t + ∂(ρvA)/∂z = 0
    Momentum:     ∂(ρvA)/∂t + ∂(ρv²A)/∂z + A ∂P/∂z + ρ g A cos(θ) + F_fric = 0
    Closure:      ρ = ρ(P) via bulk modulus  (dρ/ρ = dP/β)
                  F_fric from the Stage-A FrictionModel (quasi-steady) or an
                  unsteady-friction model (e.g. Vardy–Brown)

Suggested numerics: method of characteristics or a staggered finite-volume
scheme with CFL-limited time step (Δt <= Δz / c, c = sqrt(β/ρ) ≈ 1100 m/s);
boundary conditions: pump flow at the standpipe, choke equation at the
wellhead, bit coupling between string and annulus.

Before use it must be verified (mass balance, steady-state limit equal to
Stage A, pressure-wave speed) and validated against reference data.
"""

from __future__ import annotations

from .dynamic_model import DynamicHydraulicModel, DynamicOutput
from .schedules import DynamicInputs


class TransientConservationModel(DynamicHydraulicModel):
    """Placeholder for the distributed PDE model (see module docstring)."""

    def initialize(self, inputs: DynamicInputs) -> DynamicOutput:
        raise NotImplementedError(
            "The distributed transient PDE solver is a documented future extension; "
            "use 'lumped' or 'quasi_steady'.")

    def step(self, inputs: DynamicInputs, dt: float) -> DynamicOutput:
        raise NotImplementedError("See initialize().")
