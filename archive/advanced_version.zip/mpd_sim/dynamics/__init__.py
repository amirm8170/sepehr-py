"""Stage B — dynamic MPD simulation and closed-loop BHP control."""
