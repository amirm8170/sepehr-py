"""
Control-performance metrics for BHP time series.

Definitions (stated explicitly because textbooks differ):

* error e(t) = BHP_target(t) − BHP(t)
* steady_state_error   : mean e over the last ``final_fraction`` of the run [Pa]
* setpoint step        : exists if the target changes by >= tolerance after
                         the event; step size = final target − BHP at event
* rise_time            : time for BHP to go from 10 % to 90 % of the step
                         (NaN without a setpoint step, i.e. disturbance runs)
* overshoot_percent    : peak excursion beyond the final target in the step
                         direction, as % of |step| (NaN without a step)
* max_overshoot_pa     : max(BHP − target) after the event (>= 0)
* max_undershoot_pa    : max(target − BHP) after the event (>= 0)
* settling_time        : time after the event until |e| stays within
                         ``tolerance`` for the rest of the run (NaN if never)
* time_outside_window  : total time with BHP < pore or > fracture [s]
* IAE / ISE            : ∫|e|dt [Pa·s], ∫e²dt [Pa²·s]
"""

from __future__ import annotations

from typing import Dict, Optional

import numpy as np


def _first_crossing(time: np.ndarray, signal: np.ndarray, level: float,
                    rising: bool) -> float:
    idx = np.nonzero(signal >= level if rising else signal <= level)[0]
    return float(time[idx[0]]) if idx.size else np.nan


def compute_control_metrics(time, bhp, target, status, tolerance: float,
                            event_time: float = 0.0,
                            final_fraction: float = 0.1,
                            initial_bhp: Optional[float] = None) -> Dict[str, float]:
    """
    Compute BHP control metrics.

    Parameters
    ----------
    time, bhp, target : arrays [s], [Pa], [Pa]
    status : array of str   pressure-window status per step
    tolerance : float [Pa]  settling band half-width
    event_time : float [s]  time of the disturbance / setpoint change
    final_fraction : float  share of the run used for steady-state error
    initial_bhp : float, optional  BHP before the event (default: value at event)
    """
    t = np.asarray(time, float)
    y = np.asarray(bhp, float)
    r = np.asarray(target, float)
    err = r - y
    dt = np.diff(t, prepend=t[0])
    after = t >= event_time
    t_a, y_a, r_a, e_a = t[after], y[after], r[after], err[after]

    n_final = max(1, int(len(t) * final_fraction))
    y0 = float(initial_bhp) if initial_bhp is not None else float(y_a[0])
    # A setpoint step exists only if the TARGET changes after the event;
    # otherwise the run is a disturbance-rejection case (no rise/overshoot %).
    before = t < event_time
    target_before = float(r[before][-1]) if before.any() else float(r_a[0])
    target_change = float(r[-1] - target_before)
    has_step = abs(target_change) >= tolerance
    step = float(r[-1] - y0)

    rise = overshoot_pct = np.nan
    if has_step:
        rising = step > 0
        t10 = _first_crossing(t_a, y_a, y0 + 0.1 * step, rising)
        t90 = _first_crossing(t_a, y_a, y0 + 0.9 * step, rising)
        rise = t90 - t10
        peak = (np.max(y_a) - r[-1]) if rising else (r[-1] - np.min(y_a))
        overshoot_pct = max(peak, 0.0) / abs(step) * 100.0

    outside = np.abs(e_a) > tolerance
    if not outside.any():
        settling = 0.0
    elif outside[-1]:
        settling = np.nan
    else:
        last_out = np.nonzero(outside)[0][-1]
        settling = float(t_a[min(last_out + 1, len(t_a) - 1)] - event_time)

    unsafe = np.asarray(status) != "safe"
    return {
        "steady_state_error_pa": float(np.mean(err[-n_final:])),
        "step_size_pa": step if has_step else 0.0,
        "rise_time_s": float(rise),
        "settling_time_s": float(settling),
        "overshoot_percent": float(overshoot_pct),
        "max_overshoot_pa": float(max(np.max(y_a - r_a), 0.0)),
        "max_undershoot_pa": float(max(np.max(r_a - y_a), 0.0)),
        "max_bhp_pa": float(np.max(y)),
        "min_bhp_pa": float(np.min(y)),
        "time_outside_window_s": float(np.sum(dt[unsafe])),
        "fraction_outside_window": float(np.mean(unsafe)),
        "maintained_within_window": bool(not unsafe.any()),
        "iae_pa_s": float(np.sum(np.abs(err) * dt)),
        "ise_pa2_s": float(np.sum(err ** 2 * dt)),
        "settling_tolerance_pa": float(tolerance),
    }
