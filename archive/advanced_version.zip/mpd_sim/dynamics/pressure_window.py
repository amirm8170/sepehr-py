"""
Pressure-window classification.

At every evaluation the BHP is compared with the pore/fracture limits:

    BHP < P_pore           → "kick_risk"   (underbalanced, influx possible)
    BHP > P_frac           → "loss_risk"   (fracture / lost circulation)
    otherwise              → "safe"

and, inside the window, ``near_pore`` / ``near_fracture`` flags are raised when
BHP is within ``warning_margin`` of a limit.
"""

from __future__ import annotations

import numpy as np

from ..models.operations import PressureWindow

STATUS_SAFE = "safe"
STATUS_KICK = "kick_risk"
STATUS_LOSS = "loss_risk"


def classify_bhp(bhp, window: PressureWindow):
    """
    Classify BHP against the pressure window (scalar or array).

    Returns
    -------
    str or np.ndarray of str
        "kick_risk", "loss_risk" or "safe".
    """
    b = np.asarray(bhp, dtype=float)
    status = np.where(b < window.pore_pressure, STATUS_KICK,
                      np.where(b > window.fracture_pressure, STATUS_LOSS, STATUS_SAFE))
    return str(status) if status.ndim == 0 else status


def margin_flags(bhp, window: PressureWindow):
    """
    Near-limit warning flags.

    Returns
    -------
    (near_pore, near_fracture) : bool or arrays
        True when BHP is inside the window but within ``warning_margin``
        of the respective limit.
    """
    b = np.asarray(bhp, dtype=float)
    inside = (b >= window.pore_pressure) & (b <= window.fracture_pressure)
    near_pore = inside & (b - window.pore_pressure < window.warning_margin)
    near_frac = inside & (window.fracture_pressure - b < window.warning_margin)
    if b.ndim == 0:
        return bool(near_pore), bool(near_frac)
    return near_pore, near_frac
