"""
mpd_sim — Well hydraulics simulator for Managed Pressure Drilling (MPD).

Research / educational software developed for the graduate thesis
"Development of a Well Hydraulics Simulation Model for Managed Pressure
Drilling Systems and Dynamic Bottomhole Pressure Control".

Sub-packages
------------
models        : physical description of the well, mud, trajectory and operations
hydraulics    : Stage A — steady-state segment-based hydraulics
dynamics      : Stage B — time-domain models, choke, PID, pressure window
validation    : model-vs-reference error analysis
analysis      : sensitivity analysis
visualization : Matplotlib plots
io            : configuration loading and result export
scenarios     : ready-to-run operational scenarios

All internal calculations use SI units (see ``mpd_sim.units``).

DISCLAIMER: research/educational simulator, NOT field-certified drilling
control software.
"""

__version__ = "0.1.0"
