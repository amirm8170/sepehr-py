"""
Validation framework: compare model predictions with reference values.

Error definitions
-----------------
    absolute error   E_abs = |Model − Reference|
    relative error   E_rel = |Model − Reference| / |Reference|
    percentage error E_%   = E_rel × 100
    (for time series additionally RMSE, MAE, max |error|, mean %-error)

Data provenance is MANDATORY. Every dataset carries a ``data_type``:

    field                   measured on a real well
    laboratory              flow-loop / rheometer measurements
    literature              values published in a cited source
    synthetic_demonstration generated values — "Demonstration only — not
                            experimental validation."

Reports and plots always print the data type; a synthetic comparison is a
code-to-code VERIFICATION, never a validation of the physics.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Iterable, List

import numpy as np
import pandas as pd

DATA_TYPES = ("field", "laboratory", "literature", "synthetic_demonstration")
DEMO_DISCLAIMER = "Demonstration only — not experimental validation."


def absolute_error(model, reference):
    """|Model − Reference|."""
    return np.abs(np.asarray(model, float) - np.asarray(reference, float))


def relative_error(model, reference):
    """|Model − Reference| / |Reference| (reference must be non-zero)."""
    ref = np.asarray(reference, float)
    if np.any(ref == 0):
        raise ValueError("Relative error undefined for zero reference values.")
    return absolute_error(model, ref) / np.abs(ref)


def percentage_error(model, reference):
    """Relative error × 100 [%]."""
    return relative_error(model, reference) * 100.0


@dataclass
class ValidationPoint:
    """One reference/model pair."""

    quantity: str
    reference_value: float
    model_value: float
    unit: str
    data_type: str
    source: str
    case: str = ""

    def __post_init__(self) -> None:
        if self.data_type not in DATA_TYPES:
            raise ValueError(f"data_type must be one of {DATA_TYPES}.")

    def errors(self) -> Dict[str, float]:
        return {"absolute_error": float(absolute_error(self.model_value, self.reference_value)),
                "relative_error": float(relative_error(self.model_value, self.reference_value)),
                "percentage_error": float(percentage_error(self.model_value, self.reference_value))}


def validation_table(points: Iterable[ValidationPoint]) -> pd.DataFrame:
    """Tabulate points with their errors; adds a 'disclaimer' column for synthetic data."""
    rows: List[Dict] = []
    for p in points:
        row = {"case": p.case, "quantity": p.quantity, "unit": p.unit,
               "reference_value": p.reference_value, "model_value": p.model_value,
               **p.errors(), "data_type": p.data_type, "source": p.source}
        row["disclaimer"] = DEMO_DISCLAIMER if p.data_type == "synthetic_demonstration" else ""
        rows.append(row)
    return pd.DataFrame(rows)


def summarize(table: pd.DataFrame) -> pd.DataFrame:
    """Per-quantity error statistics."""
    return (table.groupby(["quantity", "data_type"])["percentage_error"]
            .agg(n="count", mean_percent="mean", max_percent="max").reset_index())


def compare_profiles(depth_model, value_model, depth_ref, value_ref) -> pd.DataFrame:
    """
    Compare a pressure profile with reference points (model interpolated in depth).

    Returns a table at the reference depths.
    """
    model_at_ref = np.interp(depth_ref, depth_model, value_model)
    return pd.DataFrame({"depth": depth_ref, "reference_value": value_ref,
                         "model_value": model_at_ref,
                         "absolute_error": absolute_error(model_at_ref, value_ref),
                         "percentage_error": percentage_error(model_at_ref, value_ref)})


def compare_time_series(time_model, value_model, time_ref, value_ref) -> Dict[str, float]:
    """
    Error statistics of a dynamic response (model interpolated on reference times).

    Returns RMSE, MAE, max absolute error and mean/max percentage error.
    """
    model_at_ref = np.interp(time_ref, time_model, value_model)
    err = model_at_ref - np.asarray(value_ref, float)
    pct = percentage_error(model_at_ref, value_ref)
    return {"rmse": float(np.sqrt(np.mean(err ** 2))), "mae": float(np.mean(np.abs(err))),
            "max_abs_error": float(np.max(np.abs(err))),
            "mean_percentage_error": float(np.mean(pct)),
            "max_percentage_error": float(np.max(pct))}


# ---------------------------------------------------------------------------
# Steady-state validation against a reference file
# ---------------------------------------------------------------------------
#: Map of reference-file quantity names → (HydraulicsResult attribute getter, SI kind)
STEADY_QUANTITIES = {
    "drill_pipe_loss": (lambda r: r.losses.drill_pipe, "pressure"),
    "bha_loss": (lambda r: r.losses.bha, "pressure"),
    "bit_loss": (lambda r: r.losses.bit, "pressure"),
    "annulus_loss": (lambda r: r.losses.annulus, "pressure"),
    "bhp": (lambda r: r.bhp, "pressure"),
    "spp": (lambda r: r.spp, "pressure"),
    "ecd_conventional": (lambda r: r.ecd_conventional, "density"),
    "emw_bhp": (lambda r: r.emw_bhp, "density"),
}


def validate_steady_state(result, reference: pd.DataFrame) -> pd.DataFrame:
    """
    Compare a steady-state HydraulicsResult with a reference table.

    The reference table needs columns quantity, reference_value, unit,
    data_type, source (see ``io.loaders.load_reference_csv``). Model values
    are converted into the reference unit before comparison.
    """
    from ..units import from_si   # local import keeps this module dependency-light

    points = []
    for _, row in reference.iterrows():
        q = row["quantity"]
        if q not in STEADY_QUANTITIES:
            raise ValueError(f"Unsupported reference quantity '{q}'. "
                             f"Supported: {sorted(STEADY_QUANTITIES)}")
        getter, kind = STEADY_QUANTITIES[q]
        model_value = from_si(getter(result), str(row["unit"]), kind)
        points.append(ValidationPoint(quantity=q, reference_value=float(row["reference_value"]),
                                      model_value=float(model_value), unit=str(row["unit"]),
                                      data_type=str(row["data_type"]), source=str(row["source"]),
                                      case=str(row.get("case", ""))))
    return validation_table(points)
