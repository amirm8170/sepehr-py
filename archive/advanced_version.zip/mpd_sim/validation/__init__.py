"""Model-versus-reference validation framework."""
