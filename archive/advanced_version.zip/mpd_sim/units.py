"""
Unit-conversion utilities.

Policy
------
* The computational engine works **only in SI units**:
  length [m], diameter [m], area [m²], velocity [m/s], flow rate [m³/s],
  density [kg/m³], pressure [Pa, gauge], viscosity [Pa·s],
  stress [Pa], time [s].
* Field units are accepted only at the input boundary (configuration
  loader) and produced only at the output boundary (exporters, plots).
* Every conversion goes through the explicit factor tables below — there is
  no implicit conversion anywhere in the code.

Exact definitions used (NIST SP 811):
    1 ft      = 0.3048 m                          (exact)
    1 in      = 0.0254 m                          (exact)
    1 US gal  = 3.785411784e-3 m³                 (exact)
    1 lbm     = 0.45359237 kg                     (exact)
    1 lbf     = 4.4482216152605 N                 (exact)
    1 psi     = 1 lbf/in² = 6894.757293168 Pa
    1 cP      = 1e-3 Pa·s                         (exact)
    1 ppg     = 1 lbm/US gal = 119.826427316 kg/m³
    1 lbf/100 ft² = 0.47880258980 Pa
"""

from __future__ import annotations

from typing import Dict

from .constants import GRAVITY

# ---------------------------------------------------------------------------
# Base exact factors
# ---------------------------------------------------------------------------
FT_TO_M: float = 0.3048
IN_TO_M: float = 0.0254
MM_TO_M: float = 1.0e-3
US_GAL_TO_M3: float = 3.785411784e-3
LBM_TO_KG: float = 0.45359237
LBF_TO_N: float = 4.4482216152605

PSI_TO_PA: float = LBF_TO_N / IN_TO_M ** 2            # 6894.757293168 Pa
BAR_TO_PA: float = 1.0e5
KPA_TO_PA: float = 1.0e3
MPA_TO_PA: float = 1.0e6
GPM_TO_M3S: float = US_GAL_TO_M3 / 60.0               # 6.30901964e-5 m³/s
LPM_TO_M3S: float = 1.0e-3 / 60.0
PPG_TO_KGM3: float = LBM_TO_KG / US_GAL_TO_M3         # 119.826427 kg/m³
SG_TO_KGM3: float = 1000.0                            # relative to water at 4 °C
CP_TO_PAS: float = 1.0e-3
LBF100FT2_TO_PA: float = LBF_TO_N / (100.0 * FT_TO_M ** 2)  # 0.478802590 Pa

#: Field hydrostatic constant 0.052 psi/(ft·ppg) is a ROUNDED value of
#: g * PPG_TO_KGM3 * FT_TO_M / PSI_TO_PA = 0.0519480...  The simulator uses
#: the exact SI computation; this constant exists only for field-unit helpers
#: and documentation.
FIELD_HYDROSTATIC_CONSTANT_EXACT: float = GRAVITY * PPG_TO_KGM3 * FT_TO_M / PSI_TO_PA
FIELD_HYDROSTATIC_CONSTANT_ROUNDED: float = 0.052

# ---------------------------------------------------------------------------
# Unit tables: quantity kind -> {unit tag -> factor to SI}
# Unit tags are the suffixes used in configuration keys, e.g.
# "hole_diameter_in", "density_ppg", "pump_rate_gpm".
# ---------------------------------------------------------------------------
UNIT_TABLE: Dict[str, Dict[str, float]] = {
    # "32nds" = 1/32 inch, the conventional unit of bit-nozzle sizes.
    "length": {"m": 1.0, "ft": FT_TO_M, "in": IN_TO_M, "mm": MM_TO_M,
               "32nds": IN_TO_M / 32.0},
    "pressure": {"pa": 1.0, "kpa": KPA_TO_PA, "mpa": MPA_TO_PA,
                 "bar": BAR_TO_PA, "psi": PSI_TO_PA},
    "flow_rate": {"m3_s": 1.0, "m3_min": 1.0 / 60.0, "gpm": GPM_TO_M3S,
                  "lpm": LPM_TO_M3S},
    "density": {"kg_m3": 1.0, "ppg": PPG_TO_KGM3, "sg": SG_TO_KGM3},
    "viscosity": {"pa_s": 1.0, "cp": CP_TO_PAS},
    "stress": {"pa": 1.0, "lbf_100ft2": LBF100FT2_TO_PA},
    "velocity": {"m_s": 1.0, "ft_s": FT_TO_M, "ft_min": FT_TO_M / 60.0,
                 "m_min": 1.0 / 60.0},
    "time": {"s": 1.0, "min": 60.0, "h": 3600.0},
    "pressure_rate": {"pa_s": 1.0, "bar_s": BAR_TO_PA, "psi_s": PSI_TO_PA},
    "volume": {"m3": 1.0, "bbl": 0.158987294928, "l": 1.0e-3},
    "angle": {"deg": 1.0},          # angles are kept in degrees in inputs
    "dimensionless": {"frac": 1.0, "pct": 0.01},
}


class UnitError(ValueError):
    """Raised for unknown unit tags or quantity kinds."""


def factor_to_si(unit: str, kind: str) -> float:
    """
    Return the multiplicative factor converting ``unit`` to SI.

    Parameters
    ----------
    unit : str
        Unit tag, e.g. ``"psi"``, ``"ft"`` (case-insensitive).
    kind : str
        Quantity kind, a key of :data:`UNIT_TABLE`.

    Returns
    -------
    float
        Factor such that ``value_SI = value * factor``.
    """
    table = UNIT_TABLE.get(kind)
    if table is None:
        raise UnitError(f"Unknown quantity kind '{kind}'.")
    key = unit.lower()
    if key not in table:
        raise UnitError(
            f"Unknown {kind} unit '{unit}'. Allowed: {sorted(table)}")
    return table[key]


def to_si(value: float, unit: str, kind: str) -> float:
    """Convert ``value`` expressed in ``unit`` to the SI unit of ``kind``."""
    return value * factor_to_si(unit, kind)


def from_si(value: float, unit: str, kind: str) -> float:
    """Convert an SI ``value`` of quantity ``kind`` to ``unit``."""
    return value / factor_to_si(unit, kind)


# ---------------------------------------------------------------------------
# Named convenience converters (explicit, readable at call sites)
# ---------------------------------------------------------------------------
def ft_to_m(x: float) -> float:
    """Feet → metres."""
    return x * FT_TO_M


def m_to_ft(x: float) -> float:
    """Metres → feet."""
    return x / FT_TO_M


def in_to_m(x: float) -> float:
    """Inches → metres."""
    return x * IN_TO_M


def m_to_in(x: float) -> float:
    """Metres → inches."""
    return x / IN_TO_M


def mm_to_m(x: float) -> float:
    """Millimetres → metres."""
    return x * MM_TO_M


def m_to_mm(x: float) -> float:
    """Metres → millimetres."""
    return x / MM_TO_M


def gpm_to_m3s(x: float) -> float:
    """US gallons per minute → m³/s."""
    return x * GPM_TO_M3S


def m3s_to_gpm(x: float) -> float:
    """m³/s → US gallons per minute."""
    return x / GPM_TO_M3S


def ppg_to_kgm3(x: float) -> float:
    """Pounds per US gallon → kg/m³."""
    return x * PPG_TO_KGM3


def kgm3_to_ppg(x: float) -> float:
    """kg/m³ → pounds per US gallon."""
    return x / PPG_TO_KGM3


def psi_to_pa(x: float) -> float:
    """psi → Pa."""
    return x * PSI_TO_PA


def pa_to_psi(x: float) -> float:
    """Pa → psi."""
    return x / PSI_TO_PA


def bar_to_pa(x: float) -> float:
    """bar → Pa."""
    return x * BAR_TO_PA


def pa_to_bar(x: float) -> float:
    """Pa → bar."""
    return x / BAR_TO_PA


def cp_to_pas(x: float) -> float:
    """Centipoise → Pa·s."""
    return x * CP_TO_PAS


def pas_to_cp(x: float) -> float:
    """Pa·s → centipoise."""
    return x / CP_TO_PAS


def lbf100ft2_to_pa(x: float) -> float:
    """lbf/100 ft² (yield point / gel strength unit) → Pa."""
    return x * LBF100FT2_TO_PA


def pa_to_lbf100ft2(x: float) -> float:
    """Pa → lbf/100 ft²."""
    return x / LBF100FT2_TO_PA


def nozzle_32nds_to_m(x: float) -> float:
    """Bit nozzle size in 32nds of an inch → metres (e.g. 12/32" → 12)."""
    return x / 32.0 * IN_TO_M


def field_hydrostatic_psi(mud_weight_ppg: float, tvd_ft: float,
                          rounded: bool = True) -> float:
    """
    Field-unit hydrostatic pressure  P_h = 0.052 × MW(ppg) × TVD(ft)  [psi].

    Provided ONLY as an output/check helper for users accustomed to oilfield
    units. The engine itself computes ρ g ΔTVD in SI.

    Parameters
    ----------
    mud_weight_ppg : float
        Mud weight [ppg].
    tvd_ft : float
        True vertical depth [ft].
    rounded : bool
        If True use the traditional rounded 0.052; otherwise the exact
        0.051948 derived from SI definitions.

    Returns
    -------
    float
        Hydrostatic pressure [psi].
    """
    c = (FIELD_HYDROSTATIC_CONSTANT_ROUNDED if rounded
         else FIELD_HYDROSTATIC_CONSTANT_EXACT)
    return c * mud_weight_ppg * tvd_ft


def pressure_to_emw(pressure_pa: float, tvd_m: float) -> float:
    """
    Convert a pressure at depth to Equivalent Mud Weight [kg/m³].

    EMW = P / (g × TVD)

    Parameters
    ----------
    pressure_pa : float
        Gauge pressure [Pa].
    tvd_m : float
        True vertical depth [m], must be > 0.
    """
    if tvd_m <= 0:
        raise ValueError("TVD must be positive to compute an equivalent density.")
    return pressure_pa / (GRAVITY * tvd_m)


def emw_to_pressure(emw_kgm3: float, tvd_m: float) -> float:
    """Convert Equivalent Mud Weight [kg/m³] at TVD [m] to gauge pressure [Pa]."""
    return emw_kgm3 * GRAVITY * tvd_m
