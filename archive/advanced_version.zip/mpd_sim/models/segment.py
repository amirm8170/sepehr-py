"""
Well discretisation into segments.

The well is divided along MD from the surface (0) to the bit into segments
of target length ``segment_length``, with forced boundaries at every
geometry change (drill-string component tops, hole-section boundaries, bit).
The SAME MD grid is used for the drill-string interior and for the annulus,
so each depth interval yields one "string" segment and one "annulus"
segment. The open hole between bit and TD (rathole) contains static mud and
is handled as a hydrostatic column only.

Each ``WellSegment`` is self-contained: it stores MD, TVD, inclination,
azimuth, length, diameters, flow area and hydraulic diameter. Hydraulic
results (velocity, rheology numbers, friction factor, pressure loss) are
attached by the solver in ``SegmentHydraulics`` objects.

For speed the solver works on the column arrays of ``FlowPathGrid``; the
``WellSegment`` objects are generated from the same arrays for inspection,
export and teaching purposes.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import List

import numpy as np

from ..constants import DEPTH_TOLERANCE
from ..hydraulics.geometry import (annulus_area, annulus_hydraulic_diameter,
                                   pipe_area, pipe_closed_end_area,
                                   pipe_steel_area)
from .well import WellGeometry

logger = logging.getLogger(__name__)

STRING_PATH = "drill_string"
ANNULUS_PATH = "annulus"


@dataclass(frozen=True)
class WellSegment:
    """
    One discretised well segment (geometry only, SI units).

    md_top / md_bottom   [m]  measured depth of segment ends
    tvd_top / tvd_bottom [m]  true vertical depth of segment ends
    inclination, azimuth [deg] at the segment mid-point
    length               [m]  = md_bottom − md_top (flow-path length)
    flow_path            "drill_string" | "annulus"
    section              component name (string) or "hole/component" (annulus)
    category             "drill_pipe" | "bha" | "annulus"
    inner_diameter       [m]  pipe ID (string) or pipe OD (annulus inner wall)
    outer_diameter       [m]  pipe ID (string) or hole diameter (annulus outer wall)
    flow_area            [m²]
    hydraulic_diameter   [m]
    """

    index: int
    flow_path: str
    section: str
    category: str
    md_top: float
    md_bottom: float
    tvd_top: float
    tvd_bottom: float
    inclination: float
    azimuth: float
    length: float
    inner_diameter: float
    outer_diameter: float
    flow_area: float
    hydraulic_diameter: float

    @property
    def delta_tvd(self) -> float:
        """Vertical extent of the segment [m] (used for hydrostatics)."""
        return self.tvd_bottom - self.tvd_top


@dataclass
class FlowPathGrid:
    """
    Column-array representation of the discretised well (surface → bit).

    All arrays have length N (number of depth intervals).
    """

    md_top: np.ndarray
    md_bottom: np.ndarray
    tvd_top: np.ndarray
    tvd_bottom: np.ndarray
    inclination: np.ndarray
    azimuth: np.ndarray
    length: np.ndarray
    # drill-string interior
    pipe_id: np.ndarray
    pipe_od: np.ndarray
    string_area: np.ndarray
    string_section: np.ndarray
    string_category: np.ndarray
    displacement_area_closed: np.ndarray
    displacement_area_open: np.ndarray
    # annulus
    hole_diameter: np.ndarray
    annulus_area: np.ndarray
    annulus_dh: np.ndarray
    annulus_section: np.ndarray

    @property
    def n_segments(self) -> int:
        return int(self.md_top.size)

    @property
    def delta_tvd(self) -> np.ndarray:
        return self.tvd_bottom - self.tvd_top

    def string_segments(self) -> List[WellSegment]:
        """WellSegment objects for the drill-string interior."""
        return [WellSegment(i, STRING_PATH, str(self.string_section[i]),
                            str(self.string_category[i]),
                            float(self.md_top[i]), float(self.md_bottom[i]),
                            float(self.tvd_top[i]), float(self.tvd_bottom[i]),
                            float(self.inclination[i]), float(self.azimuth[i]),
                            float(self.length[i]), float(self.pipe_id[i]),
                            float(self.pipe_id[i]), float(self.string_area[i]),
                            float(self.pipe_id[i]))
                for i in range(self.n_segments)]

    def annulus_segments(self) -> List[WellSegment]:
        """WellSegment objects for the annulus."""
        return [WellSegment(i, ANNULUS_PATH, str(self.annulus_section[i]), "annulus",
                            float(self.md_top[i]), float(self.md_bottom[i]),
                            float(self.tvd_top[i]), float(self.tvd_bottom[i]),
                            float(self.inclination[i]), float(self.azimuth[i]),
                            float(self.length[i]), float(self.pipe_od[i]),
                            float(self.hole_diameter[i]), float(self.annulus_area[i]),
                            float(self.annulus_dh[i]))
                for i in range(self.n_segments)]


def build_md_grid(breakpoints: np.ndarray, bit_depth: float,
                  segment_length: float) -> np.ndarray:
    """
    Build the MD node grid from 0 to the bit.

    Each interval between consecutive breakpoints is split into
    ceil(Δ/segment_length) equal parts, so no segment exceeds the target
    length and every geometry change falls on a node.
    """
    if segment_length <= 0:
        raise ValueError("Segment length must be > 0.")
    pts = np.unique(np.append(breakpoints[breakpoints <= bit_depth + DEPTH_TOLERANCE],
                              bit_depth))
    # Merge points closer than the depth tolerance (avoids zero-length segments
    # from round-off, e.g. 9500 ft + 500 ft vs 10000 ft).
    pts = pts[np.concatenate([[True], np.diff(pts) > DEPTH_TOLERANCE])]
    nodes = [pts[0]]
    for a, b in zip(pts[:-1], pts[1:]):
        n = max(1, int(np.ceil((b - a) / segment_length - 1e-9)))
        nodes.extend(np.linspace(a, b, n + 1)[1:])
    return np.asarray(nodes)


def discretize_well(well: WellGeometry, segment_length: float) -> FlowPathGrid:
    """
    Discretise the well from surface to bit.

    Parameters
    ----------
    well : WellGeometry
    segment_length : float
        Target (maximum) segment length [m].

    Returns
    -------
    FlowPathGrid
    """
    nodes = build_md_grid(well.breakpoints(), well.bit_depth, segment_length)
    md_top, md_bottom = nodes[:-1], nodes[1:]
    mid = 0.5 * (md_top + md_bottom)
    traj = well.trajectory

    comp_idx = well.string_component_index_at(mid)
    hole_idx = well.hole_section_index_at(mid)
    comps = well.drill_string
    holes = well.hole_sections

    pipe_id = np.array([comps[i].inner_diameter for i in comp_idx])
    pipe_od = np.array([comps[i].outer_diameter for i in comp_idx])
    hole_d = np.array([holes[i].diameter for i in hole_idx])
    grid = FlowPathGrid(
        md_top=md_top, md_bottom=md_bottom,
        tvd_top=traj.tvd_at(md_top), tvd_bottom=traj.tvd_at(md_bottom),
        inclination=traj.inclination_at(mid), azimuth=traj.azimuth_at(mid),
        length=md_bottom - md_top,
        pipe_id=pipe_id, pipe_od=pipe_od, string_area=pipe_area(pipe_id),
        string_section=np.array([comps[i].name for i in comp_idx]),
        string_category=np.array([comps[i].category for i in comp_idx]),
        displacement_area_closed=pipe_closed_end_area(pipe_od),
        displacement_area_open=pipe_steel_area(pipe_od, pipe_id),
        hole_diameter=hole_d,
        annulus_area=annulus_area(hole_d, pipe_od),
        annulus_dh=annulus_hydraulic_diameter(hole_d, pipe_od),
        annulus_section=np.array([f"{holes[h].name}/{comps[c].name}"
                                  for h, c in zip(hole_idx, comp_idx)]),
    )
    logger.info("Well discretized into %d segments per flow path "
                "(target length %.1f m, %d forced breakpoints).",
                grid.n_segments, segment_length, well.breakpoints().size)
    return grid
