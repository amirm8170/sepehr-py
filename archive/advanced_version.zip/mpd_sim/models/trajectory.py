"""
Well trajectory (directional survey) model.

Distinguishes the four trajectory quantities explicitly:

* MD  — measured depth: length along the well path [m]. Used for flow-path
        length (friction, volumes, fluid inertia).
* TVD — true vertical depth [m]. Used ONLY for hydrostatic pressure.
* Inclination — angle from vertical [deg] (0 = vertical, 90 = horizontal).
* Azimuth — angle from north in the horizontal plane [deg].

TVD at survey stations
----------------------
If TVD is supplied by the user it is taken as authoritative (it normally
comes from the survey contractor) and cross-checked against the minimum
curvature method; a warning is logged if they differ by more than
``TVD_CONSISTENCY_TOLERANCE``. If TVD is not supplied it is computed with
the Minimum Curvature Method (standard industry method; e.g. SPE/ISCWSA,
Bourgoyne et al. 1986, Ch. 8):

    cos(β) = cos(I2 - I1) - sin(I1) sin(I2) (1 - cos(A2 - A1))
    RF     = (2/β) tan(β/2)        (RF = 1 when β → 0)
    ΔTVD   = ΔMD/2 (cos I1 + cos I2) RF

TVD between stations
--------------------
Engineering simplification: TVD, inclination and azimuth are linearly
interpolated in MD between survey stations. Hydrostatic pressure at
station depths is therefore exact; between stations the error is
second-order in the dogleg and negligible for typical station spacing
(≈ 30 m). Inclination is interpolated linearly; azimuth is interpolated
along the shortest angular path.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Optional, Sequence

import numpy as np

from ..constants import DEPTH_TOLERANCE, TVD_CONSISTENCY_TOLERANCE

logger = logging.getLogger(__name__)


def minimum_curvature_tvd(md: np.ndarray, inclination_deg: np.ndarray,
                          azimuth_deg: np.ndarray) -> np.ndarray:
    """
    Compute TVD at survey stations by the Minimum Curvature Method.

    Parameters
    ----------
    md : array [m]
        Measured depths, strictly increasing, md[0] is the surface reference.
    inclination_deg, azimuth_deg : array [deg]
        Survey angles at each station.

    Returns
    -------
    np.ndarray
        TVD at each station [m], TVD[0] = 0 relative to md[0] (assumes the
        first station is at the vertical reference, i.e. md[0] = tvd[0]).
    """
    inc = np.radians(inclination_deg)
    azi = np.radians(azimuth_deg)
    d_md = np.diff(md)
    i1, i2 = inc[:-1], inc[1:]
    a1, a2 = azi[:-1], azi[1:]
    cos_dogleg = np.cos(i2 - i1) - np.sin(i1) * np.sin(i2) * (1.0 - np.cos(a2 - a1))
    dogleg = np.arccos(np.clip(cos_dogleg, -1.0, 1.0))
    # Ratio factor RF = 2/β tan(β/2); its limit for β → 0 is 1.
    with np.errstate(divide="ignore", invalid="ignore"):
        ratio_factor = np.where(dogleg > 1e-12, 2.0 / dogleg * np.tan(dogleg / 2.0), 1.0)
    d_tvd = d_md / 2.0 * (np.cos(i1) + np.cos(i2)) * ratio_factor
    return np.concatenate([[md[0]], md[0] + np.cumsum(d_tvd)])


def minimum_curvature_coordinates(md: np.ndarray, inclination_deg: np.ndarray,
                                  azimuth_deg: np.ndarray):
    """
    North and East displacements [m] at survey stations (minimum curvature).

        ΔN = ΔMD/2 (sin I1 cos A1 + sin I2 cos A2) RF
        ΔE = ΔMD/2 (sin I1 sin A1 + sin I2 sin A2) RF

    Used for trajectory visualisation (plan view / vertical section).
    """
    inc = np.radians(inclination_deg)
    azi = np.radians(azimuth_deg)
    d_md = np.diff(md)
    i1, i2, a1, a2 = inc[:-1], inc[1:], azi[:-1], azi[1:]
    cos_dogleg = np.cos(i2 - i1) - np.sin(i1) * np.sin(i2) * (1.0 - np.cos(a2 - a1))
    dogleg = np.arccos(np.clip(cos_dogleg, -1.0, 1.0))
    with np.errstate(divide="ignore", invalid="ignore"):
        rf = np.where(dogleg > 1e-12, 2.0 / dogleg * np.tan(dogleg / 2.0), 1.0)
    d_n = d_md / 2.0 * (np.sin(i1) * np.cos(a1) + np.sin(i2) * np.cos(a2)) * rf
    d_e = d_md / 2.0 * (np.sin(i1) * np.sin(a1) + np.sin(i2) * np.sin(a2)) * rf
    return (np.concatenate([[0.0], np.cumsum(d_n)]), np.concatenate([[0.0], np.cumsum(d_e)]))


@dataclass
class Trajectory:
    """
    Directional survey of the well.

    Attributes
    ----------
    md : np.ndarray
        Measured depth of each survey station [m] (first station = 0 m at
        the rig-floor / wellhead reference).
    inclination : np.ndarray
        Inclination [deg].
    azimuth : np.ndarray
        Azimuth [deg].
    tvd : np.ndarray
        True vertical depth [m] (user-supplied or minimum-curvature).
    """

    md: np.ndarray
    inclination: np.ndarray
    azimuth: np.ndarray
    tvd: np.ndarray

    @classmethod
    def from_stations(cls, md: Sequence[float], inclination: Sequence[float],
                      azimuth: Sequence[float],
                      tvd: Optional[Sequence[float]] = None) -> "Trajectory":
        """
        Build and validate a trajectory from survey stations (SI units).

        Raises
        ------
        ValueError
            If MD is not increasing, angles are out of range, or TVD > MD.
        """
        md_a = np.asarray(md, dtype=float)
        inc_a = np.asarray(inclination, dtype=float)
        azi_a = np.asarray(azimuth, dtype=float)
        if not (md_a.size == inc_a.size == azi_a.size) or md_a.size < 2:
            raise ValueError("Trajectory needs >= 2 stations with equal-length MD/inc/azi arrays.")
        if np.any(np.diff(md_a) <= 0):
            raise ValueError("Survey MD must be strictly increasing.")
        if md_a[0] < 0:
            raise ValueError("Survey MD must be non-negative.")
        if np.any((inc_a < 0) | (inc_a > 180)):
            raise ValueError("Inclination must be within [0, 180] deg.")

        tvd_mc = minimum_curvature_tvd(md_a, inc_a, azi_a)
        if tvd is None:
            tvd_a = tvd_mc
            logger.info("TVD computed from survey by minimum curvature method.")
        else:
            tvd_a = np.asarray(tvd, dtype=float)
            if tvd_a.size != md_a.size:
                raise ValueError("TVD array length must match MD array length.")
            mismatch = np.max(np.abs(tvd_a - tvd_mc))
            if mismatch > TVD_CONSISTENCY_TOLERANCE:
                logger.warning(
                    "User TVD differs from minimum-curvature TVD by up to %.2f m; "
                    "user TVD is used. Check survey data.", mismatch)

        if np.any(tvd_a > md_a + DEPTH_TOLERANCE):
            raise ValueError("TVD cannot exceed MD at any survey station (TVD <= MD).")
        if np.any(np.diff(tvd_a) > np.diff(md_a) + DEPTH_TOLERANCE):
            raise ValueError("TVD increment cannot exceed MD increment between stations.")
        return cls(md=md_a, inclination=inc_a, azimuth=azi_a, tvd=tvd_a)

    @classmethod
    def vertical(cls, total_md: float) -> "Trajectory":
        """Convenience constructor for a vertical well of depth ``total_md`` [m]."""
        return cls.from_stations([0.0, total_md], [0.0, 0.0], [0.0, 0.0],
                                 [0.0, total_md])

    @property
    def total_md(self) -> float:
        """Measured depth of the last survey station [m]."""
        return float(self.md[-1])

    @property
    def total_tvd(self) -> float:
        """TVD of the last survey station [m]."""
        return float(self.tvd[-1])

    def coordinates(self):
        """(north, east) displacement of each station [m] by minimum curvature."""
        return minimum_curvature_coordinates(self.md, self.inclination, self.azimuth)

    def tvd_at(self, md: np.ndarray) -> np.ndarray:
        """TVD [m] at arbitrary MD [m] (linear interpolation between stations)."""
        self._check_range(md)
        return np.interp(md, self.md, self.tvd)

    def inclination_at(self, md: np.ndarray) -> np.ndarray:
        """Inclination [deg] at arbitrary MD [m] (linear interpolation)."""
        self._check_range(md)
        return np.interp(md, self.md, self.inclination)

    def azimuth_at(self, md: np.ndarray) -> np.ndarray:
        """Azimuth [deg] at arbitrary MD [m] (interpolated along shortest arc)."""
        self._check_range(md)
        unwrapped = np.degrees(np.unwrap(np.radians(self.azimuth)))
        return np.mod(np.interp(md, self.md, unwrapped), 360.0)

    def _check_range(self, md) -> None:
        md_arr = np.atleast_1d(md)
        if np.any(md_arr < self.md[0] - DEPTH_TOLERANCE) or \
                np.any(md_arr > self.md[-1] + DEPTH_TOLERANCE):
            raise ValueError(
                f"Requested MD outside survey range [{self.md[0]}, {self.md[-1]}] m.")
