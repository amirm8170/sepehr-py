"""
Well geometry: hole sections, drill string and bit.

Conventions
-----------
* Depths are MD [m] measured from the surface reference (MD = 0).
* The drill string is listed from SURFACE to BIT; its total length defines
  the bit depth (MD). The bit may be above the well TD (off bottom).
* Hole sections (cased hole uses the casing ID; open hole uses bit/hole size)
  must cover 0 → TD contiguously.
* Concentric pipe is assumed (no eccentricity), tool joints are ignored
  (simplification E — tool-joint losses can be added later).
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import List

import numpy as np

from ..constants import DEPTH_TOLERANCE
from ..hydraulics.bit import total_flow_area
from .trajectory import Trajectory

logger = logging.getLogger(__name__)

HOLE_KINDS = ("cased", "open_hole", "riser", "liner")
STRING_CATEGORIES = ("drill_pipe", "bha")


@dataclass
class HoleSection:
    """
    A wellbore interval with constant diameter.

    Attributes
    ----------
    name : str
    top_md, bottom_md : float [m]
    diameter : float [m]  casing ID (cased) or hole diameter (open hole)
    kind : str            one of HOLE_KINDS
    """

    name: str
    top_md: float
    bottom_md: float
    diameter: float
    kind: str = "open_hole"

    def __post_init__(self) -> None:
        if self.bottom_md <= self.top_md:
            raise ValueError(f"Hole section '{self.name}': bottom MD must exceed top MD.")
        if self.diameter <= 0:
            raise ValueError(f"Hole section '{self.name}': diameter must be > 0.")
        if self.kind not in HOLE_KINDS:
            raise ValueError(f"Hole section kind must be one of {HOLE_KINDS}.")


@dataclass
class DrillStringComponent:
    """
    A drill-string component of uniform cross-section.

    Attributes
    ----------
    name : str
    length : float [m]
    outer_diameter : float [m]  (OD — annulus inner wall)
    inner_diameter : float [m]  (ID — internal flow path)
    category : "drill_pipe" | "bha"   (used for the SPP loss breakdown)
    """

    name: str
    length: float
    outer_diameter: float
    inner_diameter: float
    category: str = "drill_pipe"

    def __post_init__(self) -> None:
        if self.length <= 0:
            raise ValueError(f"Component '{self.name}': length must be > 0.")
        if self.inner_diameter <= 0 or self.outer_diameter <= 0:
            raise ValueError(f"Component '{self.name}': diameters must be > 0.")
        if self.outer_diameter <= self.inner_diameter:
            raise ValueError(f"Component '{self.name}': OD must exceed ID.")
        if self.category not in STRING_CATEGORIES:
            raise ValueError(f"Component category must be one of {STRING_CATEGORIES}.")


@dataclass
class BitNozzles:
    """
    Bit nozzle configuration.

    Attributes
    ----------
    nozzle_diameters : list of float [m]
    discharge_coefficient : float [-]  (C_d, typically 0.95; calibrate)
    """

    nozzle_diameters: List[float]
    discharge_coefficient: float = 0.95

    def __post_init__(self) -> None:
        if not 0 < self.discharge_coefficient <= 1:
            raise ValueError("Discharge coefficient must be in (0, 1].")
        total_flow_area(self.nozzle_diameters)  # validates diameters

    @property
    def total_flow_area(self) -> float:
        """TFA [m²]."""
        return total_flow_area(self.nozzle_diameters)


@dataclass
class WellGeometry:
    """
    Complete static description of the well and drill string.

    Attributes
    ----------
    trajectory : Trajectory
    hole_sections : list of HoleSection (surface → TD, contiguous)
    drill_string : list of DrillStringComponent (surface → bit)
    bit : BitNozzles
    """

    trajectory: Trajectory
    hole_sections: List[HoleSection]
    drill_string: List[DrillStringComponent]
    bit: BitNozzles
    _string_tops: np.ndarray = field(init=False, repr=False)

    def __post_init__(self) -> None:
        self._validate_hole_sections()
        self._string_tops = np.concatenate(
            [[0.0], np.cumsum([c.length for c in self.drill_string])[:-1]])
        if self.bit_depth > self.total_depth + DEPTH_TOLERANCE:
            raise ValueError(
                f"Drill-string length ({self.bit_depth:.1f} m) exceeds well TD "
                f"({self.total_depth:.1f} m).")
        self._validate_clearances()
        logger.info("Well geometry: TD %.1f m MD / %.1f m TVD, bit at %.1f m MD.",
                    self.total_depth, self.td_tvd, self.bit_depth)

    # -------------------------------------------------------------- checks
    def _validate_hole_sections(self) -> None:
        if not self.hole_sections:
            raise ValueError("At least one hole section is required.")
        sections = sorted(self.hole_sections, key=lambda s: s.top_md)
        if abs(sections[0].top_md) > DEPTH_TOLERANCE:
            raise ValueError("First hole section must start at MD = 0.")
        for upper, lower in zip(sections[:-1], sections[1:]):
            if abs(upper.bottom_md - lower.top_md) > DEPTH_TOLERANCE:
                raise ValueError(
                    f"Hole sections '{upper.name}' and '{lower.name}' are not contiguous.")
        if sections[-1].bottom_md > self.trajectory.total_md + DEPTH_TOLERANCE:
            raise ValueError("Hole sections extend below the last survey station.")
        self.hole_sections = sections

    def _validate_clearances(self) -> None:
        for comp, top in zip(self.drill_string, self._string_tops):
            for sec in self.hole_sections:
                overlap = min(sec.bottom_md, top + comp.length) - max(sec.top_md, top)
                if overlap > DEPTH_TOLERANCE and sec.diameter <= comp.outer_diameter:
                    raise ValueError(
                        f"Hole diameter of '{sec.name}' ({sec.diameter:.4f} m) is not "
                        f"larger than OD of '{comp.name}' ({comp.outer_diameter:.4f} m).")

    # ---------------------------------------------------------- properties
    @property
    def total_depth(self) -> float:
        """Well TD [m MD] = bottom of the deepest hole section."""
        return self.hole_sections[-1].bottom_md

    @property
    def td_tvd(self) -> float:
        """TVD at well TD [m]."""
        return float(self.trajectory.tvd_at(self.total_depth))

    @property
    def bit_depth(self) -> float:
        """Bit MD [m] = total drill-string length."""
        return float(sum(c.length for c in self.drill_string))

    @property
    def bit_tvd(self) -> float:
        """Bit TVD [m]."""
        return float(self.trajectory.tvd_at(self.bit_depth))

    # ------------------------------------------------------------ lookups
    def hole_section_index_at(self, md) -> np.ndarray:
        """Index of the hole section containing each MD (segment mid-points)."""
        bottoms = np.array([s.bottom_md for s in self.hole_sections])
        idx = np.searchsorted(bottoms, np.asarray(md), side="left")
        return np.clip(idx, 0, len(self.hole_sections) - 1)

    def string_component_index_at(self, md) -> np.ndarray:
        """Index of the drill-string component containing each MD."""
        idx = np.searchsorted(self._string_tops, np.asarray(md), side="right") - 1
        return np.clip(idx, 0, len(self.drill_string) - 1)

    def breakpoints(self) -> np.ndarray:
        """MDs where geometry changes (component/section boundaries, bit, TD)."""
        points = [0.0, self.bit_depth, self.total_depth]
        points += list(self._string_tops) + [s.bottom_md for s in self.hole_sections]
        pts = np.unique(np.round(np.asarray(points, dtype=float), 6))
        return pts[(pts >= 0) & (pts <= self.total_depth + DEPTH_TOLERANCE)]

    def surface_component(self) -> DrillStringComponent:
        """Drill-string component crossing the wellhead (used for displacement)."""
        return self.drill_string[0]
