"""Physical description of the well system: trajectory, geometry, mud, operations, segments."""
