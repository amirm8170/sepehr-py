"""
Operating conditions and the pressure window.

``OperatingConditions`` is a *snapshot* of what the rig is doing (used by the
steady-state solver and, step by step, by the dynamic model).

Back-pressure modes
-------------------
* ``"specified"`` — the surface back pressure (SBP) is given directly
  (idealised pressure-controlled choke / input value).
* ``"choke"``     — SBP results from the choke equation for the current
  choke opening and the flow through the choke
  (Q_choke = Q_pump + Q_backpressure_pump + pipe displacement).

Pipe movement (simplified swab/surge, MODELING CHOICE REQUIRING VALIDATION)
--------------------------------------------------------------------------
``pipe_velocity`` > 0 means the string moves DOWN (running in → surge),
< 0 means UP (pulling out → swab). See ``hydraulics.hydraulics`` for the
Burkhardt-type clinging-constant model.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, replace

logger = logging.getLogger(__name__)

BACK_PRESSURE_MODES = ("specified", "choke")
PIPE_END_TYPES = ("closed", "open")


@dataclass
class OperatingConditions:
    """
    Instantaneous operating conditions (SI units).

    pump_rate                 Q_pump [m³/s] (>= 0)
    back_pressure_mode        "specified" | "choke"
    surface_back_pressure     SBP [Pa gauge] (used in "specified" mode)
    choke_opening             u [-] in [0, 1] (used in "choke" mode)
    backpressure_pump_rate    Q_bpp [m³/s] (>= 0): MPD back-pressure pump flow
                              injected at the wellhead, through the choke only
    pipe_velocity             v_p [m/s] (+ down, − up)
    pipe_end                  "closed" | "open" (displacement area for swab/surge)
    clinging_constant         K_c [-] (Burkhardt 1961; ≈ 0.4–0.5 laminar)
    choke_downstream_pressure P_0 [Pa gauge] (separator / atmosphere)
    """

    pump_rate: float
    back_pressure_mode: str = "specified"
    surface_back_pressure: float = 0.0
    choke_opening: float = 1.0
    backpressure_pump_rate: float = 0.0
    pipe_velocity: float = 0.0
    pipe_end: str = "closed"
    clinging_constant: float = 0.45
    choke_downstream_pressure: float = 0.0

    def __post_init__(self) -> None:
        if self.pump_rate < 0:
            logger.error("Invalid negative flow rate: %.4g m³/s", self.pump_rate)
            raise ValueError("Pump rate must be >= 0.")
        if self.backpressure_pump_rate < 0:
            raise ValueError("Back-pressure pump rate must be >= 0.")
        if self.back_pressure_mode not in BACK_PRESSURE_MODES:
            raise ValueError(f"back_pressure_mode must be one of {BACK_PRESSURE_MODES}.")
        if not 0.0 <= self.choke_opening <= 1.0:
            raise ValueError("Choke opening must be within [0, 1].")
        if self.surface_back_pressure < 0:
            raise ValueError("Surface back pressure must be >= 0 (gauge).")
        if self.pipe_end not in PIPE_END_TYPES:
            raise ValueError(f"pipe_end must be one of {PIPE_END_TYPES}.")
        if not 0.0 <= self.clinging_constant <= 1.0:
            raise ValueError("Clinging constant must be within [0, 1].")

    def with_changes(self, **changes) -> "OperatingConditions":
        """Copy with modified fields (validation re-runs)."""
        return replace(self, **changes)


@dataclass
class PressureWindow:
    """
    Operating pressure window at the BHP reference depth (well TD).

    pore_pressure       P_pore [Pa]  — below it: underbalance / kick risk
    fracture_pressure   P_frac [Pa]  — above it: losses / fracture risk
    target_bhp          P_target [Pa]
    warning_margin      [Pa] — "approaching limit" warning distance
    reference_tvd       [m] TVD at which the window is defined
    allow_target_outside_window : bool
    """

    pore_pressure: float
    fracture_pressure: float
    target_bhp: float
    reference_tvd: float
    warning_margin: float = 0.0
    allow_target_outside_window: bool = False

    def __post_init__(self) -> None:
        if self.pore_pressure <= 0 or self.fracture_pressure <= 0:
            raise ValueError("Pore and fracture pressures must be > 0.")
        if self.fracture_pressure <= self.pore_pressure:
            raise ValueError("Fracture pressure must exceed pore pressure.")
        if self.warning_margin < 0:
            raise ValueError("Warning margin must be >= 0.")
        inside = self.pore_pressure <= self.target_bhp <= self.fracture_pressure
        if not inside:
            if self.allow_target_outside_window:
                logger.warning("Target BHP is outside the pore–fracture window (allowed by config).")
            else:
                raise ValueError("Target BHP must lie inside the pressure window "
                                 "(set allow_target_outside_window to override).")

    @property
    def width(self) -> float:
        """Window width P_frac − P_pore [Pa]."""
        return self.fracture_pressure - self.pore_pressure
