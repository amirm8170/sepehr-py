"""
Drilling-fluid (mud) properties.

The mud is described by density, rheological parameters and gel strengths.
Internally everything is SI:

    density        ρ   [kg/m³]
    plastic visc.  μ_p [Pa·s]     (field: PV in cP)
    yield point    τ_y [Pa]       (field: YP in lbf/100 ft²)
    gel strengths  τ_g [Pa]       (field: lbf/100 ft²)

Assumption (D): incompressible for hydrostatics/friction; compressibility
enters only the lumped dynamic model via the bulk modulus β (see
``dynamics.dynamic_model``). Isothermal: properties do not vary with P or T.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from ..hydraulics.rheology import BinghamPlastic, RheologyModel, build_rheology


@dataclass
class MudProperties:
    """
    Drilling-fluid properties in SI units.

    Attributes
    ----------
    density : float
        Mud density ρ [kg/m³] (> 0).
    plastic_viscosity : float
        Bingham plastic viscosity μ_p [Pa·s] (>= 0).
    yield_point : float
        Bingham yield stress τ_y [Pa] (>= 0).
    gel_10s, gel_10min : float, optional
        Gel strengths [Pa]. Used for the break-circulation pressure estimate.
    rheology_model : str
        Name of the rheology model ("bingham_plastic" initially).
    bulk_modulus : float
        Effective bulk modulus β [Pa] for the dynamic model. Typical
        water-based mud ≈ 1.5–2.2e9 Pa (modeling parameter; calibrate).
    """

    density: float
    plastic_viscosity: float
    yield_point: float
    gel_10s: Optional[float] = None
    gel_10min: Optional[float] = None
    rheology_model: str = "bingham_plastic"
    bulk_modulus: float = 1.5e9

    def __post_init__(self) -> None:
        if self.density <= 0:
            raise ValueError("Mud density must be > 0.")
        if self.plastic_viscosity < 0:
            raise ValueError("Plastic viscosity (PV) must be >= 0.")
        if self.yield_point < 0:
            raise ValueError("Yield point (YP) must be >= 0.")
        for gel in (self.gel_10s, self.gel_10min):
            if gel is not None and gel < 0:
                raise ValueError("Gel strength must be >= 0.")
        if self.bulk_modulus <= 0:
            raise ValueError("Bulk modulus must be > 0.")

    def rheology(self) -> RheologyModel:
        """Return the rheology strategy object for this mud."""
        return build_rheology(self.rheology_model,
                              plastic_viscosity=self.plastic_viscosity,
                              yield_stress=self.yield_point)

    def with_changes(self, **changes) -> "MudProperties":
        """Return a copy with some attributes changed (used by sensitivity analysis)."""
        data = dict(self.__dict__)
        data.update(changes)
        return MudProperties(**data)


def mud_from_fann(density: float, theta_600: float, theta_300: float,
                  **kwargs) -> MudProperties:
    """
    Build MudProperties from Fann VG-meter dial readings (600/300 rpm).

    Uses the standard Bingham interpretation (API RP 13B-1):
        PV [cP] = θ600 − θ300,   YP [lbf/100 ft²] = θ300 − PV
    """
    bingham = BinghamPlastic.from_fann(theta_600, theta_300)
    return MudProperties(density=density,
                         plastic_viscosity=bingham.plastic_viscosity,
                         yield_point=bingham.yield_stress, **kwargs)
