"""
Physical and numerical constants used throughout the simulator.

All values are in SI units. Unit-conversion factors live in
``mpd_sim.units``; this module only holds *physical* constants and
*numerical/modeling* defaults so that no "magic numbers" appear inside the
calculation functions.

Each constant states its source or its status (standard value, literature
value, or modeling choice requiring validation).
"""

from __future__ import annotations

# ---------------------------------------------------------------------------
# Physical constants (standard values)
# ---------------------------------------------------------------------------

#: Standard gravitational acceleration [m/s²] (CGPM 1901, exact by definition).
GRAVITY: float = 9.80665

#: Atmospheric pressure [Pa]. Only used if absolute pressures are requested;
#: the simulator works internally in *gauge* pressure (atmosphere = 0 Pa).
ATMOSPHERIC_PRESSURE: float = 101_325.0

# ---------------------------------------------------------------------------
# Flow-regime constants (literature)
# ---------------------------------------------------------------------------

#: Newtonian laminar→turbulent critical Reynolds number for pipe flow.
#: Hanks (1963) Bingham criterion reduces to this value when He → 0.
NEWTONIAN_CRITICAL_REYNOLDS: float = 2100.0

#: Constant in the Hanks (1963) critical-Reynolds criterion for Bingham
#: plastics:  x_c / (1 - x_c)^3 = He / 16800.
HANKS_CONSTANT: float = 16800.0

#: Blasius-type smooth-pipe turbulent Fanning friction factor
#: f = a * Re^-b (Blasius 1913; used with plastic viscosity in
#: Bourgoyne et al., Applied Drilling Engineering, SPE Textbook Vol. 2, 1986).
BLASIUS_COEFFICIENT: float = 0.0791
BLASIUS_EXPONENT: float = 0.25

#: Effective-diameter factor for turbulent annular flow:
#: D_eff = 0.816 (D_hole - D_pipe)   (Bourgoyne et al., 1986, slot-flow
#: equivalence; 0.816 = sqrt(2/3)).
ANNULUS_TURBULENT_DIAMETER_FACTOR: float = 0.816

#: Darby, Mun & Boger (1992) turbulent Bingham friction-factor constants:
#: f_T = 10^a Re^-0.193, a = -1.47 [1 + 0.146 exp(-2.9e-5 He)]
DARBY_A0: float = -1.47
DARBY_A1: float = 0.146
DARBY_A2: float = 2.9e-5
DARBY_RE_EXPONENT: float = 0.193
#: Blending exponent m = 1.7 + 40000/Re (Darby et al., 1992).
DARBY_BLEND_M0: float = 1.7
DARBY_BLEND_M1: float = 40_000.0

# ---------------------------------------------------------------------------
# Numerical defaults (modeling choices requiring validation)
# ---------------------------------------------------------------------------

#: Velocities below this magnitude [m/s] are treated as "no flow".
ZERO_VELOCITY_TOLERANCE: float = 1.0e-9

#: Flow rates below this magnitude [m³/s] are treated as "no flow".
ZERO_FLOW_TOLERANCE: float = 1.0e-12

#: Max iterations / tolerance for implicit friction-factor equations.
FRICTION_MAX_ITERATIONS: int = 100
FRICTION_TOLERANCE: float = 1.0e-10

#: Tolerance [m] used when comparing depths (e.g. TVD <= MD checks).
DEPTH_TOLERANCE: float = 1.0e-6

#: Allowed mismatch [m] between user TVD and minimum-curvature TVD
#: before a warning is logged.
TVD_CONSISTENCY_TOLERANCE: float = 1.0
