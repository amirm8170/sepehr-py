# CLAUDE.md — MPD well hydraulics simulator (thesis project)

## Purpose
- Graduate-thesis simulator (Univ. of Tehran): Stage A steady-state Bingham hydraulics → Stage B dynamic MPD + PID BHP control.
- Thesis proposal PDF was NOT available; scope = user's written spec. Unspecified correlations are labelled "Modeling choice requiring validation".
- All bundled data are synthetic demonstration data — never claim validation.

## Stack / run
- Python 3.9 (system) + `.venv` (numpy, pandas, scipy, matplotlib, PyYAML, pytest). Keep 3.9-compatible: `from __future__ import annotations`, no `X | Y` at runtime, no `match`.
- `.venv/bin/python main.py [--scenario all|base|pump_change|pid_control|<name>] [--sensitivity] [--validate] [--list]`
- `.venv/bin/pytest` (123 tests incl. headless GUI tests, ~25 s). Full CLI run ~20 s. Outputs → `outputs/` (git-ignored).
- `examples/build_demo_reference.py` regenerates `data/validation/demo_reference_steady_state.csv` (independent ADE hand calc).

- Desktop app: `.venv/bin/python gui.py` (PySide6 6.10 + embedded matplotlib). User explicitly rejected a web UI — keep it a native desktop app. Engine never imports gui/.

## Architecture (mpd_sim/)
- `units.py` exact factors + UNIT_TABLE; `constants.py` all literature/numerical constants (no magic numbers in code).
- `io/loaders.py`: ONLY place field units enter. Config keys carry unit suffix (`density_ppg`, `_emw_ppg` for pressures). `choke_opening_frac: auto` → inverse choke curve to hit target BHP.
- `models/`: trajectory (min-curvature), well (hole sections, string surface→bit, bit), segment (FlowPathGrid arrays + WellSegment objects), operations (OperatingConditions, PressureWindow).
- `hydraulics/`: rheology (Strategy; Bingham full, PowerLaw/HB constitutive only), friction (Buckingham–Reiner pipe, exact slot annulus, Blasius, Darby), pressure_loss (FrictionModel strategies `bourgoyne` default / `darby`; Pipe/Annulus/Bit/Choke loss classes), hydraulics.py (SteadyStateHydraulicsSolver).
- `dynamics/`: FrictionTable (Stage-A solver tabulated over q, v_p), QuasiSteadyModel, LumpedMPDModel (Kaasa 2012 3-state ODE, solve_ivp LSODA per dt), choke (Cv US→SI), pid, simulator (loop + Actuator), performance metrics, pressure_window, transient.py (interface only).
- `scenarios/runner.py` builds everything from base_case.yaml + scenarios.yaml entry; `main.py` CLI.

## Desktop GUI (gui/, gui.py)
- `state.AppState(QObject)`: working case = dict shaped like base_case.yaml; signals `case_loaded` (rebuild input widgets), `config_edited` (debounced 300 ms → recompute), `units_changed`. Setup/steady results cached by config JSON.
- `widgets.py`: PlotCanvas (matplotlib + NavigationToolbar), KpiCard, Banner, StatusBadge, DataTable (pandas model), bound inputs (`quantity_spin` keeps the unit already in the config), `Worker` (QThread; fn(progress, *args)).
- `pages/*.py` subclass `pages/base.Page` (scrollable; hooks on_case_loaded / on_config_edited / on_units_changed). `results_view.ResultView` shared by dynamic + PID pages. `plots.py` = all chart drawing.
- macOS gotcha: files inside `.venv` get the BSD `hidden` flag → Qt ignores its platform plugins ("Could not find the Qt platform plugin"). `gui/app.unhide_qt_plugins()` clears it at start; tests call it too. Headless: `QT_QPA_PLATFORM=offscreen`.
- QLocale forced to en_US without group separators ("." decimals).
- Model page renders README sections 1, 8, 9, 10, 16, 17 by heading number — keep README numbering.

## Conventions / gotchas
- SI internally, gauge pressure. BHP reference = annulus at well TD. SBP = annulus pressure at wellhead upstream of choke.
- Two ECDs: `ecd_conventional` (excl. SBP) and `emw_bhp` (incl. SBP). Keep both.
- Sign: string flow + down, annulus + up, pipe velocity + down (surge).
- Exported CSVs keep SI columns and ADD field columns (`_psi/_bar/_ppg/_gpm`); never overwrite.
- Choke actuation PID is reverse acting; gains "per bar" via `error_scale`. Back-pressure gains in `controller.back_pressure_gains` (bar/bar).
- `event_time_s` may be a list → per-event metrics `eventN_*`; setpoint step detected from target change vs target before event.
- md grid merges breakpoints within DEPTH_TOLERANCE (ft→m round-off created zero-length segments before).
- Tests must use independent references (hand calcs, analytic solutions, ADE field formulas), not copies of the implementation.
- Plots: one y-axis per panel, palette in `visualization/plots.py::COLORS`, footer states data status.

## Current state
- Base case: BHP 380.4 bar, SPP 172.6 bar, SBP 11.1 bar (auto choke 0.426). Demo validation: annulus loss −9 % vs ADE linearised slot (expected), others < 1.5 %.
- PID gains Kp 0.03, Ki 0.008 tuned on synthetic scenario 10 only.
