"""
MPD well hydraulics simulator — command-line entry point.

Examples
--------
    python main.py                          # steady state + all dynamic scenarios
    python main.py --scenario base          # steady-state base case only
    python main.py --scenario pump_change   # pump-rate increase scenario
    python main.py --scenario pid_control   # closed-loop PID BHP control
    python main.py --list                   # list scenarios
    python main.py --sensitivity            # steady-state sensitivity analysis
    python main.py --validate               # demonstration validation workflow

Outputs are written to ./outputs/<scenario>/ (CSV, JSON, PNG).

DISCLAIMER: research/educational simulator — not field-certified drilling
control software.
"""

from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from mpd_sim.logging_config import setup_logging  # noqa: E402

logger = logging.getLogger("main")


def parse_args(argv=None) -> argparse.Namespace:
    p = argparse.ArgumentParser(description="MPD well hydraulics simulator (research/educational).")
    p.add_argument("--scenario", default="all",
                   help="'all' (default), 'base'/'steady_state', a scenario name or alias")
    p.add_argument("--config", default=str(ROOT / "config" / "base_case.yaml"))
    p.add_argument("--scenarios", default=str(ROOT / "config" / "scenarios.yaml"))
    p.add_argument("--output-dir", default=str(ROOT / "outputs"))
    p.add_argument("--sensitivity", action="store_true", help="run steady-state sensitivity analysis")
    p.add_argument("--validate", action="store_true", help="run the demonstration validation workflow")
    p.add_argument("--no-plots", action="store_true", help="skip PNG generation")
    p.add_argument("--list", action="store_true", help="list available scenarios and exit")
    p.add_argument("--log-level", default="INFO")
    return p.parse_args(argv)


def list_scenarios(scenarios_path: str) -> None:
    from mpd_sim.scenarios.runner import STEADY_STATE, load_scenario_catalog
    cat = load_scenario_catalog(scenarios_path)
    print(f"{STEADY_STATE:28s} steady-state base case (Stage A)")
    for name, sc in cat["scenarios"].items():
        print(f"{name:28s} {sc.get('description', '')}")
    print("\nAliases: " + ", ".join(f"{k} -> {v}" for k, v in cat["aliases"].items()))


def run_sensitivity(config: str, output_dir: Path, make_plots: bool) -> None:
    from mpd_sim.analysis.sensitivity import one_at_a_time, sweep
    from mpd_sim.io.exporters import export_dataframe
    from mpd_sim.io.loaders import load_setup
    from mpd_sim.units import BAR_TO_PA, GPM_TO_M3S, PPG_TO_KGM3
    from mpd_sim.visualization import plots

    setup = load_setup(config)
    out = output_dir / "sensitivity"
    table = one_at_a_time(setup, 0.10)
    export_dataframe(table, out / "sensitivity_oat.csv",
                     header_note="One-at-a-time ±10 % sensitivity — synthetic demonstration case")
    q0, rho0 = setup.conditions.pump_rate, setup.mud.density
    factors = [0.5, 0.6, 0.7, 0.8, 0.9, 1.0, 1.1, 1.2, 1.3]
    sw_q = sweep(setup, "pump_rate", factors, lambda f: f * q0 / GPM_TO_M3S)
    sw_mw = sweep(setup, "mud_weight", [0.94, 0.97, 1.0, 1.03, 1.06],
                  lambda f: f * rho0 / PPG_TO_KGM3)
    export_dataframe(sw_q, out / "sweep_pump_rate.csv")
    export_dataframe(sw_mw, out / "sweep_mud_weight.csv")
    if make_plots:
        plots.plot_tornado(table, "bhp", out / "tornado_bhp.png", BAR_TO_PA, "bar")
        plots.plot_tornado(table, "spp", out / "tornado_spp.png", BAR_TO_PA, "bar")
        plots.plot_tornado(table, "ecd", out / "tornado_ecd.png", PPG_TO_KGM3, "ppg")
        plots.plot_sweep(sw_q, "pump rate", out / "sweep_pump_rate.png", "Pump rate [gpm]")
        plots.plot_sweep(sw_mw, "mud weight", out / "sweep_mud_weight.png", "Mud weight [ppg]")
    logger.info("Sensitivity results written to %s", out)


def run_validation(config_root: Path, scenarios: str, output_dir: Path,
                   make_plots: bool) -> None:
    from mpd_sim.io.exporters import export_dataframe, export_json
    from mpd_sim.io.loaders import load_reference_csv, load_setup, load_yaml
    from mpd_sim.scenarios.runner import build_simulator, load_scenario_catalog
    from mpd_sim.units import BAR_TO_PA
    from mpd_sim.validation.validation import (DEMO_DISCLAIMER, compare_time_series,
                                               summarize, validate_steady_state)
    from mpd_sim.visualization import plots

    out = output_dir / "validation"
    # 1) Steady state vs independent hand calculation (synthetic demonstration)
    setup = load_setup(config_root / "config" / "validation_demo_case.yaml")
    result = setup.solver.solve(setup.conditions)
    ref = load_reference_csv(config_root / "data" / "validation" / "demo_reference_steady_state.csv")
    table = validate_steady_state(result, ref)
    export_dataframe(table, out / "steady_state_validation.csv", field_units=False,
                     header_note=DEMO_DISCLAIMER)
    export_dataframe(summarize(table), out / "steady_state_validation_summary.csv",
                     field_units=False, header_note=DEMO_DISCLAIMER)
    print("\nSteady-state comparison (" + DEMO_DISCLAIMER + ")")
    print(table[["quantity", "unit", "reference_value", "model_value",
                 "percentage_error"]].to_string(index=False, float_format="%.2f"))
    if make_plots:
        psi = table[table["unit"] == "psi"]
        plots.plot_parity(psi, out / "parity_steady_state.png",
                          "synthetic demonstration (hand calc)", "[psi]",
                          footer=DEMO_DISCLAIMER)

    # 2) Dynamic: lumped model vs quasi-steady model (model-to-model comparison)
    base = load_yaml(config_root / "config" / "base_case.yaml")
    cat = load_scenario_catalog(scenarios)
    scen = cat["scenarios"]["pump_rate_increase"]
    lumped = build_simulator(base, "pump_rate_increase", scen).run().timeseries
    qs_cfg = dict(base, dynamics=dict(base["dynamics"], model="quasi_steady"))
    quasi = build_simulator(qs_cfg, "pump_rate_increase_qs", scen).run().timeseries
    stats = compare_time_series(lumped["time_s"], lumped["bhp_pa"],
                                quasi["time_s"], quasi["bhp_pa"])
    export_json({**stats, "comparison": "LumpedMPDModel vs QuasiSteadyModel BHP, pump_rate_increase",
                 "data_status": "model-to-model comparison — " + DEMO_DISCLAIMER},
                out / "dynamic_model_comparison.json")
    if make_plots:
        plots.plot_series_comparison(quasi["time_s"], quasi["bhp_pa"] / BAR_TO_PA,
                                     lumped["bhp_pa"] / BAR_TO_PA,
                                     out / "dynamic_bhp_comparison.png",
                                     "quasi-steady (reference) vs lumped (model)", "BHP [bar g]",
                                     footer="Model-to-model comparison — " + DEMO_DISCLAIMER)
    logger.info("Validation outputs written to %s", out)


def main(argv=None) -> int:
    args = parse_args(argv)
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    setup_logging(args.log_level, str(output_dir / "simulation.log"))
    if args.list:
        list_scenarios(args.scenarios)
        return 0

    from mpd_sim.scenarios.runner import run_named
    try:
        results = run_named(args.scenario, args.config, args.scenarios, output_dir,
                            make_plots=not args.no_plots)
    except (KeyError, ValueError) as exc:
        logger.error("%s", exc)
        return 2

    for name, res in results.items():
        if hasattr(res, "bhp"):
            print(f"\n[{name}] BHP {res.bhp / 1e5:.2f} bar | SPP {res.spp / 1e5:.2f} bar | "
                  f"SBP {res.surface_back_pressure / 1e5:.2f} bar | ECD(conv) "
                  f"{res.ecd_conventional:.1f} kg/m³ | status {res.window_status}")
            print(res.pressure_breakdown().assign(
                pressure_bar=lambda d: d.pressure_pa / 1e5).to_string(index=False))
        else:
            m = res.metrics
            control = (f", settling {m['settling_time_s']:.1f} s (PID)"
                       if res.controller_enabled else " (open loop)")
            print(f"[{name}] BHP {m['min_bhp_pa'] / 1e5:.2f}–{m['max_bhp_pa'] / 1e5:.2f} bar, "
                  f"outside window {m['time_outside_window_s']:.1f} s{control}")
    if args.sensitivity:
        run_sensitivity(args.config, output_dir, not args.no_plots)
    if args.validate:
        run_validation(ROOT, args.scenarios, output_dir, not args.no_plots)
    print(f"\nOutputs: {output_dir.resolve()}")
    print("NOTE: synthetic demonstration data — not field-validated. "
          "Research/educational software, not field-certified control software.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
