"""
Colours, display units, Qt style sheet and matplotlib styling.

The simulator works in SI. Values are converted to the selected display
system only when they are shown (cards, tables, charts).
"""

from __future__ import annotations

from dataclasses import dataclass

import matplotlib as mpl

from mpd_sim.units import BAR_TO_PA, FT_TO_M, GPM_TO_M3S, LPM_TO_M3S, PPG_TO_KGM3, PSI_TO_PA

#: Categorical palette (fixed order) and reserved status colours.
COLORS = {
    "s1": "#2a78d6", "s2": "#eb6834", "s3": "#1baf7a", "s4": "#eda100", "s5": "#4a3aa7",
    "muted": "#8a8984", "text": "#1d1d1b", "grid": "#e4e3df",
    "good": "#1f9d55", "good_bg": "#e6f4ec",
    "warn": "#b7791f", "warn_bg": "#fdf3dc",
    "critical": "#d64545", "critical_bg": "#fbe9e9",
    "accent": "#2a78d6", "panel": "#ffffff", "window": "#f4f5f7", "border": "#dcdee3",
    "sidebar": "#1f2a37", "sidebar_text": "#c9d1db",
}


@dataclass(frozen=True)
class DisplayUnits:
    """Unit labels and SI → display divisors for one display system."""

    name: str
    pressure: str
    pressure_factor: float
    density: str
    density_factor: float
    flow: str
    flow_factor: float
    depth: str
    depth_factor: float

    def p(self, value_pa):
        return value_pa / self.pressure_factor

    def rho(self, value_kgm3):
        return value_kgm3 / self.density_factor

    def q(self, value_m3s):
        return value_m3s / self.flow_factor

    def z(self, value_m):
        return value_m / self.depth_factor


UNIT_SYSTEMS = {
    "Oilfield (psi, ppg, gpm, ft)": DisplayUnits("field", "psi", PSI_TO_PA, "ppg", PPG_TO_KGM3,
                                                 "gpm", GPM_TO_M3S, "ft", FT_TO_M),
    "Metric (bar, kg/m³, L/min, m)": DisplayUnits("metric", "bar", BAR_TO_PA, "kg/m³", 1.0,
                                                  "L/min", LPM_TO_M3S, "m", 1.0),
}

#: Readable labels for configuration unit tags.
UNIT_TAG_LABELS = {
    "m": "m", "ft": "ft", "in": "in", "mm": "mm", "32nds": "1/32 in",
    "pa": "Pa", "kpa": "kPa", "mpa": "MPa", "bar": "bar", "psi": "psi",
    "m3_s": "m³/s", "m3_min": "m³/min", "gpm": "gpm", "lpm": "L/min",
    "kg_m3": "kg/m³", "ppg": "ppg", "sg": "SG", "pa_s": "Pa·s", "cp": "cP",
    "lbf_100ft2": "lbf/100 ft²", "m_s": "m/s", "ft_s": "ft/s", "ft_min": "ft/min",
    "m_min": "m/min", "s": "s", "min": "min", "h": "h", "m3": "m³", "bbl": "bbl", "l": "L",
    "psi_s": "psi/s", "bar_s": "bar/s", "frac": "fraction",
}

STYLE_SHEET = f"""
QMainWindow, QWidget#page {{ background: {COLORS['window']}; }}
QWidget {{ font-size: 13px; color: {COLORS['text']}; }}
QListWidget#nav {{
    background: {COLORS['sidebar']}; border: none; padding: 8px 6px; outline: 0;
    color: {COLORS['sidebar_text']}; font-size: 14px;
}}
QListWidget#nav::item {{ padding: 10px 12px; border-radius: 6px; margin: 2px 4px; }}
QListWidget#nav::item:selected {{ background: {COLORS['accent']}; color: white; }}
QListWidget#nav::item:hover:!selected {{ background: #2c3a4b; }}
QLabel#navTitle {{ background: {COLORS['sidebar']}; color: white; font-size: 16px;
                   font-weight: 700; padding: 18px 16px 2px 16px; }}
QLabel#navSubtitle {{ background: {COLORS['sidebar']}; color: {COLORS['sidebar_text']};
                      font-size: 11px; padding: 0 16px 14px 16px; }}
QLabel#pageTitle {{ font-size: 24px; font-weight: 700; }}
QLabel#pageSubtitle {{ color: {COLORS['muted']}; font-size: 13px; }}
QFrame#card {{ background: {COLORS['panel']}; border: 1px solid {COLORS['border']};
               border-radius: 8px; }}
QLabel#cardLabel {{ color: {COLORS['muted']}; font-size: 12px; }}
QLabel#cardValue {{ font-size: 21px; font-weight: 600; }}
QLabel#cardNote {{ font-size: 11px; }}
QGroupBox {{ background: {COLORS['panel']}; border: 1px solid {COLORS['border']};
             border-radius: 8px; margin-top: 14px; padding: 12px 10px 10px 10px;
             font-weight: 600; }}
QGroupBox::title {{ subcontrol-origin: margin; left: 12px; padding: 0 4px; }}
QPushButton {{ background: white; border: 1px solid {COLORS['border']}; border-radius: 6px;
               padding: 6px 14px; }}
QPushButton:hover {{ border-color: {COLORS['accent']}; }}
QPushButton#primary {{ background: {COLORS['accent']}; color: white; border: none;
                       font-weight: 600; padding: 8px 18px; }}
QPushButton#primary:hover {{ background: #1f63b5; }}
QPushButton#primary:disabled {{ background: #9dbbe2; }}
QTabWidget::pane {{ border: 1px solid {COLORS['border']}; border-radius: 6px;
                    background: {COLORS['panel']}; top: -1px; }}
QTabBar::tab {{ padding: 7px 14px; border: none; color: {COLORS['muted']}; }}
QTabBar::tab:selected {{ color: {COLORS['accent']}; border-bottom: 2px solid {COLORS['accent']};
                         font-weight: 600; }}
QTableView {{ background: white; border: 1px solid {COLORS['border']}; border-radius: 6px;
              gridline-color: {COLORS['grid']}; selection-background-color: #d6e6fa;
              selection-color: {COLORS['text']}; }}
QHeaderView::section {{ background: #f0f1f3; border: none;
                        border-bottom: 1px solid {COLORS['border']}; padding: 5px;
                        font-weight: 600; color: #4a4a48; }}
QDoubleSpinBox, QSpinBox, QComboBox, QLineEdit {{
    background: white; border: 1px solid {COLORS['border']}; border-radius: 5px;
    padding: 4px 6px; min-height: 22px;
}}
QDoubleSpinBox:focus, QSpinBox:focus, QComboBox:focus, QLineEdit:focus {{
    border-color: {COLORS['accent']};
}}
QProgressBar {{ border: 1px solid {COLORS['border']}; border-radius: 5px; background: white;
                text-align: center; height: 16px; }}
QProgressBar::chunk {{ background: {COLORS['accent']}; border-radius: 4px; }}
QStatusBar {{ background: white; border-top: 1px solid {COLORS['border']}; }}
QTextBrowser {{ background: white; border: 1px solid {COLORS['border']}; border-radius: 8px;
                padding: 12px; }}
QScrollArea {{ border: none; background: transparent; }}
"""


def apply_matplotlib_style() -> None:
    """Consistent, recessive chart styling for every embedded figure."""
    mpl.rcParams.update({
        "axes.prop_cycle": mpl.cycler(color=[COLORS[k] for k in ("s1", "s2", "s3", "s4", "s5")]),
        "axes.spines.top": False, "axes.spines.right": False,
        "axes.edgecolor": "#9a9995", "axes.grid": True, "grid.color": COLORS["grid"],
        "grid.linewidth": 0.7, "axes.titlesize": 11, "axes.titleweight": "bold",
        "axes.titlelocation": "left", "axes.labelsize": 10, "xtick.labelsize": 9,
        "ytick.labelsize": 9, "legend.fontsize": 9, "legend.frameon": False,
        "lines.linewidth": 1.9, "figure.facecolor": "white", "axes.facecolor": "white",
        "font.family": "sans-serif",
    })
