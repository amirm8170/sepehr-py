"""Main window: navigation on the left, pages on the right, menus and status bar."""

from __future__ import annotations

from pathlib import Path

import yaml
from PySide6.QtCore import QSize, Qt
from PySide6.QtGui import QAction, QActionGroup, QKeySequence
from PySide6.QtWidgets import (QFileDialog, QHBoxLayout, QLabel, QListWidget, QListWidgetItem,
                               QMainWindow, QMessageBox, QStackedWidget, QStyle, QVBoxLayout,
                               QWidget)

from .pages.case_setup import CaseSetupPage
from .pages.dashboard import DashboardPage
from .pages.dynamic import DynamicPage
from .pages.model_info import ModelInfoPage
from .pages.pid_lab import PidLabPage
from .pages.sensitivity import SensitivityPage
from .pages.validation import ValidationPage
from .state import CASES, ROOT, AppState
from .theme import UNIT_SYSTEMS
from .widgets import StatusBadge

DISCLAIMER = ("Research / educational simulator — not field-certified drilling control software. "
              "Bundled data are synthetic demonstration data, not field or experimental validation.")

#: (navigation text, page class, standard icon)
PAGES = [
    ("Dashboard", DashboardPage, QStyle.SP_ComputerIcon),
    ("Dynamic scenarios", DynamicPage, QStyle.SP_MediaPlay),
    ("PID control lab", PidLabPage, QStyle.SP_BrowserReload),
    ("Sensitivity", SensitivityPage, QStyle.SP_FileDialogDetailedView),
    ("Validation", ValidationPage, QStyle.SP_DialogApplyButton),
    ("Case setup", CaseSetupPage, QStyle.SP_FileDialogContentsView),
    ("Model & assumptions", ModelInfoPage, QStyle.SP_MessageBoxInformation),
]


class MainWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.state = AppState()
        self.setWindowTitle("MPD Hydraulics Simulator")
        self.resize(1440, 920)

        central = QWidget()
        root = QHBoxLayout(central)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        side = QWidget()
        side.setFixedWidth(230)
        sl = QVBoxLayout(side)
        sl.setContentsMargins(0, 0, 0, 0)
        sl.setSpacing(0)
        title = QLabel("MPD Hydraulics")
        title.setObjectName("navTitle")
        subtitle = QLabel("Well hydraulics · dynamic MPD · BHP control")
        subtitle.setObjectName("navSubtitle")
        subtitle.setWordWrap(True)
        self.nav = QListWidget()
        self.nav.setObjectName("nav")
        self.nav.setIconSize(QSize(18, 18))
        sl.addWidget(title)
        sl.addWidget(subtitle)
        sl.addWidget(self.nav, 1)
        root.addWidget(side)

        self.stack = QStackedWidget()
        root.addWidget(self.stack, 1)
        self.pages = []
        for text, cls, icon in PAGES:
            page = cls(self.state)
            self.pages.append(page)
            self.stack.addWidget(page)
            item = QListWidgetItem(self.style().standardIcon(icon), text)
            self.nav.addItem(item)
        self.nav.currentRowChanged.connect(self._show_page)
        self.nav.setCurrentRow(0)
        self.setCentralWidget(central)

        self._build_menus()
        self.badge = StatusBadge()
        self.case_label = QLabel()
        self.statusBar().addPermanentWidget(self.case_label)
        self.statusBar().addPermanentWidget(self.badge)
        self.state.config_edited.connect(self._update_status)
        self.state.case_loaded.connect(self._update_status)
        self._update_status()

    # ------------------------------------------------------------------ menus
    def _build_menus(self) -> None:
        file_menu = self.menuBar().addMenu("&File")
        open_act = QAction("Open case (YAML)…", self, shortcut=QKeySequence.Open,
                           triggered=self.open_case)
        save_act = QAction("Save case as (YAML)…", self, shortcut=QKeySequence.SaveAs,
                           triggered=self.save_case)
        file_menu.addAction(open_act)
        file_menu.addAction(save_act)
        bundled = file_menu.addMenu("Load bundled case")
        for label, path in CASES.items():
            bundled.addAction(QAction(label, self,
                                      triggered=lambda _=False, p=path, l=label: self.load(p, l)))
        file_menu.addSeparator()
        file_menu.addAction(QAction("Quit", self, shortcut=QKeySequence.Quit, triggered=self.close))

        view = self.menuBar().addMenu("&View")
        group = QActionGroup(self)
        for name in UNIT_SYSTEMS:
            act = QAction(name, self, checkable=True, checked=name == self.state.units_name)
            act.triggered.connect(lambda _=False, n=name: self.state.set_units(n))
            group.addAction(act)
            view.addAction(act)
        view.addSeparator()
        for i, (text, _, _) in enumerate(PAGES):
            view.addAction(QAction(text, self, shortcut=f"Ctrl+{i + 1}",
                                   triggered=lambda _=False, r=i: self.nav.setCurrentRow(r)))

        help_menu = self.menuBar().addMenu("&Help")
        help_menu.addAction(QAction("Model && assumptions", self,
                                    triggered=lambda: self.nav.setCurrentRow(len(PAGES) - 1)))
        help_menu.addAction(QAction("About", self, triggered=self.about))

    # ---------------------------------------------------------------- actions
    def _show_page(self, row: int) -> None:
        self.stack.setCurrentIndex(row)
        self.pages[row].on_show()

    def load(self, path: Path, label: str) -> None:
        try:
            self.state.load_case(path, label)
        except Exception as exc:
            QMessageBox.critical(self, "Case not loaded", str(exc))

    def open_case(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Open case", str(ROOT / "config"),
                                              "YAML files (*.yaml *.yml)")
        if path:
            self.load(Path(path), Path(path).name)

    def save_case(self) -> None:
        path, _ = QFileDialog.getSaveFileName(self, "Save case", str(ROOT / "config" / "my_case.yaml"),
                                              "YAML files (*.yaml)")
        if path:
            Path(path).write_text(yaml.safe_dump(self.state.config, sort_keys=False), encoding="utf-8")
            self.statusBar().showMessage(f"Case saved to {path}", 5000)

    def about(self) -> None:
        QMessageBox.about(self, "About MPD Hydraulics Simulator",
                          "<h3>MPD Hydraulics Simulator</h3>"
                          "<p>Well hydraulics simulation for Managed Pressure Drilling and "
                          "dynamic bottomhole-pressure control (graduate thesis project).</p>"
                          "<p>Stage A: segment-based Bingham-plastic hydraulics.<br>"
                          "Stage B: lumped dynamic MPD model with PID BHP control.</p>"
                          f"<p><i>{DISCLAIMER}</i></p>")

    def _update_status(self) -> None:
        _, result, err = self.state.steady()
        self.case_label.setText(f"Case: {self.state.case_label}   ")
        self.badge.set_status(None if err or result is None else result.window_status)
        if err:
            self.statusBar().showMessage(f"Input error: {err}")
        else:
            self.statusBar().showMessage(DISCLAIMER)
