"""PID control lab: tune the controller and compare closed loop with open loop."""

from __future__ import annotations

import copy

import pandas as pd
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QButtonGroup, QCheckBox, QComboBox, QFormLayout, QGridLayout,
                               QGroupBox, QHBoxLayout, QLabel, QProgressBar, QPushButton,
                               QRadioButton, QSplitter, QVBoxLayout, QWidget)

from mpd_sim.io.loaders import read_quantity

from .. import plots
from ..widgets import Banner, DataTable, PlotCanvas, Worker, combo_input, plain_spin
from .base import Page
from .dynamic import simulate
from .results_view import ResultView, events_frame, metrics_frame


def closed_and_open(progress, config, name, scenario, compare: bool):
    """Run the scenario with PID, then (optionally) without it."""
    half = 0.5 if compare else 1.0
    closed = simulate(lambda f: progress(f * half), config, name, scenario)
    opened = None
    if compare:
        open_scen = copy.deepcopy(scenario)
        open_scen["controller"]["enabled"] = False
        opened = simulate(lambda f: progress(0.5 + 0.5 * f), config, name, open_scen)
    return closed, opened


class PidLabPage(Page):
    title = "PID control lab"
    subtitle = ("Closed loop: target BHP → error → PID → choke / SBP → well hydraulics → BHP → "
                "feedback. Tune the gains and compare with the uncontrolled response.")

    def __init__(self, state, parent=None) -> None:
        super().__init__(state, parent)
        self.worker = None
        self.data = None

        box = QGroupBox("Controller set-up")
        grid = QGridLayout(box)
        self.scenario = QComboBox()
        for name in state.catalog["scenarios"]:
            self.scenario.addItem(state.scenario_label(name), name)
        idx = self.scenario.findData("pid_control")
        self.scenario.setCurrentIndex(max(idx, 0))
        grid.addWidget(QLabel("Disturbance scenario"), 0, 0)
        grid.addWidget(self.scenario, 0, 1, 1, 3)
        self.choke_rb = QRadioButton("Choke opening")
        self.bp_rb = QRadioButton("SBP set-point (idealised)")
        self.choke_rb.setChecked(True)
        group = QButtonGroup(self)
        group.addButton(self.choke_rb)
        group.addButton(self.bp_rb)
        self.choke_rb.toggled.connect(self._build_gains)
        grid.addWidget(QLabel("Actuation"), 1, 0)
        grid.addWidget(self.choke_rb, 1, 1)
        grid.addWidget(self.bp_rb, 1, 2)
        self.compare = QCheckBox("Also run without control (open loop)")
        self.compare.setChecked(True)
        grid.addWidget(self.compare, 1, 3)
        self.gains_box = QWidget()
        self.gains_layout = QHBoxLayout(self.gains_box)
        self.gains_layout.setContentsMargins(0, 0, 0, 0)
        grid.addWidget(self.gains_box, 2, 0, 1, 4)
        run_row = QHBoxLayout()
        self.run_btn = QPushButton("▶  Run closed loop")
        self.run_btn.setObjectName("primary")
        self.run_btn.clicked.connect(self.run)
        self.progress = QProgressBar()
        self.progress.setVisible(False)
        run_row.addWidget(self.run_btn)
        run_row.addWidget(self.progress, 1)
        grid.addLayout(run_row, 3, 0, 1, 4)
        self.body.addWidget(box)

        self.banner = Banner("Choose a scenario and gains, then press <b>Run closed loop</b>.")
        self.body.addWidget(self.banner)

        self.results = QWidget()
        rl = QVBoxLayout(self.results)
        rl.setContentsMargins(0, 0, 0, 0)
        split = QSplitter(Qt.Horizontal)
        self.c_bhp = PlotCanvas(height=7)
        split.addWidget(self.c_bhp)
        self.t_cmp = DataTable(stretch=True)
        split.addWidget(self.t_cmp)
        split.setSizes([760, 380])
        rl.addWidget(split)
        self.c_err = PlotCanvas(height=5)
        rl.addWidget(self.c_err)
        rl.addWidget(QLabel("<b>Per-event metrics (PID)</b>"))
        self.t_events = DataTable(stretch=True)
        self.t_events.setMinimumHeight(140)
        rl.addWidget(self.t_events)
        rl.addWidget(QLabel("<b>Full closed-loop result</b>"))
        self.full = ResultView(self)
        rl.addWidget(self.full)
        self.results.setVisible(False)
        self.body.addWidget(self.results)
        self.body.addStretch(1)
        self._build_gains()

    def _actuation(self) -> str:
        return "choke" if self.choke_rb.isChecked() else "back_pressure"

    def _build_gains(self) -> None:
        while self.gains_layout.count():
            item = self.gains_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        ctrl = self.state.config["controller"]
        if self._actuation() == "choke":
            gains, unit = ctrl, "fraction / bar"
        else:
            gains = ctrl.setdefault("back_pressure_gains", {"kp": 0.6, "ki": 0.3, "kd": 0.0})
            unit = "bar SBP / bar"
        form = QFormLayout()
        row = QWidget()
        row.setLayout(form)
        boxes = QHBoxLayout()
        for key, label, default, step in (("kp", f"Kp [{unit}]", 0.03, 0.005),
                                          ("ki", f"Ki [{unit}·s⁻¹]", 0.008, 0.001),
                                          ("kd", f"Kd [{unit}·s]", 0.0, 0.005)):
            f = QFormLayout()
            f.addRow(label, plain_spin(self.state, gains, key, default, 0, 100, step, 4))
            w = QWidget()
            w.setLayout(f)
            boxes.addWidget(w)
        f = QFormLayout()
        f.addRow("Anti-windup", combo_input(self.state, ctrl, "anti_windup",
                                            {"clamping": "Clamping", "back_calculation":
                                             "Back-calculation", "none": "None"}))
        f.addRow("Derivative filter [s]", plain_spin(self.state, ctrl, "derivative_filter_time_s",
                                                     1.0, 0, 100, 0.5, 2))
        w = QWidget()
        w.setLayout(f)
        boxes.addWidget(w)
        holder = QWidget()
        holder.setLayout(boxes)
        self.gains_layout.addWidget(holder)

    def on_case_loaded(self) -> None:
        self._build_gains()
        self.results.setVisible(False)

    def run(self) -> None:
        name = self.scenario.currentData()
        scen = copy.deepcopy(self.state.catalog["scenarios"][name])
        scen.setdefault("dynamics", {})["actuation"] = self._actuation()
        scen.setdefault("controller", {})["enabled"] = True
        self.run_btn.setEnabled(False)
        self.progress.setValue(0)
        self.progress.setVisible(True)
        self.banner.show_message("Running…", "info")
        self.worker = Worker(closed_and_open, copy.deepcopy(self.state.config), name, scen,
                             self.compare.isChecked())
        self.worker.progress.connect(lambda f: self.progress.setValue(int(f * 100)))
        self.worker.finished.connect(self._done)
        self.worker.failed.connect(self._failed)
        self.worker.start()

    def _done(self, payload) -> None:
        self.run_btn.setEnabled(True)
        self.progress.setVisible(False)
        self.data = payload
        closed = payload[0][0]
        ok = closed.metrics["maintained_within_window"]
        self.banner.show_message(
            "<b>PID kept BHP inside the pressure window.</b>" if ok else
            f"<b>BHP left the window for {closed.metrics['time_outside_window_s']:.1f} s</b> — "
            "consider re-tuning.", "success" if ok else "warning")
        self.results.setVisible(True)
        self.redraw()

    def _failed(self, message: str) -> None:
        self.run_btn.setEnabled(True)
        self.progress.setVisible(False)
        self.banner.show_message(f"<b>Simulation failed.</b> {message}", "error")

    def redraw(self) -> None:
        if not self.data:
            return
        (closed, meta), opened = self.data
        u = self.state.units
        extra = {"BHP, open loop": opened[0].timeseries} if opened else None
        plots.pressures_time(self.c_bhp.clear(), closed.timeseries, u, extra)
        self.c_bhp.draw()
        runs = {"PID": closed.metrics}
        if opened:
            runs["Open loop"] = opened[0].metrics
        self.t_cmp.set_frame(metrics_frame(runs, u))
        tol = read_quantity(self.state.config["controller"], "settling_tolerance", "pressure",
                            default=1e5)
        plots.control_error_and_terms(self.c_err.clear(), closed.timeseries, u, tol)
        self.c_err.draw()
        ev = events_frame(closed.metrics, u)
        self.t_events.set_frame(ev if ev is not None else pd.DataFrame({"Event": []}))
        self.full.show_result(closed, meta)

    def on_units_changed(self) -> None:
        self.redraw()
