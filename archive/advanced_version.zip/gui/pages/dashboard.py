"""Steady-state dashboard: KPIs, pressure window, profile, SPP build-up, segment data."""

from __future__ import annotations

import pandas as pd
from PySide6.QtWidgets import (QButtonGroup, QCheckBox, QFormLayout, QGridLayout, QGroupBox,
                               QHBoxLayout, QPushButton, QSplitter, QTabWidget, QVBoxLayout,
                               QWidget)
from PySide6.QtCore import Qt

from .. import plots
from ..widgets import (Banner, DataTable, KpiCard, PlotCanvas, StatusBadge, _spin,
                       combo_input, quantity_spin)
from .base import Page


class DashboardPage(Page):
    title = "Steady-state dashboard"
    subtitle = ("Stage A — segment-based circulating hydraulics. BHP, SPP, ECD and the full "
                "pressure profile are recalculated as soon as an input changes.")

    def __init__(self, state, parent=None) -> None:
        super().__init__(state, parent)
        self.depth_axis = "md"
        self.result = None
        self.setup = None

        self.inputs_box = QGroupBox("Operating point")
        self.inputs_layout = QHBoxLayout(self.inputs_box)
        self.body.addWidget(self.inputs_box)

        self.banner = Banner()
        self.badge = StatusBadge()
        self.body.addWidget(self.banner)
        self.body.addWidget(self.badge, alignment=Qt.AlignLeft)

        grid = QGridLayout()
        grid.setSpacing(10)
        self.cards = {
            "bhp": KpiCard("Bottomhole pressure"),
            "spp": KpiCard("Stand-pipe pressure"),
            "sbp": KpiCard("Surface back pressure"),
            "ecd": KpiCard("ECD (conventional)", "MW + annular friction / (g·TVD). Excludes SBP."),
            "emw": KpiCard("EMW of BHP", "BHP / (g·TVD). Includes SBP — the MPD 'ECD'."),
            "margin": KpiCard("Margin to nearest limit"),
        }
        for i, card in enumerate(self.cards.values()):
            grid.addWidget(card, 0, i)
        self.body.addLayout(grid)

        self.gauge = PlotCanvas(height=2.1, toolbar=False)
        self.body.addWidget(self.gauge)

        split = QSplitter(Qt.Horizontal)
        left = QWidget()
        lv = QVBoxLayout(left)
        lv.setContentsMargins(0, 0, 0, 0)
        toggle = QHBoxLayout()
        self.depth_group = QButtonGroup(self)
        for key, text in (("md", "Measured depth (flow path)"),
                          ("tvd", "True vertical depth (hydrostatics)")):
            b = QPushButton(text)
            b.setCheckable(True)
            b.setChecked(key == "md")
            b.clicked.connect(lambda _=False, k=key: self._set_depth(k))
            self.depth_group.addButton(b)
            toggle.addWidget(b)
        toggle.addStretch(1)
        lv.addLayout(toggle)
        self.profile = PlotCanvas(height=7.0)
        lv.addWidget(self.profile)
        split.addWidget(left)
        right = QWidget()
        rv = QVBoxLayout(right)
        rv.setContentsMargins(0, 0, 0, 0)
        self.breakdown = PlotCanvas(height=3.2, toolbar=False)
        rv.addWidget(self.breakdown)
        self.accounting = DataTable(decimals=1, stretch=True)
        self.accounting.setMinimumHeight(250)
        rv.addWidget(self.accounting)
        split.addWidget(right)
        split.setSizes([620, 480])
        self.body.addWidget(split)

        self.tabs = QTabWidget()
        seg = QWidget()
        sv = QVBoxLayout(seg)
        self.segments = DataTable(decimals=4)
        self.segments.setMinimumHeight(320)
        sv.addWidget(self.segments)
        buttons = QHBoxLayout()
        for text, fn in (("Export segments CSV…", self._export_segments),
                         ("Export pressure profile CSV…", self._export_profile),
                         ("Export SPP breakdown CSV…", self._export_breakdown)):
            b = QPushButton(text)
            b.clicked.connect(fn)
            buttons.addWidget(b)
        buttons.addStretch(1)
        sv.addLayout(buttons)
        self.tabs.addTab(seg, "Segment data")
        self.regimes = PlotCanvas(height=4.5)
        self.tabs.addTab(self.regimes, "Flow regimes")
        self.body.addWidget(self.tabs)

        self.on_case_loaded()
        self.on_config_edited()

    # --------------------------------------------------------------- inputs
    def on_case_loaded(self) -> None:
        while self.inputs_layout.count():
            item = self.inputs_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        ops = self.state.config["operations"]
        form1 = QFormLayout()
        label, spin = quantity_spin(self.state, ops, "pump_rate", "flow_rate", "Pump rate", "gpm",
                                    500, 0, 5000, 10, 0)
        form1.addRow(label, spin)
        mode = combo_input(self.state, ops, "back_pressure_mode",
                           {"choke": "Choke equation", "specified": "Specified SBP"},
                           on_change=lambda _v: self._mode_visibility())
        form1.addRow("Back pressure from", mode)
        w1 = QWidget()
        w1.setLayout(form1)
        self.inputs_layout.addWidget(w1)

        form2 = QFormLayout()
        label, self.sbp_spin = quantity_spin(self.state, ops, "surface_back_pressure", "pressure",
                                             "Surface back pressure", "psi", 0, 0, 5000, 10, 1)
        self.sbp_label = label
        form2.addRow(label, self.sbp_spin)
        self.auto = QCheckBox("Auto choke opening (reach target BHP)")
        self.auto.setChecked(str(ops.get("choke_opening_frac", "auto")).lower() == "auto")
        self.auto.toggled.connect(self._auto_changed)
        form2.addRow(self.auto)
        current = ops.get("choke_opening_frac")
        self.opening = _spin(0.4 if isinstance(current, str) else float(current), 0.0, 1.0,
                             0.01, 3, "Choke opening fraction (0 = closed, 1 = fully open)")
        self.opening.valueChanged.connect(self._opening_changed)
        form2.addRow("Choke opening [fraction]", self.opening)
        w2 = QWidget()
        w2.setLayout(form2)
        self.inputs_layout.addWidget(w2)
        self.inputs_layout.addStretch(1)
        self._mode_visibility()

    def _mode_visibility(self) -> None:
        choke = self.state.config["operations"].get("back_pressure_mode") == "choke"
        self.sbp_spin.setEnabled(not choke)
        self.auto.setEnabled(choke)
        self.opening.setEnabled(choke and not self.auto.isChecked())

    def _auto_changed(self, checked: bool) -> None:
        ops = self.state.config["operations"]
        ops["choke_opening_frac"] = "auto" if checked else float(self.opening.value())
        self._mode_visibility()
        self.state.touch()

    def _opening_changed(self, value: float) -> None:
        if not self.auto.isChecked():
            self.state.config["operations"]["choke_opening_frac"] = float(value)
            self.state.touch()

    def _set_depth(self, key: str) -> None:
        self.depth_axis = key
        self._draw_profile()

    # --------------------------------------------------------------- results
    def on_units_changed(self) -> None:
        self.on_config_edited()

    def on_config_edited(self) -> None:
        setup, result, err = self.state.steady()
        if err:
            self.banner.show_message(f"<b>The case could not be solved.</b> {err}", "error")
            return
        self.banner.show_message("")
        self.setup, self.result = setup, result
        u, w, r = self.state.units, setup.window, result
        self.badge.set_status(r.window_status)
        if setup.conditions.back_pressure_mode == "choke" and self.auto.isChecked():
            self.opening.blockSignals(True)
            self.opening.setValue(setup.conditions.choke_opening)
            self.opening.blockSignals(False)
        self.cards["bhp"].set(f"{u.p(r.bhp):,.1f} {u.pressure}",
                              f"{u.p(r.bhp - w.target_bhp):+,.1f} vs target")
        self.cards["spp"].set(f"{u.p(r.spp):,.1f} {u.pressure}")
        self.cards["sbp"].set(f"{u.p(r.surface_back_pressure):,.1f} {u.pressure}",
                              f"choke {setup.conditions.choke_opening:.1%} open"
                              if setup.conditions.back_pressure_mode == "choke" else "specified")
        self.cards["ecd"].set(f"{u.rho(r.ecd_conventional):,.3f} {u.density}")
        self.cards["emw"].set(f"{u.rho(r.emw_bhp):,.3f} {u.density}")
        margin = min(r.bhp - w.pore_pressure, w.fracture_pressure - r.bhp)
        self.cards["margin"].set(f"{u.p(margin):,.1f} {u.pressure}",
                                 "inside window" if margin >= 0 else "outside window",
                                 "good" if margin >= 0 else "bad")

        plots.window_gauge(self.gauge.clear(), r, w, u)
        self.gauge.draw()
        self._draw_profile()
        plots.spp_breakdown(self.breakdown.clear(), r, u)
        self.breakdown.draw()
        rows = [("Hydrostatic at TD  (ρ·g·TVD)", r.hydrostatic_td),
                ("+ Annular friction", r.losses.annulus),
                ("+ Surface back pressure", r.surface_back_pressure),
                ("= Circulating BHP", r.bhp),
                ("Static BHP (pumps off, SBP 0)", r.bhp_static),
                ("Bit pressure drop", r.losses.bit),
                ("Break-circulation (gel) estimate", r.gel_breaking_pressure)]
        self.accounting.set_frame(pd.DataFrame({
            "Pressure accounting": [x[0] for x in rows],
            f"[{u.pressure}]": [u.p(x[1]) for x in rows]}))
        self.segments.set_frame(r.segment_table())
        plots.regime_map(self.regimes.clear(), r, u)
        self.regimes.draw()

    def _draw_profile(self) -> None:
        if self.result is None:
            return
        plots.pressure_profile(self.profile.clear(), self.result, self.setup.window,
                               self.state.units, self.depth_axis)
        self.profile.draw()

    # --------------------------------------------------------------- export
    def _export_segments(self) -> None:
        self.save_csv(self.result.segment_table() if self.result else None, "segments.csv")

    def _export_profile(self) -> None:
        self.save_csv(self.result.profile if self.result else None, "pressure_profile.csv")

    def _export_breakdown(self) -> None:
        self.save_csv(self.result.pressure_breakdown() if self.result else None,
                      "pressure_breakdown.csv")
