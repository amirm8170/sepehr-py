"""Shared widget that displays one dynamic simulation result (KPIs + chart tabs + tables)."""

from __future__ import annotations

from typing import Dict, Optional

import numpy as np
import pandas as pd
from PySide6.QtWidgets import (QGridLayout, QHBoxLayout, QLabel, QPushButton, QTabWidget,
                               QVBoxLayout, QWidget)

from .. import plots
from ..widgets import DataTable, KpiCard, PlotCanvas

METRIC_LABELS = {
    "min_bhp_pa": ("Min BHP", "p"), "max_bhp_pa": ("Max BHP", "p"),
    "max_overshoot_pa": ("Max above target", "p"), "max_undershoot_pa": ("Max below target", "p"),
    "steady_state_error_pa": ("Steady-state error", "p"),
    "rise_time_s": ("Rise time (10–90 %)", "s"), "settling_time_s": ("Settling time", "s"),
    "overshoot_percent": ("Overshoot", "%"), "time_outside_window_s": ("Time outside window", "s"),
    "iae_pa_s": ("Integral of |error| (IAE)", "ps"),
}


def format_metric(key: str, value, u) -> str:
    kind = METRIC_LABELS.get(key, (key, ""))[1]
    if value is None or (isinstance(value, float) and np.isnan(value)):
        return "—"
    if kind == "p":
        return f"{u.p(value):,.2f} {u.pressure}"
    if kind == "ps":
        return f"{u.p(value):,.0f} {u.pressure}·s"
    if kind == "s":
        return f"{value:,.1f} s"
    if kind == "%":
        return f"{value:,.1f} %"
    return str(value)


def metrics_frame(runs: Dict[str, Dict], u) -> pd.DataFrame:
    return pd.DataFrame([{"Metric": label, **{name: format_metric(key, m.get(key), u)
                                               for name, m in runs.items()}}
                         for key, (label, _) in METRIC_LABELS.items()])


def events_frame(metrics: Dict, u) -> Optional[pd.DataFrame]:
    ids = sorted({int(k.split("_")[0][5:]) for k in metrics
                  if k.startswith("event") and k.split("_")[0][5:].isdigit()})
    if not ids:
        return None
    rows = []
    for n in ids:
        row = {"Event": n, "Starts at": f"{metrics.get(f'event{n}_time_s', np.nan):.1f} s"}
        for key in ("settling_time_s", "rise_time_s", "max_overshoot_pa", "max_undershoot_pa",
                    "steady_state_error_pa"):
            row[METRIC_LABELS[key][0]] = format_metric(key, metrics.get(f"event{n}_{key}"), u)
        rows.append(row)
    return pd.DataFrame(rows)


class ResultView(QWidget):
    """KPI cards and tabbed charts/tables for a SimulationResult."""

    def __init__(self, page, parent=None) -> None:
        super().__init__(parent)
        self.page = page
        self.result = None
        self.meta: Dict = {}
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        grid = QGridLayout()
        self.cards = {k: KpiCard(t) for k, t in (
            ("bhp", "BHP range"), ("spp", "SPP range"), ("window", "Time outside window"),
            ("dev", "Max deviation from target"), ("last", "Settling time / IAE"))}
        for i, c in enumerate(self.cards.values()):
            grid.addWidget(c, 0, i)
        lay.addLayout(grid)
        self.events = QLabel()
        self.events.setWordWrap(True)
        self.events.setObjectName("pageSubtitle")
        lay.addWidget(self.events)
        self.tabs = QTabWidget()
        self.c_press = PlotCanvas(height=7.5)
        self.c_ecd = PlotCanvas(height=5)
        self.c_flow = PlotCanvas(height=6.5)
        self.c_win = PlotCanvas(height=3)
        self.c_prof = PlotCanvas(height=6.5)
        self.tabs.addTab(self.c_press, "Pressures")
        self.tabs.addTab(self.c_ecd, "ECD")
        self.tabs.addTab(self.c_flow, "Flow && choke")
        self.tabs.addTab(self.c_win, "Window status")
        self.tabs.addTab(self.c_prof, "Depth profiles")
        mt = QWidget()
        mv = QVBoxLayout(mt)
        self.t_metrics = DataTable(stretch=True)
        self.t_events = DataTable(stretch=True)
        mv.addWidget(QLabel("<b>Control-performance metrics</b> (from the first event time)"))
        mv.addWidget(self.t_metrics)
        mv.addWidget(QLabel("<b>Per-event metrics</b>"))
        mv.addWidget(self.t_events)
        self.tabs.addTab(mt, "Metrics")
        dt = QWidget()
        dv = QVBoxLayout(dt)
        self.t_data = DataTable(decimals=4)
        dv.addWidget(self.t_data)
        row = QHBoxLayout()
        for text, fn in (("Export time series CSV…", self._export_ts),
                         ("Export depth profiles CSV…", self._export_prof)):
            b = QPushButton(text)
            b.clicked.connect(fn)
            row.addWidget(b)
        row.addStretch(1)
        dv.addLayout(row)
        self.tabs.addTab(dt, "Data")
        self.tabs.setMinimumHeight(640)
        lay.addWidget(self.tabs)

    def show_result(self, result, meta: Dict, extra: Optional[Dict] = None) -> None:
        self.result, self.meta, self.extra = result, meta, extra
        self.redraw()

    def redraw(self) -> None:
        r = self.result
        if r is None:
            return
        u = self.page.state.units
        ts, m = r.timeseries, r.metrics
        self.cards["bhp"].set(f"{u.p(m['min_bhp_pa']):,.0f} – {u.p(m['max_bhp_pa']):,.0f}",
                              u.pressure)
        self.cards["spp"].set(f"{u.p(ts['spp_pa'].min()):,.0f} – {u.p(ts['spp_pa'].max()):,.0f}",
                              u.pressure)
        out = m["time_outside_window_s"]
        self.cards["window"].set(f"{out:,.1f} s", "window held" if out == 0 else "window violated",
                                 "good" if out == 0 else "bad")
        self.cards["dev"].set(f"{u.p(max(m['max_overshoot_pa'], m['max_undershoot_pa'])):,.1f} "
                              f"{u.pressure}")
        if r.controller_enabled:
            self.cards["last"].set(format_metric("settling_time_s", m["settling_time_s"], u),
                                   "settling (PID)")
        else:
            self.cards["last"].set(format_metric("iae_pa_s", m["iae_pa_s"], u), "IAE (open loop)")
        self.events.setText("Events: " + " · ".join(r.events) if r.events else "")
        plots.pressures_time(self.c_press.clear(), ts, u, self.extra)
        plots.ecd_time(self.c_ecd.clear(), ts, u, self.meta["density"], self.meta["td_tvd"])
        plots.flow_and_actuator(self.c_flow.clear(), ts, u, r.actuation)
        plots.window_strip(self.c_win.clear(), ts)
        if not r.profiles.empty:
            plots.profiles_over_time(self.c_prof.clear(), r.profiles, u)
        for c in (self.c_press, self.c_ecd, self.c_flow, self.c_win, self.c_prof):
            c.draw()
        self.t_metrics.set_frame(metrics_frame({"Value": m}, u))
        ev = events_frame(m, u)
        self.t_events.set_frame(ev if ev is not None else pd.DataFrame({"Event": []}))
        self.t_data.set_frame(ts)

    def _export_ts(self) -> None:
        self.page.save_csv(self.result.timeseries if self.result else None,
                           f"{self.result.name if self.result else 'run'}_timeseries.csv")

    def _export_prof(self) -> None:
        self.page.save_csv(self.result.profiles if self.result else None,
                           "profiles.csv", field_units=False)
