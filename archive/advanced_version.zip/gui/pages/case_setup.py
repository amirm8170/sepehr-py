"""Case setup: every input of the working case (geometry, survey, mud, operations, control)."""

from __future__ import annotations

from typing import Any, Dict, List, Tuple

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QCheckBox, QComboBox, QFileDialog, QFormLayout, QGridLayout,
                               QGroupBox, QHBoxLayout, QHeaderView, QLabel, QLineEdit,
                               QPushButton, QSpinBox, QTableWidget, QTableWidgetItem, QTabWidget,
                               QVBoxLayout, QWidget)

from mpd_sim.io.loaders import (build_trajectory, find_unit_key, load_trajectory_csv,
                                read_quantity)
from mpd_sim.units import to_si

from .. import plots
from ..state import ROOT
from ..widgets import (Banner, PlotCanvas, _spin, check_input, combo_input, plain_spin,
                       quantity_spin, unit_label)
from .base import Page

QuantitySpec = Tuple[str, str, str, str]          # (base key, kind, default unit, column label)


class RowsTable(QWidget):
    """Editable table for a list of config rows with unit-suffixed keys (Apply to commit)."""

    def __init__(self, state, rows: List[Dict[str, Any]], text_cols: List[Tuple[str, str, List[str]]],
                 quantities: List[QuantitySpec], on_apply) -> None:
        super().__init__()
        self.state, self.text_cols, self.quantities, self.on_apply = state, text_cols, quantities, on_apply
        self.units = {}
        for base, kind, default_unit, _ in quantities:
            self.units[base] = next((find_unit_key(r, base, kind) for r in rows
                                     if find_unit_key(r, base, kind)), None) or default_unit
        headers = [label for _, label, _ in text_cols] + [
            f"{label} [{unit_label(self.units[b])}]" for b, _, _, label in quantities]
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        self.table = QTableWidget(0, len(headers))
        self.table.setHorizontalHeaderLabels(headers)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table.verticalHeader().setVisible(False)
        self.table.setMinimumHeight(150)
        for r in rows:
            self._add([r.get(k, opts[0] if opts else "") for k, _, opts in text_cols],
                      [read_quantity(r, b, kind) / to_si(1.0, self.units[b], kind)
                       for b, kind, _, _ in quantities])
        lay.addWidget(self.table)
        buttons = QHBoxLayout()
        add, rem, apply = QPushButton("+ Row"), QPushButton("− Row"), QPushButton("Apply changes")
        apply.setObjectName("primary")
        add.clicked.connect(lambda: self._add([opts[0] if opts else "new" for _, _, opts in text_cols],
                                              [0.0] * len(quantities)))
        rem.clicked.connect(lambda: self.table.removeRow(self.table.currentRow()
                                                         if self.table.currentRow() >= 0
                                                         else self.table.rowCount() - 1))
        apply.clicked.connect(self.apply)
        for b in (add, rem):
            buttons.addWidget(b)
        buttons.addStretch(1)
        buttons.addWidget(apply)
        lay.addLayout(buttons)

    def _add(self, texts: List[str], values: List[float]) -> None:
        r = self.table.rowCount()
        self.table.insertRow(r)
        for c, ((_, _, options), text) in enumerate(zip(self.text_cols, texts)):
            if options:
                combo = QComboBox()
                combo.addItems(options)
                combo.setCurrentText(str(text))
                self.table.setCellWidget(r, c, combo)
            else:
                self.table.setItem(r, c, QTableWidgetItem(str(text)))
        offset = len(self.text_cols)
        for c, v in enumerate(values):
            self.table.setItem(r, offset + c, QTableWidgetItem(f"{v:g}"))

    def rows(self) -> List[Dict[str, Any]]:
        out = []
        for r in range(self.table.rowCount()):
            row: Dict[str, Any] = {}
            for c, (key, _, options) in enumerate(self.text_cols):
                widget = self.table.cellWidget(r, c)
                row[key] = widget.currentText() if widget else self.table.item(r, c).text()
            offset = len(self.text_cols)
            for c, (base, _, _, label) in enumerate(self.quantities):
                item = self.table.item(r, offset + c)
                row[f"{base}_{self.units[base]}"] = float(item.text())
            out.append(row)
        return out

    def apply(self) -> None:
        try:
            self.on_apply(self.rows())
            self.state.touch()
        except (ValueError, AttributeError) as exc:
            self.window().statusBar().showMessage(f"Table not applied: {exc}", 6000)


def _form(rows) -> QWidget:
    w = QWidget()
    form = QFormLayout(w)
    form.setLabelAlignment(Qt.AlignRight)
    for row in rows:
        if isinstance(row, tuple):
            form.addRow(*row)
        else:
            form.addRow(row)
    return w


class CaseSetupPage(Page):
    title = "Case setup"
    subtitle = ("All inputs of the current case. Number fields apply immediately; tables apply "
                "with their 'Apply changes' button. Save the case with File → Save case as…")

    def __init__(self, state, parent=None) -> None:
        super().__init__(state, parent)
        self.status = Banner()
        self.body.addWidget(self.status)
        self.tabs = QTabWidget()
        self.body.addWidget(self.tabs)
        self.on_case_loaded()
        self.on_config_edited()

    # ----------------------------------------------------------------- build
    def on_case_loaded(self) -> None:
        current = self.tabs.currentIndex()
        self.tabs.clear()
        cfg = self.state.config
        self.tabs.addTab(self._geometry(cfg), "Geometry")
        self.tabs.addTab(self._trajectory(cfg), "Trajectory")
        self.tabs.addTab(self._fluid(cfg), "Drilling fluid")
        self.tabs.addTab(self._operations(cfg), "Operations && window")
        self.tabs.addTab(self._control(cfg), "Choke && control")
        self.tabs.addTab(self._numerics(cfg), "Numerics")
        self.tabs.setCurrentIndex(max(current, 0))

    def _geometry(self, cfg) -> QWidget:
        well = cfg["well"]
        page = QWidget()
        lay = QVBoxLayout(page)

        def set_holes(rows):
            well["hole_sections"] = rows

        def set_string(rows):
            well["drill_string"] = rows
        holes = QGroupBox("Hole sections — surface to TD, contiguous (cased hole uses casing ID)")
        QVBoxLayout(holes).addWidget(RowsTable(
            self.state, well["hole_sections"],
            [("name", "Name", []), ("kind", "Kind", ["cased", "open_hole", "riser", "liner"])],
            [("top_md", "length", "m", "Top MD"), ("bottom_md", "length", "m", "Bottom MD"),
             ("diameter", "length", "in", "Diameter")], set_holes))
        lay.addWidget(holes)
        string = QGroupBox("Drill string — surface to bit (total length = bit depth)")
        QVBoxLayout(string).addWidget(RowsTable(
            self.state, well["drill_string"],
            [("name", "Name", []), ("category", "Category", ["drill_pipe", "bha"])],
            [("length", "length", "m", "Length"), ("outer_diameter", "length", "in", "OD"),
             ("inner_diameter", "length", "in", "ID")], set_string))
        lay.addWidget(string)
        bit = well["bit"]
        unit = find_unit_key(bit, "nozzle_diameters", "length") or "32nds"
        nozzles = QLineEdit(", ".join(f"{v:g}" for v in bit.get(f"nozzle_diameters_{unit}", [12, 12, 12])))

        def set_nozzles():
            try:
                sizes = [float(x) for x in nozzles.text().replace(";", ",").split(",") if x.strip()]
                bit[f"nozzle_diameters_{unit}"] = sizes
                self.state.touch()
            except ValueError:
                self.window().statusBar().showMessage("Nozzle sizes must be numbers.", 5000)
        nozzles.editingFinished.connect(set_nozzles)
        box = QGroupBox("Bit")
        QVBoxLayout(box).addWidget(_form([
            (f"Nozzle sizes [{unit_label(unit)}], comma separated", nozzles),
            ("Discharge coefficient C_d", plain_spin(self.state, bit, "discharge_coefficient", 0.95,
                                                     0.5, 1.0, 0.01, 2,
                                                     "Nozzle discharge coefficient — calibrate "
                                                     "against measured SPP"))]))
        lay.addWidget(box)
        lay.addStretch(1)
        return page

    def _trajectory(self, cfg) -> QWidget:
        page = QWidget()
        lay = QHBoxLayout(page)
        left = QVBoxLayout()
        try:
            traj = build_trajectory(cfg["well"]["trajectory"], ROOT)
        except Exception as exc:
            left.addWidget(Banner(f"Trajectory error: {exc}", "error"))
            traj = None
        info = QLabel()
        info.setObjectName("pageSubtitle")
        info.setWordWrap(True)
        left.addWidget(info)
        self.traj_table = QTableWidget(0, 4)
        self.traj_table.setHorizontalHeaderLabels(["MD [m]", "Inclination [deg]", "Azimuth [deg]",
                                                   "TVD [m]"])
        self.traj_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.traj_table.verticalHeader().setVisible(False)
        self.traj_table.setMinimumHeight(420)
        if traj is not None:
            info.setText(f"{len(traj.md)} stations · TD {traj.total_md:,.0f} m MD / "
                         f"{traj.total_tvd:,.0f} m TVD · max inclination {traj.inclination.max():.1f}°")
            for vals in zip(traj.md, traj.inclination, traj.azimuth, traj.tvd):
                r = self.traj_table.rowCount()
                self.traj_table.insertRow(r)
                for c, v in enumerate(vals):
                    self.traj_table.setItem(r, c, QTableWidgetItem(f"{v:.2f}"))
        left.addWidget(self.traj_table)
        self.recompute_tvd = QCheckBox("Recompute TVD by minimum curvature (ignore TVD column)")
        left.addWidget(self.recompute_tvd)
        buttons = QHBoxLayout()
        add, imp, apply = QPushButton("+ Station"), QPushButton("Import CSV…"), QPushButton("Apply changes")
        apply.setObjectName("primary")
        add.clicked.connect(lambda: self.traj_table.insertRow(self.traj_table.rowCount()))
        imp.clicked.connect(self._import_survey)
        apply.clicked.connect(self._apply_survey)
        for b in (add, imp):
            buttons.addWidget(b)
        buttons.addStretch(1)
        buttons.addWidget(apply)
        left.addLayout(buttons)
        lw = QWidget()
        lw.setLayout(left)
        lay.addWidget(lw, 2)

        right = QVBoxLayout()
        self.traj_view = QComboBox()
        self.traj_view.addItems(["Vertical section", "Plan view", "3D", "Inclination"])
        right.addWidget(self.traj_view)
        self.traj_canvas = PlotCanvas(height=6)
        right.addWidget(self.traj_canvas)
        rw = QWidget()
        rw.setLayout(right)
        lay.addWidget(rw, 3)

        def draw():
            if traj is not None:
                plots.trajectory(self.traj_canvas.clear(), traj, self.state.units,
                                 self.traj_view.currentText())
                self.traj_canvas.draw()
        self.traj_view.currentIndexChanged.connect(draw)
        draw()
        return page

    def _apply_survey(self) -> None:
        stations = []
        try:
            for r in range(self.traj_table.rowCount()):
                cells = [self.traj_table.item(r, c) for c in range(4)]
                if cells[0] is None or not cells[0].text().strip():
                    continue
                s = {"md_m": float(cells[0].text()),
                     "inclination_deg": float(cells[1].text()) if cells[1] else 0.0,
                     "azimuth_deg": float(cells[2].text()) if cells[2] else 0.0}
                if not self.recompute_tvd.isChecked() and cells[3] and cells[3].text().strip():
                    s["tvd_m"] = float(cells[3].text())
                stations.append(s)
        except ValueError as exc:
            self.window().statusBar().showMessage(f"Survey not applied: {exc}", 6000)
            return
        stations.sort(key=lambda s: s["md_m"])
        self.state.config["well"]["trajectory"] = {"stations": stations}
        self.state.touch()
        self.on_case_loaded()

    def _import_survey(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Survey CSV", str(ROOT / "data"),
                                              "CSV files (*.csv)")
        if not path:
            return
        try:
            traj = load_trajectory_csv(path)
        except Exception as exc:
            self.window().statusBar().showMessage(f"Survey rejected: {exc}", 8000)
            return
        self.state.config["well"]["trajectory"] = {"stations": [
            {"md_m": float(m), "inclination_deg": float(i), "azimuth_deg": float(a),
             "tvd_m": float(t)} for m, i, a, t in zip(traj.md, traj.inclination, traj.azimuth,
                                                      traj.tvd)]}
        self.state.touch()
        self.on_case_loaded()

    def _fluid(self, cfg) -> QWidget:
        mud = cfg["mud"]
        page = QWidget()
        lay = QHBoxLayout(page)
        self.flow_canvas = PlotCanvas(height=4.5, toolbar=False)

        def redraw(_v=None):
            try:
                plots.flow_curve(self.flow_canvas.clear(),
                                 read_quantity(mud, "plastic_viscosity", "viscosity"),
                                 read_quantity(mud, "yield_point", "stress"))
                self.flow_canvas.draw()
            except Exception:
                pass
        rows = [("Rheology model", combo_input(self.state, mud, "rheology_model",
                                               {"bingham_plastic": "Bingham Plastic  (τ = τy + μp·γ̇)"},
                                               "Power Law and Herschel–Bulkley friction models are "
                                               "planned extensions."))]
        for base, kind, label, unit, default, lo, hi, step, dec in (
                ("density", "density", "Mud density", "ppg", 10, 0.1, 30, 0.1, 2),
                ("plastic_viscosity", "viscosity", "Plastic viscosity PV", "cp", 20, 0, 500, 1, 1),
                ("yield_point", "stress", "Yield point YP", "lbf_100ft2", 15, 0, 500, 1, 1),
                ("gel_10s", "stress", "Gel strength 10 s", "lbf_100ft2", 5, 0, 500, 1, 1),
                ("gel_10min", "stress", "Gel strength 10 min", "lbf_100ft2", 10, 0, 500, 1, 1)):
            rows.append(quantity_spin(self.state, mud, base, kind, label, unit, default, lo, hi,
                                      step, dec, on_change=redraw))
        rows.append(quantity_spin(self.state, mud, "bulk_modulus", "pressure",
                                  "Effective bulk modulus β", "pa", 1.5e9, 1e7, 1e11, 1e8, 0,
                                  "Used by the lumped dynamic model; calibrate from pump "
                                  "start/stop SPP transients."))
        left = QVBoxLayout()
        box = QGroupBox("Mud properties")
        QVBoxLayout(box).addWidget(_form(rows))
        left.addWidget(box)
        fann = QGroupBox("Fann VG-meter calculator (API RP 13B-1)")
        fl = QFormLayout(fann)
        th600, th300 = _spin(50, 0, 300, 1, 1, ""), _spin(35, 0, 300, 1, 1, "")
        result = QLabel()

        def calc(_v=None):
            pv, yp = th600.value() - th300.value(), 2 * th300.value() - th600.value()
            result.setText(f"PV = θ600 − θ300 = <b>{pv:.1f} cP</b> · YP = θ300 − PV = "
                           f"<b>{yp:.1f} lbf/100 ft²</b>")
            return pv, yp
        th600.valueChanged.connect(calc)
        th300.valueChanged.connect(calc)
        calc()
        apply = QPushButton("Apply to mud")

        def apply_fann():
            pv, yp = calc()
            if yp < 0:
                return
            for k in [k for k in mud if k.startswith(("plastic_viscosity_", "yield_point_"))]:
                mud.pop(k)
            mud["plastic_viscosity_cp"], mud["yield_point_lbf_100ft2"] = pv, yp
            self.state.touch()
            self.on_case_loaded()
        apply.clicked.connect(apply_fann)
        fl.addRow("θ600 reading", th600)
        fl.addRow("θ300 reading", th300)
        fl.addRow(result)
        fl.addRow(apply)
        left.addWidget(fann)
        left.addStretch(1)
        lw = QWidget()
        lw.setLayout(left)
        lay.addWidget(lw, 2)
        lay.addWidget(self.flow_canvas, 3)
        redraw()
        return page

    def _pressure_or_emw(self, section, base, label):
        if find_unit_key(section, base, "pressure"):
            return quantity_spin(self.state, section, base, "pressure", label, "psi", 0, 0, 1e5, 10, 1)
        return quantity_spin(self.state, section, f"{base}_emw", "density", f"{label} (EMW)", "ppg",
                             10, 0.1, 30, 0.05, 2)

    def _operations(self, cfg) -> QWidget:
        ops, win = cfg["operations"], cfg["pressure_window"]
        page = QWidget()
        lay = QHBoxLayout(page)
        box1 = QGroupBox("Operating conditions")
        auto = QCheckBox("Choke opening: auto (reach target BHP)")
        auto.setChecked(str(ops.get("choke_opening_frac", "auto")).lower() == "auto")
        cur = ops.get("choke_opening_frac")
        opening = _spin(0.4 if isinstance(cur, str) else float(cur), 0, 1, 0.01, 3, "")
        opening.setEnabled(not auto.isChecked())

        def set_auto(checked):
            ops["choke_opening_frac"] = "auto" if checked else float(opening.value())
            opening.setEnabled(not checked)
            self.state.touch()

        def set_opening(v):
            if not auto.isChecked():
                ops["choke_opening_frac"] = float(v)
                self.state.touch()
        auto.toggled.connect(set_auto)
        opening.valueChanged.connect(set_opening)
        QVBoxLayout(box1).addWidget(_form([
            quantity_spin(self.state, ops, "pump_rate", "flow_rate", "Pump rate", "gpm", 500, 0, 5000, 10, 0),
            ("Back pressure from", combo_input(self.state, ops, "back_pressure_mode",
                                               {"choke": "Choke equation", "specified": "Specified SBP"})),
            quantity_spin(self.state, ops, "surface_back_pressure", "pressure",
                          "Surface back pressure (specified mode)", "psi", 0, 0, 1e4, 10, 1),
            auto, ("Choke opening [fraction]", opening),
            quantity_spin(self.state, ops, "backpressure_pump_rate", "flow_rate",
                          "Back-pressure pump rate", "gpm", 0, 0, 2000, 10, 0),
            quantity_spin(self.state, ops, "choke_downstream_pressure", "pressure",
                          "Choke downstream pressure", "psi", 0, 0, 1000, 5, 1),
            quantity_spin(self.state, ops, "pipe_velocity", "velocity", "Pipe velocity (+ down)",
                          "m_s", 0, -5, 5, 0.1, 2),
            ("Pipe end", combo_input(self.state, ops, "pipe_end", {"closed": "Closed", "open": "Open"})),
            ("Clinging constant K_c", plain_spin(self.state, ops, "clinging_constant", 0.45, 0, 1,
                                                 0.05, 2, "Burkhardt (1961) swab/surge constant")),
        ]))
        lay.addWidget(box1)
        box2 = QGroupBox("Pressure window at TD")
        QVBoxLayout(box2).addWidget(_form([
            self._pressure_or_emw(win, "pore_pressure", "Pore pressure"),
            self._pressure_or_emw(win, "fracture_pressure", "Fracture pressure"),
            self._pressure_or_emw(win, "target_bhp", "Target BHP"),
            quantity_spin(self.state, win, "warning_margin", "pressure", "Warning margin", "psi",
                          100, 0, 5000, 10, 0),
            check_input(self.state, win, "allow_target_outside_window",
                        "Allow target outside window"),
        ]))
        lay.addWidget(box2, alignment=Qt.AlignTop)
        return page

    def _control(self, cfg) -> QWidget:
        choke, bp, ctrl = cfg["choke"], cfg["back_pressure_actuator"], cfg["controller"]
        page = QWidget()
        lay = QHBoxLayout(page)
        box1 = QGroupBox("MPD choke  —  Q = K(u)·√(ΔP/ρ), Cv in US units (gpm/√psi)")
        QVBoxLayout(box1).addWidget(_form([
            ("Characteristic", combo_input(self.state, choke, "characteristic",
                                           {"linear": "Linear", "equal_percentage": "Equal percentage",
                                            "table": "Table (from config)"})),
            ("Cv at full opening", plain_spin(self.state, choke, "cv_max", 100, 1, 1e4, 5, 1)),
            ("Leakage Cv (closed)", plain_spin(self.state, choke, "cv_leak", 1, 0, 1e3, 0.5, 2)),
            ("Rangeability R (equal %)", plain_spin(self.state, choke, "rangeability", 50, 1.1, 1e3, 5, 1)),
            ("Min opening", plain_spin(self.state, choke, "min_opening_frac", 0.02, 0, 0.99, 0.01, 3)),
            ("Max opening", plain_spin(self.state, choke, "max_opening_frac", 1.0, 0.01, 1, 0.01, 3)),
            ("Stroke-rate limit [fraction/s]", plain_spin(self.state, choke, "max_rate_frac_per_s",
                                                          0.05, 0.001, 10, 0.01, 3)),
        ]))
        bp_box = QGroupBox("Back-pressure actuator (idealised SBP regulator)")
        QVBoxLayout(bp_box).addWidget(_form([
            quantity_spin(self.state, bp, "min", "pressure", "Min SBP", "psi", 0, 0, 1e4, 10, 0),
            quantity_spin(self.state, bp, "max", "pressure", "Max SBP", "psi", 1500, 1, 1e5, 10, 0),
            quantity_spin(self.state, bp, "max_rate", "pressure_rate", "Max rate", "psi_s", 50,
                          0.1, 1e4, 5, 1),
            quantity_spin(self.state, bp, "time_constant", "time", "Time constant", "s", 2, 0.01,
                          600, 0.5, 2),
        ]))
        col = QVBoxLayout()
        col.addWidget(box1)
        col.addWidget(bp_box)
        cw = QWidget()
        cw.setLayout(col)
        lay.addWidget(cw)
        bpg = ctrl.setdefault("back_pressure_gains", {"kp": 0.6, "ki": 0.3, "kd": 0.0})
        box2 = QGroupBox("PID controller")
        QVBoxLayout(box2).addWidget(_form([
            QLabel("<b>Choke actuation</b> — gains per bar of BHP error"),
            ("Kp", plain_spin(self.state, ctrl, "kp", 0.03, 0, 100, 0.005, 4)),
            ("Ki", plain_spin(self.state, ctrl, "ki", 0.008, 0, 100, 0.001, 4)),
            ("Kd", plain_spin(self.state, ctrl, "kd", 0.0, 0, 100, 0.005, 4)),
            QLabel("<b>Back-pressure actuation</b> — bar of SBP per bar of error"),
            ("Kp", plain_spin(self.state, bpg, "kp", 0.6, 0, 100, 0.05, 3)),
            ("Ki", plain_spin(self.state, bpg, "ki", 0.3, 0, 100, 0.05, 3)),
            ("Kd", plain_spin(self.state, bpg, "kd", 0.0, 0, 100, 0.05, 3)),
            ("Anti-windup", combo_input(self.state, ctrl, "anti_windup",
                                        {"clamping": "Clamping", "back_calculation": "Back-calculation",
                                         "none": "None"})),
            ("Derivative on", combo_input(self.state, ctrl, "derivative_on",
                                          {"measurement": "Measurement (no setpoint kick)",
                                           "error": "Error"})),
            ("Derivative filter [s]", plain_spin(self.state, ctrl, "derivative_filter_time_s", 1,
                                                 0, 100, 0.5, 2)),
            quantity_spin(self.state, ctrl, "settling_tolerance", "pressure", "Settling tolerance",
                          "psi", 15, 0.1, 1000, 1, 1),
        ]))
        lay.addWidget(box2, alignment=Qt.AlignTop)
        return page

    def _numerics(self, cfg) -> QWidget:
        num, dyn = cfg["numerics"], cfg["dynamics"]
        page = QWidget()
        lay = QHBoxLayout(page)
        box1 = QGroupBox("Steady-state solver")
        QVBoxLayout(box1).addWidget(_form([
            quantity_spin(self.state, num, "segment_length", "length", "Target segment length",
                          "m", 30, 1, 1000, 5, 1),
            ("Friction correlation", combo_input(self.state, num, "friction_model", {
                "bourgoyne": "Bourgoyne et al. (1986) — Blasius on μp (default)",
                "darby": "Darby, Mun & Boger (1992) — blended"})),
        ]))
        box2 = QGroupBox("Dynamic model")
        QVBoxLayout(box2).addWidget(_form([
            ("Model", combo_input(self.state, dyn, "model", {
                "lumped": "Lumped MPD ODE (Kaasa et al. 2012)",
                "quasi_steady": "Quasi-steady time marching"})),
            ("Actuation", combo_input(self.state, dyn, "actuation", {
                "choke": "Choke opening", "back_pressure": "SBP set-point"})),
            quantity_spin(self.state, dyn, "dt", "time", "Time step", "s", 0.1, 0.01, 10, 0.05, 2),
            quantity_spin(self.state, dyn, "profile_interval", "time", "Profile interval", "s",
                          10, 0.5, 3600, 1, 1),
            quantity_spin(self.state, dyn, "surface_line_volume", "volume", "Surface line volume",
                          "m3", 1, 0, 100, 0.1, 2),
            ("Friction-table points", plain_spin(self.state, dyn, "friction_table_points", 161,
                                                 21, 2001, 20, 0, integer=True)),
        ]))
        lay.addWidget(box1, alignment=Qt.AlignTop)
        lay.addWidget(box2, alignment=Qt.AlignTop)
        return page

    # ---------------------------------------------------------------- status
    def on_config_edited(self) -> None:
        setup, err = self.state.setup()
        if err:
            self.status.show_message(f"<b>Input check failed:</b> {err}", "error")
        else:
            self.status.show_message(
                f"Inputs valid — {setup.solver.grid.n_segments} segments per flow path, bit at "
                f"{setup.well.bit_depth:,.0f} m MD, TD {setup.well.td_tvd:,.0f} m TVD.", "success")
