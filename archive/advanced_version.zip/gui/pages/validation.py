"""Validation: compare model results with reference data, with mandatory provenance."""

from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QButtonGroup, QFileDialog, QGridLayout, QGroupBox, QHBoxLayout,
                               QLabel, QPushButton, QRadioButton, QSplitter)

from mpd_sim.io.loaders import load_reference_csv, load_setup
from mpd_sim.validation.validation import (DATA_TYPES, DEMO_DISCLAIMER, STEADY_QUANTITIES,
                                           summarize, validate_steady_state)

from .. import plots
from ..state import CONFIG_DIR, ROOT
from ..widgets import Banner, DataTable, KpiCard, PlotCanvas
from .base import Page

DEMO_REF = ROOT / "data" / "validation" / "demo_reference_steady_state.csv"
DEMO_CASE = CONFIG_DIR / "validation_demo_case.yaml"


class ValidationPage(Page):
    title = "Validation"
    subtitle = ("Compare model predictions with reference values (absolute, relative and "
                "percentage error). Every reference dataset must state where it comes from.")

    def __init__(self, state, parent=None) -> None:
        super().__init__(state, parent)
        self.ref_path: Path = DEMO_REF
        self.table = None
        box = QGroupBox("Comparison set-up")
        grid = QGridLayout(box)
        self.demo_ref = QRadioButton("Bundled demonstration (hand calculation)")
        self.file_ref = QRadioButton("Reference CSV file…")
        self.demo_ref.setChecked(True)
        g1 = QButtonGroup(self)
        g1.addButton(self.demo_ref)
        g1.addButton(self.file_ref)
        self.file_ref.clicked.connect(self._choose_file)
        self.file_label = QLabel(DEMO_REF.name)
        self.file_label.setObjectName("pageSubtitle")
        grid.addWidget(QLabel("<b>Reference data</b>"), 0, 0)
        grid.addWidget(self.demo_ref, 1, 0)
        grid.addWidget(self.file_ref, 2, 0)
        grid.addWidget(self.file_label, 3, 0)
        self.demo_case = QRadioButton("Validation demo case (vertical well)")
        self.cur_case = QRadioButton("Current case")
        self.demo_case.setChecked(True)
        g2 = QButtonGroup(self)
        g2.addButton(self.demo_case)
        g2.addButton(self.cur_case)
        grid.addWidget(QLabel("<b>Model case</b> (must match the reference well)"), 0, 1)
        grid.addWidget(self.demo_case, 1, 1)
        grid.addWidget(self.cur_case, 2, 1)
        self.run_btn = QPushButton("▶  Compare")
        self.run_btn.setObjectName("primary")
        self.run_btn.clicked.connect(self.compare)
        grid.addWidget(self.run_btn, 3, 1, alignment=Qt.AlignRight)
        hint = QLabel(f"CSV columns: case, quantity, reference_value, unit, data_type, source. "
                      f"Quantities: {', '.join(sorted(STEADY_QUANTITIES))}. "
                      f"data_type: {', '.join(DATA_TYPES)}.")
        hint.setWordWrap(True)
        hint.setObjectName("pageSubtitle")
        grid.addWidget(hint, 4, 0, 1, 2)
        self.body.addWidget(box)

        self.banner = Banner()
        self.body.addWidget(self.banner)
        cards = QHBoxLayout()
        self.cards = [KpiCard("Quantities compared"), KpiCard("Mean error"), KpiCard("Largest error")]
        for c in self.cards:
            cards.addWidget(c)
        self.body.addLayout(cards)
        split = QSplitter(Qt.Horizontal)
        self.c_parity = PlotCanvas(height=5)
        self.c_err = PlotCanvas(height=5)
        split.addWidget(self.c_parity)
        split.addWidget(self.c_err)
        self.body.addWidget(split)
        self.t_table = DataTable()
        self.t_table.setMinimumHeight(260)
        self.body.addWidget(self.t_table)
        self.t_summary = DataTable(stretch=True)
        self.t_summary.setMinimumHeight(220)
        self.body.addWidget(self.t_summary)
        exp = QPushButton("Export comparison CSV…")
        exp.clicked.connect(lambda: self.save_csv(self.table, "validation.csv", field_units=False))
        self.body.addWidget(exp, alignment=Qt.AlignLeft)
        self.compare()

    def _choose_file(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Reference CSV", str(ROOT / "data"),
                                              "CSV files (*.csv)")
        if path:
            self.ref_path = Path(path)
            self.file_label.setText(self.ref_path.name)
        else:
            self.demo_ref.setChecked(True)

    def compare(self) -> None:
        ref_path = DEMO_REF if self.demo_ref.isChecked() else self.ref_path
        try:
            ref = load_reference_csv(ref_path)
            if self.demo_case.isChecked():
                setup = load_setup(DEMO_CASE)
                result = setup.solver.solve(setup.conditions)
            else:
                _, result, err = self.state.steady()
                if err:
                    raise ValueError(err)
            table = validate_steady_state(result, ref)
        except Exception as exc:
            self.banner.show_message(f"<b>Comparison failed.</b> {exc}", "error")
            return
        self.table = table
        if (table["data_type"] == "synthetic_demonstration").any():
            self.banner.show_message(
                f"<b>Synthetic demonstration data.</b> {DEMO_DISCLAIMER} The bundled reference is "
                "an independent hand calculation (Applied Drilling Engineering field equations): "
                "a code verification. The 9 % annular difference is expected (exact vs. "
                "linearised slot equation).", "warning")
        else:
            types = ", ".join(sorted(table["data_type"].unique()))
            self.banner.show_message(f"Reference data type: <b>{types}</b>.", "success")
        worst = table.loc[table["percentage_error"].idxmax()]
        self.cards[0].set(str(len(table)))
        self.cards[1].set(f"{table['percentage_error'].mean():.2f} %")
        self.cards[2].set(f"{worst['percentage_error']:.2f} %", str(worst["quantity"]))
        plots.parity(self.c_parity.clear(), table)
        plots.error_bars(self.c_err.clear(), table)
        self.c_parity.draw()
        self.c_err.draw()
        self.t_table.set_frame(table.drop(columns=["disclaimer"]))
        self.t_summary.set_frame(summarize(table))
