"""Sensitivity analysis: one-at-a-time tornado charts and parameter sweeps."""

from __future__ import annotations

import copy
import json

import numpy as np
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QCheckBox, QComboBox, QGridLayout, QDoubleSpinBox, QFormLayout, QGroupBox, QHBoxLayout,
                               QProgressBar, QPushButton,
                               QSpinBox, QTabWidget, QVBoxLayout, QWidget)

from mpd_sim.analysis.sensitivity import PARAMETERS, one_at_a_time, sweep
from mpd_sim.io.loaders import build_setup

from .. import plots
from ..state import ROOT
from ..widgets import Banner, DataTable, PlotCanvas, Worker
from .base import Page

LABELS = {"pump_rate": "Pump rate", "mud_weight": "Mud weight", "plastic_viscosity": "Plastic viscosity (PV)",
          "yield_point": "Yield point (YP)", "hole_diameter": "Hole diameter", "pipe_od": "Pipe OD",
          "back_pressure": "Surface back pressure", "choke_opening": "Choke opening",
          "target_bhp": "Target BHP"}


def run_oat(progress, config, change, params):
    setup = build_setup(config, ROOT)
    return one_at_a_time(setup, change, params)


def run_sweep(progress, config, param, factors, units):
    setup = build_setup(config, ROOT)
    c, mud, w = setup.conditions, setup.mud, setup.window
    base = {
        "pump_rate": (units.q(c.pump_rate), f"Pump rate [{units.flow}]"),
        "mud_weight": (units.rho(mud.density), f"Mud weight [{units.density}]"),
        "plastic_viscosity": (mud.plastic_viscosity * 1000, "PV [cP]"),
        "yield_point": (mud.yield_point / 0.4788026, "YP [lbf/100 ft²]"),
        "hole_diameter": (1.0, "Hole diameter (× base)"),
        "pipe_od": (1.0, "Pipe OD (× base)"),
        "back_pressure": (units.p(setup.solver.surface_back_pressure(c)), f"SBP [{units.pressure}]"),
        "choke_opening": (c.choke_opening * 100, "Choke opening [%]"),
    }[param]
    data = sweep(setup, param, factors, lambda f: f * base[0])
    return data, base[1]


class SensitivityPage(Page):
    title = "Sensitivity analysis"
    subtitle = ("One-at-a-time perturbation of each input around the current case, showing how "
                "BHP, SPP and conventional ECD respond.")

    def __init__(self, state, parent=None) -> None:
        super().__init__(state, parent)
        self.worker = None
        self.oat = None
        self.sweep_data = None
        tabs = QTabWidget()

        # --- Tornado
        oat = QWidget()
        ov = QVBoxLayout(oat)
        ctrl = QHBoxLayout()
        form = QFormLayout()
        self.change = QSpinBox()
        self.change.setRange(1, 30)
        self.change.setValue(10)
        self.change.setSuffix(" %")
        form.addRow("Perturbation ±", self.change)
        fw = QWidget()
        fw.setLayout(form)
        ctrl.addWidget(fw)
        self.params = {}
        checks = QWidget()
        cgrid = QGridLayout(checks)
        cgrid.setContentsMargins(0, 0, 0, 0)
        for i, p in enumerate(PARAMETERS):
            box = QCheckBox(LABELS[p])
            box.setChecked(True)
            self.params[p] = box
            cgrid.addWidget(box, i // 3, i % 3)
        ctrl.addWidget(checks, 1)
        self.oat_btn = QPushButton("▶  Run sensitivity")
        self.oat_btn.setObjectName("primary")
        self.oat_btn.clicked.connect(self.run_oat)
        ctrl.addWidget(self.oat_btn)
        ov.addLayout(ctrl)
        self.oat_progress = QProgressBar()
        self.oat_progress.setRange(0, 0)
        self.oat_progress.setVisible(False)
        ov.addWidget(self.oat_progress)
        self.c_tornado = PlotCanvas(height=4.8)
        ov.addWidget(self.c_tornado)
        self.t_norm = DataTable(stretch=True)
        self.t_norm.setMinimumHeight(300)
        ov.addWidget(self.t_norm)
        exp = QPushButton("Export table CSV…")
        exp.clicked.connect(lambda: self.save_csv(self.oat, "sensitivity_oat.csv"))
        ov.addWidget(exp, alignment=Qt.AlignLeft)
        tabs.addTab(oat, "Tornado (one at a time)")

        # --- Sweep
        sw = QWidget()
        swl = QVBoxLayout(sw)
        row = QHBoxLayout()
        self.sweep_param = QComboBox()
        for p in PARAMETERS:
            if p != "target_bhp":
                self.sweep_param.addItem(LABELS[p], p)
        self.lo, self.hi = QDoubleSpinBox(), QDoubleSpinBox()
        for box, v in ((self.lo, 0.6), (self.hi, 1.4)):
            box.setRange(0.1, 3.0)
            box.setSingleStep(0.05)
            box.setValue(v)
            box.setPrefix("× ")
        self.points = QSpinBox()
        self.points.setRange(3, 41)
        self.points.setValue(13)
        form = QFormLayout()
        form.addRow("Parameter", self.sweep_param)
        form.addRow("From", self.lo)
        form.addRow("To", self.hi)
        form.addRow("Points", self.points)
        fw = QWidget()
        fw.setLayout(form)
        row.addWidget(fw)
        self.sweep_btn = QPushButton("▶  Run sweep")
        self.sweep_btn.setObjectName("primary")
        self.sweep_btn.clicked.connect(self.run_sweep)
        row.addWidget(self.sweep_btn, alignment=Qt.AlignBottom)
        row.addStretch(1)
        swl.addLayout(row)
        self.c_sweep = PlotCanvas(height=4)
        swl.addWidget(self.c_sweep)
        exp2 = QPushButton("Export sweep CSV…")
        exp2.clicked.connect(lambda: self.save_csv(self.sweep_data[0] if self.sweep_data else None,
                                                   "sweep.csv"))
        swl.addWidget(exp2, alignment=Qt.AlignLeft)
        swl.addStretch(1)
        tabs.addTab(sw, "Parameter sweep")

        self.banner = Banner()
        self.body.addWidget(self.banner)
        self.body.addWidget(tabs)

    def _start(self, fn, done, *args, busy_button) -> None:
        busy_button.setEnabled(False)
        self.oat_progress.setVisible(True)
        self.banner.show_message("")
        self.worker = Worker(fn, copy.deepcopy(self.state.config), *args)

        def finish(result):
            busy_button.setEnabled(True)
            self.oat_progress.setVisible(False)
            done(result)

        def fail(msg):
            busy_button.setEnabled(True)
            self.oat_progress.setVisible(False)
            self.banner.show_message(f"<b>Calculation failed.</b> {msg}", "error")
        self.worker.finished.connect(finish)
        self.worker.failed.connect(fail)
        self.worker.start()

    def run_oat(self) -> None:
        params = tuple(p for p, box in self.params.items() if box.isChecked())
        if not params:
            self.banner.show_message("Select at least one parameter.", "warning")
            return
        self._start(run_oat, self._oat_done, self.change.value() / 100, params,
                    busy_button=self.oat_btn)

    def _oat_done(self, table) -> None:
        self.oat = table
        self._draw_oat()

    def _draw_oat(self) -> None:
        if self.oat is None:
            return
        plots.tornados(self.c_tornado.clear(), self.oat, self.state.units, LABELS)
        self.c_tornado.draw()
        norm = self.oat[["parameter", "bhp_normalised_sensitivity", "spp_normalised_sensitivity",
                         "ecd_normalised_sensitivity"]].copy()
        norm.columns = ["Parameter", "BHP  S=(ΔY/Y)/(ΔX/X)", "SPP  S", "ECD  S"]
        norm["Parameter"] = norm["Parameter"].map(LABELS)
        self.t_norm.set_frame(norm)

    def run_sweep(self) -> None:
        factors = np.linspace(self.lo.value(), self.hi.value(), self.points.value())
        self._start(run_sweep, self._sweep_done, self.sweep_param.currentData(), factors,
                    self.state.units, busy_button=self.sweep_btn)

    def _sweep_done(self, payload) -> None:
        self.sweep_data = payload
        self._draw_sweep()

    def _draw_sweep(self) -> None:
        if not self.sweep_data:
            return
        plots.sweep(self.c_sweep.clear(), self.sweep_data[0], self.sweep_data[1], self.state.units)
        self.c_sweep.draw()

    def on_units_changed(self) -> None:
        self._draw_oat()
