"""Model & assumptions: README sections rendered as rich text (single source of truth)."""

from __future__ import annotations

import re

from PySide6.QtWidgets import QTabWidget, QTextBrowser

from ..state import ROOT
from .base import Page

SECTIONS = [("1", "Model status & assumptions"), ("8", "Mathematical model"),
            ("9", "Dynamics, choke & PID"), ("10", "Window & metrics"),
            ("16", "Limitations & calibration"), ("17", "References")]


def readme_section(text: str, number: str) -> str:
    match = re.search(rf"^## {number}\. .*?$(.*?)(?=^## \d+\. |\Z)", text, re.S | re.M)
    return match.group(1).strip() if match else "_Section not found in README.md._"


class ModelInfoPage(Page):
    title = "Model & assumptions"
    subtitle = ("What the simulator assumes, which equations and correlations it uses, and where "
                "they come from (from README.md).")

    def __init__(self, state, parent=None) -> None:
        super().__init__(state, parent)
        text = (ROOT / "README.md").read_text(encoding="utf-8")
        tabs = QTabWidget()
        for num, title in SECTIONS:
            browser = QTextBrowser()
            browser.setOpenExternalLinks(True)
            browser.setMarkdown(readme_section(text, num))
            browser.setMinimumHeight(620)
            tabs.addTab(browser, title)
        self.body.addWidget(tabs)
