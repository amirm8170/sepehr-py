"""Dynamic scenarios: choose a scenario, edit its schedules, run it in the background."""

from __future__ import annotations

import copy
from typing import Any, Dict, List

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QAbstractItemView, QCheckBox, QComboBox, QDoubleSpinBox,
                               QFormLayout, QGroupBox, QHBoxLayout, QHeaderView, QLabel,
                               QLineEdit, QProgressBar, QPushButton, QTableWidget,
                               QTableWidgetItem, QTabWidget, QVBoxLayout, QWidget)

from mpd_sim.io.loaders import find_unit_key
from mpd_sim.scenarios.runner import build_simulator

from ..state import ROOT
from ..widgets import Banner, Worker, unit_label
from .base import Page
from .results_view import ResultView

#: (schedule base key, quantity kind, default unit, label)
SCHEDULES = [
    ("pump_rate", "flow_rate", "gpm", "Rig pump"),
    ("backpressure_pump_rate", "flow_rate", "gpm", "BP pump"),
    ("choke_opening_delta", "dimensionless", "frac", "Choke Δ"),
    ("surface_back_pressure", "pressure", "psi", "SBP"),
    ("pipe_velocity", "velocity", "m_s", "Pipe speed"),
    ("target_bhp_emw", "density", "ppg", "Target"),
]
SCHEDULE_HELP = {
    "pump_rate": "Rig pump rate", "backpressure_pump_rate": "MPD back-pressure pump rate",
    "choke_opening_delta": "Change of choke opening relative to the initial opening",
    "surface_back_pressure": "SBP set-point (back-pressure actuation)",
    "pipe_velocity": "Pipe velocity, + down (surge), − up (swab)",
    "target_bhp_emw": "Target BHP as equivalent mud weight",
}


def simulate(progress, config: Dict[str, Any], name: str, scenario: Dict[str, Any]):
    """Run one scenario (executed in a worker thread)."""
    sim = build_simulator(config, name, scenario, ROOT)
    result = sim.run(on_progress=progress)
    return result, {"density": sim.model.density, "td_tvd": sim.model.td_tvd}


class ScheduleEditor(QWidget):
    """Enable checkbox + editable (time, value) table for one schedule."""

    def __init__(self, sched: Dict[str, Any], base: str, kind: str, default_unit: str) -> None:
        super().__init__()
        self.sched = sched
        self.unit = find_unit_key(sched, base, kind) or default_unit
        self.key = f"{base}_{self.unit}"
        lay = QVBoxLayout(self)
        lay.setContentsMargins(4, 6, 4, 4)
        self.enabled = QCheckBox(f"Use schedule: {SCHEDULE_HELP[base]}")
        self.enabled.setChecked(self.key in sched)
        lay.addWidget(self.enabled)
        self.table = QTableWidget(0, 2)
        self.table.setHorizontalHeaderLabels(["Time [s]", f"Value [{unit_label(self.unit)}]"])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table.verticalHeader().setVisible(False)
        self.table.setMinimumHeight(170)
        for t, v in sched.get(self.key, [[0.0, 0.0]]):
            self._add_row(t, v)
        lay.addWidget(self.table)
        row = QHBoxLayout()
        add, rem = QPushButton("+ Row"), QPushButton("− Row")
        add.clicked.connect(lambda: self._add_row(self._last_time() + 30, self._last_value()))
        rem.clicked.connect(lambda: self.table.removeRow(self.table.rowCount() - 1)
                            if self.table.rowCount() > 1 else None)
        row.addWidget(add)
        row.addWidget(rem)
        row.addStretch(1)
        lay.addLayout(row)
        self.enabled.toggled.connect(self.table.setEnabled)
        self.table.setEnabled(self.enabled.isChecked())

    def _add_row(self, t: float, v: float) -> None:
        r = self.table.rowCount()
        self.table.insertRow(r)
        self.table.setItem(r, 0, QTableWidgetItem(f"{t:g}"))
        self.table.setItem(r, 1, QTableWidgetItem(f"{v:g}"))

    def _cell(self, r: int, c: int) -> float:
        item = self.table.item(r, c)
        return float(item.text()) if item and item.text().strip() else 0.0

    def _last_time(self) -> float:
        n = self.table.rowCount()
        return self._cell(n - 1, 0) if n else 0.0

    def _last_value(self) -> float:
        n = self.table.rowCount()
        return self._cell(n - 1, 1) if n else 0.0

    def apply(self) -> None:
        """Write the table back into the scenario (raises ValueError on bad numbers)."""
        if not self.enabled.isChecked():
            self.sched.pop(self.key, None)
            return
        points = sorted([[self._cell(r, 0), self._cell(r, 1)] for r in range(self.table.rowCount())])
        self.sched[self.key] = points


class DynamicPage(Page):
    title = "Dynamic scenarios"
    subtitle = ("Stage B — time-domain MPD simulation. Pick a scenario, adjust its schedules and "
                "settings, run it, and inspect BHP, SPP, ECD, choke response and the pressure "
                "window over time.")

    def __init__(self, state, parent=None) -> None:
        super().__init__(state, parent)
        self.edits: Dict[str, Dict[str, Any]] = {}
        self.worker = None

        top = QHBoxLayout()
        setup = QGroupBox("Scenario")
        sv = QVBoxLayout(setup)
        self.combo = QComboBox()
        for name in state.catalog["scenarios"]:
            self.combo.addItem(state.scenario_label(name), name)
        self.combo.currentIndexChanged.connect(self._load_scenario)
        sv.addWidget(self.combo)
        self.desc = QLabel()
        self.desc.setWordWrap(True)
        self.desc.setObjectName("pageSubtitle")
        sv.addWidget(self.desc)
        form = QFormLayout()
        self.duration = QDoubleSpinBox()
        self.duration.setRange(1, 36000)
        self.duration.setDecimals(0)
        self.duration.setSuffix(" s")
        self.events = QLineEdit()
        self.events.setToolTip("Disturbance / setpoint-change times for the metrics, comma separated")
        self.model = QComboBox()
        self.model.addItem("Lumped MPD model (Kaasa et al. 2012)", "lumped")
        self.model.addItem("Quasi-steady time marching", "quasi_steady")
        self.pid = QCheckBox("Closed-loop PID control")
        form.addRow("Duration", self.duration)
        form.addRow("Event time(s) [s]", self.events)
        form.addRow("Dynamic model", self.model)
        form.addRow("", self.pid)
        sv.addLayout(form)
        run_row = QHBoxLayout()
        self.run_btn = QPushButton("▶  Run simulation")
        self.run_btn.setObjectName("primary")
        self.run_btn.clicked.connect(self.run)
        self.progress = QProgressBar()
        self.progress.setVisible(False)
        run_row.addWidget(self.run_btn)
        run_row.addWidget(self.progress, 1)
        sv.addLayout(run_row)
        setup.setMinimumWidth(420)
        top.addWidget(setup, 2)

        sched_box = QGroupBox("Schedules (piecewise-linear in time)")
        sl = QVBoxLayout(sched_box)
        self.sched_tabs = QTabWidget()
        sl.addWidget(self.sched_tabs)
        top.addWidget(sched_box, 3)
        self.body.addLayout(top)

        self.banner = Banner()
        self.body.addWidget(self.banner)
        self.view = ResultView(self)
        self.view.setVisible(False)
        self.body.addWidget(self.view)
        self.body.addStretch(1)
        self._load_scenario()

    # -------------------------------------------------------------- scenario
    def _scenario(self) -> Dict[str, Any]:
        name = self.combo.currentData()
        if name not in self.edits:
            self.edits[name] = copy.deepcopy(self.state.catalog["scenarios"][name])
        return self.edits[name]

    def _load_scenario(self) -> None:
        scen = self._scenario()
        self.desc.setText(scen.get("description", ""))
        self.duration.setValue(float(scen["duration_s"]))
        ev = scen.get("event_time_s", 0.0)
        self.events.setText(", ".join(f"{v:g}" for v in (ev if isinstance(ev, list) else [ev])))
        model = scen.get("dynamics", {}).get("model",
                                             self.state.config["dynamics"].get("model", "lumped"))
        self.model.setCurrentIndex(max(self.model.findData(model), 0))
        self.pid.setChecked(bool(scen.get("controller", {}).get("enabled", False)))
        self.sched_tabs.clear()
        self.editors: List[ScheduleEditor] = []
        sched = scen.setdefault("schedules", {})
        for base, kind, unit, label in SCHEDULES:
            ed = ScheduleEditor(sched, base, kind, unit)
            self.editors.append(ed)
            title = f"● {label}" if ed.enabled.isChecked() else label
            self.sched_tabs.addTab(ed, title)

    def _collect(self) -> Dict[str, Any]:
        scen = self._scenario()
        scen["duration_s"] = float(self.duration.value())
        evs = [float(x) for x in self.events.text().split(",") if x.strip()]
        scen["event_time_s"] = evs if len(evs) > 1 else (evs[0] if evs else 0.0)
        scen.setdefault("dynamics", {})["model"] = self.model.currentData()
        scen.setdefault("controller", {})["enabled"] = self.pid.isChecked()
        for ed in self.editors:
            ed.apply()
        return scen

    # ------------------------------------------------------------------- run
    def run(self) -> None:
        try:
            scen = copy.deepcopy(self._collect())
        except ValueError as exc:
            self.banner.show_message(f"<b>Check the inputs:</b> {exc}", "error")
            return
        name = self.combo.currentData()
        self.banner.show_message(f"Running <b>{self.state.scenario_label(name)}</b>…", "info")
        self.run_btn.setEnabled(False)
        self.progress.setValue(0)
        self.progress.setVisible(True)
        self.worker = Worker(simulate, copy.deepcopy(self.state.config), name, scen)
        self.worker.progress.connect(lambda f: self.progress.setValue(int(f * 100)))
        self.worker.finished.connect(self._done)
        self.worker.failed.connect(self._failed)
        self.worker.start()

    def _done(self, payload) -> None:
        result, meta = payload
        self.run_btn.setEnabled(True)
        self.progress.setVisible(False)
        ok = result.metrics["maintained_within_window"]
        self.banner.show_message(
            f"<b>Finished.</b> {result.description}. BHP stayed inside the pressure window."
            if ok else f"<b>Finished.</b> {result.description}. <b>BHP left the pressure window "
                       f"for {result.metrics['time_outside_window_s']:.1f} s.</b>",
            "success" if ok else "warning")
        self.view.show_result(result, meta)
        self.view.setVisible(True)

    def _failed(self, message: str) -> None:
        self.run_btn.setEnabled(True)
        self.progress.setVisible(False)
        self.banner.show_message(f"<b>Simulation failed.</b> {message}", "error")

    def on_units_changed(self) -> None:
        self.view.redraw()

    def on_case_loaded(self) -> None:
        self.view.setVisible(False)
        self.banner.show_message("")
