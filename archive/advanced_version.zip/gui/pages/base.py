"""Common page scaffolding: scrollable body, header, CSV export helper."""

from __future__ import annotations

from typing import Optional

import pandas as pd
from PySide6.QtWidgets import (QFileDialog, QMessageBox, QScrollArea, QVBoxLayout, QWidget)

from mpd_sim.io.exporters import add_field_unit_columns

from ..widgets import page_header


class Page(QScrollArea):
    """A scrollable page with a title. Subclasses fill ``self.body``."""

    title = "Page"
    subtitle = ""

    def __init__(self, state, parent=None) -> None:
        super().__init__(parent)
        self.state = state
        self.setWidgetResizable(True)
        inner = QWidget()
        inner.setObjectName("page")
        self.body = QVBoxLayout(inner)
        self.body.setContentsMargins(28, 22, 28, 22)
        self.body.setSpacing(12)
        self.body.addWidget(page_header(self.title, self.subtitle))
        self.setWidget(inner)
        state.case_loaded.connect(self.on_case_loaded)
        state.config_edited.connect(self.on_config_edited)
        state.units_changed.connect(self.on_units_changed)

    # Hooks -----------------------------------------------------------------
    def on_case_loaded(self) -> None:
        """Rebuild input widgets for a new case."""

    def on_config_edited(self) -> None:
        """Recompute after an input change."""

    def on_units_changed(self) -> None:
        """Redraw with the new display units."""

    def on_show(self) -> None:
        """Called when the page becomes visible."""

    # Helpers ---------------------------------------------------------------
    def save_csv(self, df: Optional[pd.DataFrame], default_name: str,
                 field_units: bool = True) -> None:
        if df is None or df.empty:
            QMessageBox.information(self, "Nothing to export", "Run a calculation first.")
            return
        path, _ = QFileDialog.getSaveFileName(self, "Export CSV", default_name, "CSV files (*.csv)")
        if path:
            (add_field_unit_columns(df) if field_units else df).to_csv(path, index=False)
            self.window().statusBar().showMessage(f"Saved {path}", 5000)
