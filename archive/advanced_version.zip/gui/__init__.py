"""
Desktop application (PySide6 / Qt) for the MPD well hydraulics simulator.

Start with:   python gui.py

Layout: navigation list on the left, one page per task on the right, menu bar
(File / View / Help) and a status bar. Charts are matplotlib figures embedded
in Qt with the standard zoom / pan / save toolbar. Long simulations run in a
background thread so the window stays responsive.
"""
