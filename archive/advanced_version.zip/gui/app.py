"""Application start-up: Qt application, style, main window."""

from __future__ import annotations

import os
import stat
import sys
from pathlib import Path


def unhide_qt_plugins() -> None:
    """
    Work around Qt skipping 'hidden' plugin files on macOS.

    Recent macOS versions give files inside a dot-folder (e.g. ``.venv``) the
    BSD ``hidden`` flag. Qt's plugin scanner ignores hidden files, so it
    reports "Could not find the Qt platform plugin 'cocoa'". Clearing the flag
    on PySide6's plugin files fixes it; it changes nothing else.
    """
    if sys.platform != "darwin" or not hasattr(os, "chflags"):
        return
    import PySide6
    plugins = Path(PySide6.__file__).parent / "Qt" / "plugins"
    for path in plugins.rglob("*"):
        try:
            flags = path.lstat().st_flags
            if flags & stat.UF_HIDDEN:
                os.chflags(path, flags & ~stat.UF_HIDDEN)
        except OSError:
            pass


def main() -> int:
    unhide_qt_plugins()
    from PySide6.QtCore import QLocale
    from PySide6.QtGui import QFont
    from PySide6.QtWidgets import QApplication

    from .theme import STYLE_SHEET, apply_matplotlib_style

    # Engineering convention: "." as decimal separator regardless of OS locale.
    locale = QLocale(QLocale.English, QLocale.UnitedStates)
    locale.setNumberOptions(QLocale.OmitGroupSeparator)
    QLocale.setDefault(locale)
    app = QApplication.instance() or QApplication(sys.argv)
    app.setApplicationName("MPD Hydraulics Simulator")
    app.setStyle("Fusion")                 # same look on macOS, Windows and Linux
    app.setFont(QFont(app.font().family(), 13 if sys.platform == "darwin" else 10))
    app.setStyleSheet(STYLE_SHEET)
    apply_matplotlib_style()
    from .main_window import MainWindow    # import after QApplication exists
    window = MainWindow()
    window.show()
    return app.exec()
