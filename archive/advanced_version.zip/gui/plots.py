"""
Chart drawing for the desktop app (matplotlib on a given Figure).

Rules: one y-axis per panel (stacked panels instead of dual axes), fixed
colour order, red reserved for pressure-window limits/violations, units from
the selected display system.
"""

from __future__ import annotations

from typing import Dict, Optional, Sequence

import numpy as np
import pandas as pd
from matplotlib.figure import Figure

from mpd_sim.constants import GRAVITY

from .theme import COLORS, DisplayUnits


def _shade_unsafe(ax, ts: pd.DataFrame) -> None:
    unsafe = (ts["window_status"] != "safe").to_numpy()
    if unsafe.any():
        ax.fill_between(ts["time_s"], 0, 1, where=unsafe, transform=ax.get_xaxis_transform(),
                        color=COLORS["critical"], alpha=0.10, linewidth=0,
                        label="Outside window")


def _limits(ax, pore: float, frac: float) -> None:
    ax.axhline(pore, color=COLORS["critical"], ls="--", lw=1.2)
    ax.axhline(frac, color=COLORS["critical"], ls=":", lw=1.4)
    ax.annotate("Pore pressure", (1, pore), xycoords=("axes fraction", "data"),
                xytext=(-4, -12), textcoords="offset points", ha="right", fontsize=8,
                color=COLORS["critical"])
    ax.annotate("Fracture pressure", (1, frac), xycoords=("axes fraction", "data"),
                xytext=(-4, 4), textcoords="offset points", ha="right", fontsize=8,
                color=COLORS["critical"])


# ---------------------------------------------------------------------------
# Steady state
# ---------------------------------------------------------------------------
def pressure_profile(fig: Figure, result, window, u: DisplayUnits, depth: str = "md") -> None:
    ax = fig.add_subplot(111)
    col = "md_m" if depth == "md" else "tvd_m"
    label = "Measured depth" if depth == "md" else "True vertical depth"
    ann = result.annulus_profile
    ax.plot(u.p(ann["hydrostatic_contribution_pa"]), u.z(ann[col]), color=COLORS["muted"],
            ls="-.", lw=1.3, label="Hydrostatic only (ρ·g·TVD)")
    ax.plot(u.p(result.string_profile["pressure_pa"]), u.z(result.string_profile[col]),
            color=COLORS["s1"], lw=2.2, label="Inside drill string")
    ax.plot(u.p(ann["pressure_pa"]), u.z(ann[col]), color=COLORS["s2"], lw=2.2, label="Annulus")
    if window is not None:
        td = u.z(ann[col].iloc[-1])
        ax.plot([u.p(window.pore_pressure)], [td], marker="<", ms=10, ls="none",
                color=COLORS["critical"], label="Pore / fracture at TD")
        ax.plot([u.p(window.fracture_pressure)], [td], marker=">", ms=10, ls="none",
                color=COLORS["critical"])
    ax.invert_yaxis()
    ax.set_xlabel(f"Pressure [{u.pressure}]")
    ax.set_ylabel(f"{label} [{u.depth}]")
    ax.set_title(f"Pressure vs {label.lower()}")
    ax.legend(loc="lower left")


def window_gauge(fig: Figure, result, window, u: DisplayUnits) -> None:
    ax = fig.add_subplot(111)
    pore, frac = u.p(window.pore_pressure), u.p(window.fracture_pressure)
    pad = 0.35 * (frac - pore)
    lo = min(pore - pad, u.p(result.bhp_static) - pad * 0.15)
    hi = max(frac + pad, u.p(result.bhp) + pad * 0.15)
    for x0, x1, color, text in ((lo, pore, COLORS["critical_bg"], "Kick risk"),
                                (pore, frac, COLORS["good_bg"], "Safe window"),
                                (frac, hi, COLORS["critical_bg"], "Loss risk")):
        ax.axvspan(x0, x1, color=color, lw=0)
        ax.text((x0 + x1) / 2, 0.82, text, ha="center", fontsize=8.5, color="#55554f")
    for x in (pore, frac):
        ax.axvline(x, color=COLORS["critical"], lw=1.2)
    marks = [(u.p(result.bhp_static), "Static BHP", COLORS["muted"], 0.32, 70),
             (u.p(window.target_bhp), "Target", COLORS["s2"], 0.5, 90),
             (u.p(result.bhp), "Circulating BHP", COLORS["s1"], 0.5, 150)]
    for x, name, color, y, size in marks:
        ax.scatter([x], [y], s=size, marker="D", color=color, edgecolor="white", zorder=5,
                   label=name)
    ax.set_xlim(lo, hi)
    ax.set_ylim(0, 1)
    ax.set_yticks([])
    ax.grid(False)
    ax.spines["left"].set_visible(False)
    ax.set_xlabel(f"Pressure at TD [{u.pressure}]")
    ax.legend(loc="lower right", bbox_to_anchor=(1.0, 1.0), ncol=3)
    ax.set_title("Pressure window at TD")


def spp_breakdown(fig: Figure, result, u: DisplayUnits) -> None:
    ax = fig.add_subplot(111)
    items = [("Drill pipe friction", result.losses.drill_pipe), ("BHA friction", result.losses.bha),
             ("Bit nozzles", result.losses.bit), ("Annulus friction", result.losses.annulus),
             ("Surface back pressure", result.surface_back_pressure)]
    names = [i[0] for i in items][::-1]
    vals = np.array([u.p(i[1]) for i in items][::-1])
    total = u.p(result.spp)
    ax.barh(names, vals, color=COLORS["s1"], height=0.6)
    for y, v in enumerate(vals):
        ax.annotate(f"{v:,.1f}  ({v / total:.0%})", (v, y), xytext=(4, 0),
                    textcoords="offset points", va="center", fontsize=8.5)
    ax.set_xlim(0, vals.max() * 1.35)
    ax.set_xlabel(f"Pressure [{u.pressure}]")
    ax.set_title(f"SPP build-up — total {total:,.1f} {u.pressure}")
    ax.grid(axis="y", visible=False)


def regime_map(fig: Figure, result, u: DisplayUnits) -> None:
    table = result.segment_table()
    axes = fig.subplots(1, 2, sharey=True)
    for ax, path, title in zip(axes, ("drill_string", "annulus"), ("Drill string", "Annulus")):
        t = table[table["flow_path"] == path]
        depth = u.z(0.5 * (t["md_top_m"] + t["md_bottom_m"]))
        ax.plot(t["reynolds"], depth, color=COLORS["s1"], label="Reynolds number")
        ax.plot(t["critical_reynolds"], depth, color=COLORS["s2"], ls="--",
                label="Critical Re (Hanks)")
        ax.set_xscale("log")
        ax.set_title(title)
        ax.set_xlabel("Reynolds number [-]")
    axes[0].invert_yaxis()
    axes[0].set_ylabel(f"MD [{u.depth}]")
    axes[0].legend(loc="lower left")


# ---------------------------------------------------------------------------
# Case setup
# ---------------------------------------------------------------------------
def trajectory(fig: Figure, traj, u: DisplayUnits, view: str) -> None:
    north, east = traj.coordinates()
    if view == "3D":
        ax = fig.add_subplot(111, projection="3d")
        ax.plot(u.z(east), u.z(north), -u.z(traj.tvd), color=COLORS["s1"], lw=2.5)
        ax.set_xlabel(f"East [{u.depth}]")
        ax.set_ylabel(f"North [{u.depth}]")
        ax.set_zlabel(f"−TVD [{u.depth}]")
        return
    ax = fig.add_subplot(111)
    if view == "Vertical section":
        ax.plot(u.z(np.hypot(north, east)), u.z(traj.tvd), "-o", ms=3, color=COLORS["s1"])
        ax.invert_yaxis()
        ax.set_xlabel(f"Horizontal departure [{u.depth}]")
        ax.set_ylabel(f"TVD [{u.depth}]")
        ax.set_aspect("equal", adjustable="datalim")
    elif view == "Plan view":
        ax.plot(u.z(east), u.z(north), "-o", ms=3, color=COLORS["s1"])
        ax.set_xlabel(f"East [{u.depth}]")
        ax.set_ylabel(f"North [{u.depth}]")
        ax.set_aspect("equal", adjustable="datalim")
    else:
        ax.plot(traj.inclination, u.z(traj.md), "-o", ms=3, color=COLORS["s1"])
        ax.invert_yaxis()
        ax.set_xlabel("Inclination [deg]")
        ax.set_ylabel(f"MD [{u.depth}]")
    ax.set_title(view)


def flow_curve(fig: Figure, plastic_viscosity: float, yield_stress: float) -> None:
    ax = fig.add_subplot(111)
    rate = np.linspace(0, 1100, 200)
    ax.plot(rate, yield_stress + plastic_viscosity * rate, color=COLORS["s1"],
            label="Bingham model")
    pts = np.array([511.0, 1022.0])
    ax.plot(pts, yield_stress + plastic_viscosity * pts, "o", ms=8, color=COLORS["s2"],
            mec="white", label="300 / 600 rpm")
    ax.set_xlabel("Shear rate γ̇ [1/s]")
    ax.set_ylabel("Shear stress τ [Pa]")
    ax.set_title("Flow curve  τ = τy + μp·γ̇")
    ax.set_xlim(0)
    ax.set_ylim(0)
    ax.legend()


# ---------------------------------------------------------------------------
# Dynamic results
# ---------------------------------------------------------------------------
def pressures_time(fig: Figure, ts: pd.DataFrame, u: DisplayUnits,
                   extra: Optional[Dict[str, pd.DataFrame]] = None) -> None:
    ax1, ax2, ax3 = fig.subplots(3, 1, sharex=True, height_ratios=[2.2, 1, 1])
    t = ts["time_s"]
    _shade_unsafe(ax1, ts)
    ax1.plot(t, u.p(ts["target_bhp_pa"]), color=COLORS["s2"], ls="--", lw=1.5, label="Target BHP")
    ax1.plot(t, u.p(ts["bhp_pa"]), color=COLORS["s1"], lw=2.2, label="BHP")
    for (name, other), color in zip((extra or {}).items(), (COLORS["muted"], COLORS["s3"])):
        ax1.plot(other["time_s"], u.p(other["bhp_pa"]), color=color, lw=1.6, label=name)
    _limits(ax1, u.p(ts["pore_pressure_pa"].iloc[0]), u.p(ts["fracture_pressure_pa"].iloc[0]))
    ax1.set_ylabel(f"BHP [{u.pressure}]")
    ax1.set_title("Bottomhole pressure")
    ax1.legend(loc="best", ncol=2)
    ax2.plot(t, u.p(ts["spp_pa"]), color=COLORS["s1"])
    ax2.set_ylabel(f"SPP [{u.pressure}]")
    ax2.set_title("Stand-pipe pressure")
    ax3.plot(t, u.p(ts["sbp_pa"]), color=COLORS["s1"])
    ax3.set_ylabel(f"SBP [{u.pressure}]")
    ax3.set_title("Surface back pressure")
    ax3.set_xlabel("Time [s]")


def ecd_time(fig: Figure, ts: pd.DataFrame, u: DisplayUnits, mud_density: float,
             td_tvd: float) -> None:
    ax = fig.add_subplot(111)
    t = ts["time_s"]
    _shade_unsafe(ax, ts)
    ax.plot(t, u.rho(ts["emw_bhp_kg_m3"]), color=COLORS["s1"], lw=2.2,
            label="EMW of BHP (incl. SBP)")
    ax.plot(t, u.rho(ts["ecd_conventional_kg_m3"]), color=COLORS["s3"],
            label="Conventional ECD (MW + annular friction)")
    ax.axhline(u.rho(mud_density), color=COLORS["muted"], ls="-.", lw=1.1, label="Mud weight")
    g_tvd = GRAVITY * td_tvd
    _limits(ax, u.rho(ts["pore_pressure_pa"].iloc[0] / g_tvd),
            u.rho(ts["fracture_pressure_pa"].iloc[0] / g_tvd))
    ax.set_xlabel("Time [s]")
    ax.set_ylabel(f"Equivalent density [{u.density}]")
    ax.set_title("Equivalent density at TD")
    ax.legend(loc="lower left")


def flow_and_actuator(fig: Figure, ts: pd.DataFrame, u: DisplayUnits, actuation: str) -> None:
    has_pipe = ts["pipe_velocity_m_s"].abs().max() > 0
    axes = fig.subplots(3 if has_pipe else 2, 1, sharex=True)
    t = ts["time_s"]
    ax = axes[0]
    ax.plot(t, u.q(ts["pump_rate_m3_s"]), color=COLORS["s1"], label="Rig pump")
    if ts["backpressure_pump_rate_m3_s"].abs().max() > 0:
        ax.plot(t, u.q(ts["backpressure_pump_rate_m3_s"]), color=COLORS["s2"],
                label="Back-pressure pump")
    ax.plot(t, u.q(ts["q_bit_m3_s"]), color=COLORS["s3"], ls="--", label="Flow at bit")
    ax.plot(t, u.q(ts["q_choke_m3_s"]), color=COLORS["s5"], ls=":", label="Flow through choke")
    ax.set_ylabel(f"Flow [{u.flow}]")
    ax.set_title("Flow rates")
    ax.legend(loc="best", ncol=2)
    ax = axes[1]
    if actuation == "choke":
        ax.plot(t, ts["choke_opening"] * 100, color=COLORS["s1"], label="Applied")
        ax.plot(t, ts["actuator_command"] * 100, color=COLORS["s2"], ls="--", lw=1.2,
                label="Command")
        ax.set_ylabel("Choke opening [%]")
        ax.set_title("Choke position")
    else:
        ax.plot(t, u.p(ts["sbp_command_pa"]), color=COLORS["s1"], label="Applied set-point")
        ax.plot(t, u.p(ts["actuator_command"]), color=COLORS["s2"], ls="--", lw=1.2,
                label="Command")
        ax.set_ylabel(f"SBP set-point [{u.pressure}]")
        ax.set_title("Back-pressure actuator")
    ax.legend(loc="best")
    if has_pipe:
        axes[2].plot(t, ts["pipe_velocity_m_s"], color=COLORS["s1"])
        axes[2].set_ylabel("Pipe velocity [m/s]\n(+ down)")
        axes[2].set_title("Pipe movement")
    axes[-1].set_xlabel("Time [s]")


def window_strip(fig: Figure, ts: pd.DataFrame) -> None:
    ax = fig.add_subplot(111)
    codes = ts["window_status"].map({"kick_risk": -1, "safe": 0, "loss_risk": 1})
    _shade_unsafe(ax, ts)
    ax.step(ts["time_s"], codes, where="post", color=COLORS["s1"], lw=2)
    ax.set_yticks([-1, 0, 1])
    ax.set_yticklabels(["Kick risk", "Safe", "Loss risk"])
    ax.set_ylim(-1.5, 1.5)
    ax.set_xlabel("Time [s]")
    ax.set_title("Pressure-window status")


def profiles_over_time(fig: Figure, profiles: pd.DataFrame, u: DisplayUnits) -> None:
    ax = fig.add_subplot(111)
    ann = profiles[profiles["flow_path"] == "annulus"]
    times = np.sort(ann["time_s"].unique())
    if times.size > 10:
        times = times[np.linspace(0, times.size - 1, 10).astype(int)]
    for k, t in enumerate(times):
        p = ann[ann["time_s"] == t]
        alpha = 0.3 + 0.7 * k / max(len(times) - 1, 1)
        ax.plot(u.p(p["pressure_pa"] - p["hydrostatic_contribution_pa"]), u.z(p["tvd_m"]),
                color=COLORS["s1"], alpha=alpha, label=f"t = {t:.0f} s")
    ax.invert_yaxis()
    ax.set_xlabel(f"Annulus pressure above hydrostatic (SBP + friction) [{u.pressure}]")
    ax.set_ylabel(f"TVD [{u.depth}]")
    ax.set_title("Annulus pressure profile over time")
    ax.legend(loc="lower right", ncol=2)


def control_error_and_terms(fig: Figure, ts: pd.DataFrame, u: DisplayUnits,
                            tolerance_pa: float) -> None:
    ax1, ax2 = fig.subplots(2, 1, sharex=True)
    t = ts["time_s"]
    tol = u.p(tolerance_pa)
    ax1.axhspan(-tol, tol, color=COLORS["s3"], alpha=0.12, lw=0,
                label=f"±{tol:.1f} {u.pressure} settling band")
    ax1.plot(t, u.p(ts["control_error_pa"]), color=COLORS["s1"])
    ax1.set_ylabel(f"Error [{u.pressure}]")
    ax1.set_title("Control error (target − BHP)")
    ax1.legend(loc="best")
    for col, name, color in (("pid_p", "P", COLORS["s1"]), ("pid_i", "I", COLORS["s2"]),
                             ("pid_d", "D", COLORS["s3"])):
        ax2.plot(t, ts[col], color=color, label=name)
    ax2.set_ylabel("Contribution\n[actuator units]")
    ax2.set_title("PID terms")
    ax2.set_xlabel("Time [s]")
    ax2.legend(loc="best", ncol=3)


# ---------------------------------------------------------------------------
# Analysis
# ---------------------------------------------------------------------------
def tornados(fig: Figure, table: pd.DataFrame, u: DisplayUnits, labels: Dict[str, str]) -> None:
    specs = [("bhp", "pa", u.p, u.pressure, "BHP"), ("spp", "pa", u.p, u.pressure, "SPP"),
             ("ecd", "kg_m3", u.rho, u.density, "ECD")]
    axes = fig.subplots(1, 3)
    for ax, (out, si, conv, unit, title) in zip(axes, specs):
        t = table.copy()
        t["low"] = conv(t[f"{out}_low_change_{si}"])
        t["high"] = conv(t[f"{out}_high_change_{si}"])
        t = t.reindex((t["high"] - t["low"]).abs().sort_values().index)
        y = np.arange(len(t))
        ax.barh(y, t["low"], color=COLORS["s1"], height=0.6, label="Parameter −Δ")
        ax.barh(y, t["high"], color=COLORS["s2"], height=0.6, alpha=0.9, label="Parameter +Δ")
        ax.set_yticks(y)
        ax.set_yticklabels([labels.get(p, p) for p in t["parameter"]])
        ax.axvline(0, color=COLORS["muted"], lw=0.9)
        ax.set_xlabel(f"Δ{title.split()[-1]} [{unit}]")
        ax.set_title(f"Change in {title}")
        ax.grid(axis="y", visible=False)
    axes[0].legend(loc="lower right")


def sweep(fig: Figure, data: pd.DataFrame, x_label: str, u: DisplayUnits) -> None:
    axes = fig.subplots(1, 3)
    specs = [("bhp_pa", u.p, f"BHP [{u.pressure}]"), ("spp_pa", u.p, f"SPP [{u.pressure}]"),
             ("ecd_kg_m3", u.rho, f"Conventional ECD [{u.density}]")]
    for ax, (col, conv, label) in zip(axes, specs):
        ax.plot(data["value_display"], conv(data[col]), "-o", ms=5, color=COLORS["s1"],
                mec="white")
        ax.set_xlabel(x_label)
        ax.set_ylabel(label)
        ax.set_title(label.split(" [")[0])


def parity(fig: Figure, table: pd.DataFrame) -> None:
    ax = fig.add_subplot(111)
    unit = table["unit"].mode().iloc[0]
    t = table[table["unit"] == unit]
    ref, mod = t["reference_value"], t["model_value"]
    hi = float(max(ref.max(), mod.max())) * 1.1
    xs = np.linspace(0, hi, 10)
    ax.plot(xs, xs, color=COLORS["muted"], lw=1, label="1:1")
    for band, ls in ((0.05, "--"), (0.10, ":")):
        ax.plot(xs, xs * (1 + band), color=COLORS["muted"], lw=0.8, ls=ls, label=f"±{band:.0%}")
        ax.plot(xs, xs * (1 - band), color=COLORS["muted"], lw=0.8, ls=ls)
    colors = [COLORS[k] for k in ("s1", "s2", "s3", "s4", "s5")] * 3
    for q, c in zip(t["quantity"].unique(), colors):
        sub = t[t["quantity"] == q]
        ax.plot(sub["reference_value"], sub["model_value"], "o", ms=9, color=c, mec="white",
                label=q.replace("_", " "))
    ax.set_xlim(0, hi)
    ax.set_ylim(0, hi)
    ax.set_aspect("equal")
    ax.set_xlabel(f"Reference [{unit}]")
    ax.set_ylabel(f"Model [{unit}]")
    ax.set_title("Model vs reference")
    ax.legend(loc="upper left", fontsize=8)


def error_bars(fig: Figure, table: pd.DataFrame) -> None:
    ax = fig.add_subplot(111)
    t = table.sort_values("percentage_error")
    ax.barh(t["quantity"].str.replace("_", " "), t["percentage_error"], color=COLORS["s1"],
            height=0.6)
    for y, v in enumerate(t["percentage_error"]):
        ax.annotate(f"{v:.2f} %", (v, y), xytext=(4, 0), textcoords="offset points",
                    va="center", fontsize=8.5)
    ax.set_xlim(0, max(t["percentage_error"].max() * 1.3, 1))
    ax.set_xlabel("Error |model − ref| / |ref| [%]")
    ax.set_title("Percentage error")
    ax.grid(axis="y", visible=False)
