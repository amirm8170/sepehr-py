"""
Application state shared by all pages.

* ``config`` — the working case, a dict shaped exactly like
  ``config/base_case.yaml`` (unit-suffixed keys). Every page edits this dict.
* Signals tell pages when to refresh:
    - ``case_loaded``  : a whole new case replaced the old one → rebuild inputs
    - ``config_edited``: an input changed → recompute (debounced 300 ms)
    - ``units_changed``: display units switched → redraw
* Steady-state results are cached per configuration (JSON key).
"""

from __future__ import annotations

import copy
import json
from collections import OrderedDict
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

from PySide6.QtCore import QObject, QTimer, Signal

from mpd_sim.io.loaders import SimulationSetup, build_setup, load_yaml, resolve_path
from mpd_sim.scenarios.runner import load_scenario_catalog

from .theme import UNIT_SYSTEMS, DisplayUnits

ROOT = Path(__file__).resolve().parents[1]
CONFIG_DIR = ROOT / "config"
BASE_CASE = CONFIG_DIR / "base_case.yaml"
SCENARIOS_FILE = CONFIG_DIR / "scenarios.yaml"
CASES = {
    "Base case — J-well, MPD (synthetic)": BASE_CASE,
    "Validation demo — vertical well (synthetic)": CONFIG_DIR / "validation_demo_case.yaml",
}


def with_defaults(config: Dict[str, Any]) -> Dict[str, Any]:
    """Fill sections needed by the dynamic pages from the base case if missing."""
    base = load_yaml(BASE_CASE)
    for section in ("choke", "back_pressure_actuator", "dynamics", "controller", "numerics"):
        config.setdefault(section, copy.deepcopy(base.get(section, {})))
        for key, value in base.get(section, {}).items():
            config[section].setdefault(key, copy.deepcopy(value))
    traj = config["well"]["trajectory"]
    if "file" in traj:
        traj["file"] = str(resolve_path(traj["file"], ROOT))
    return config


class AppState(QObject):
    """Holds the working case and caches; emits signals on changes."""

    case_loaded = Signal()
    config_edited = Signal()
    units_changed = Signal()

    def __init__(self) -> None:
        super().__init__()
        self.catalog = load_scenario_catalog(SCENARIOS_FILE)
        self.units: DisplayUnits = next(iter(UNIT_SYSTEMS.values()))
        self.units_name = next(iter(UNIT_SYSTEMS))
        self._setups: "OrderedDict[str, Any]" = OrderedDict()
        self._debounce = QTimer(self)
        self._debounce.setSingleShot(True)
        self._debounce.setInterval(300)
        self._debounce.timeout.connect(self.config_edited.emit)
        self.config: Dict[str, Any] = {}
        self.case_label = ""
        self.load_case(BASE_CASE, "Base case — J-well, MPD (synthetic)", emit=False)

    # ------------------------------------------------------------- case
    def load_case(self, path: Path, label: str, emit: bool = True) -> None:
        self.set_config(load_yaml(path), label, emit)

    def set_config(self, config: Dict[str, Any], label: str, emit: bool = True) -> None:
        self.config = with_defaults(config)
        self.case_label = label
        if emit:
            self.case_loaded.emit()
            self.config_edited.emit()

    def touch(self) -> None:
        """Call after editing ``config``; triggers a debounced recompute."""
        self._debounce.start()

    def set_units(self, name: str) -> None:
        self.units_name = name
        self.units = UNIT_SYSTEMS[name]
        self.units_changed.emit()

    # ------------------------------------------------------------- compute
    def _key(self, cfg: Optional[Dict[str, Any]] = None) -> str:
        return json.dumps(cfg if cfg is not None else self.config, sort_keys=True, default=str)

    def setup(self, cfg: Optional[Dict[str, Any]] = None
              ) -> Tuple[Optional[SimulationSetup], Optional[str]]:
        """Build (cached) the SI simulation objects; returns (setup, error message)."""
        key = self._key(cfg)
        if key not in self._setups:
            try:
                built = build_setup(json.loads(key), ROOT)
                self._setups[key] = {"setup": built, "steady": None, "error": None}
            except Exception as exc:          # invalid physical input → message, not crash
                self._setups[key] = {"setup": None, "steady": None,
                                     "error": f"{type(exc).__name__}: {exc}"}
            while len(self._setups) > 12:
                self._setups.popitem(last=False)
        entry = self._setups[key]
        return entry["setup"], entry["error"]

    def steady(self, cfg: Optional[Dict[str, Any]] = None):
        """(setup, steady-state result, error) for the current case (cached)."""
        setup, err = self.setup(cfg)
        if err:
            return None, None, err
        entry = self._setups[self._key(cfg)]
        if entry["steady"] is None:
            try:
                entry["steady"] = setup.solver.solve(setup.conditions, setup.window)
            except Exception as exc:
                return setup, None, f"{type(exc).__name__}: {exc}"
        return setup, entry["steady"], None

    def scenario_label(self, name: str) -> str:
        desc = self.catalog["scenarios"].get(name, {}).get("description", "")
        prefix = desc.split(" - ")[0] if desc.startswith("Scenario") else ""
        title = name.replace("_", " ").capitalize().replace("Pid", "PID").replace("pid", "PID")
        return f"{prefix} · {title}" if prefix else title
