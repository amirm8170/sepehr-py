"""
Reusable Qt widgets.

* PlotCanvas     — matplotlib figure + navigation toolbar (zoom, pan, save PNG)
* KpiCard        — headline number with label and coloured note
* Banner         — coloured message box (info / success / warning / error)
* DataTable      — QTableView showing a pandas DataFrame
* bound inputs   — spin boxes / combos that edit the case config in place
* Worker         — runs a function in a background thread with progress
"""

from __future__ import annotations

import math
from typing import Any, Callable, Dict, Iterable, Optional, Sequence

import numpy as np
import pandas as pd
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg, NavigationToolbar2QT
from matplotlib.figure import Figure
from PySide6.QtCore import QAbstractTableModel, QModelIndex, QObject, Qt, QThread, Signal
from PySide6.QtWidgets import (QCheckBox, QComboBox, QDoubleSpinBox, QFrame, QHBoxLayout,
                               QHeaderView, QLabel, QSizePolicy, QTableView, QVBoxLayout,
                               QWidget)

from mpd_sim.io.loaders import find_unit_key

from .theme import COLORS, UNIT_TAG_LABELS


# ---------------------------------------------------------------------------
# Layout helpers
# ---------------------------------------------------------------------------
def page_header(title: str, subtitle: str) -> QWidget:
    box = QWidget()
    lay = QVBoxLayout(box)
    lay.setContentsMargins(0, 0, 0, 6)
    lay.setSpacing(2)
    t = QLabel(title)
    t.setObjectName("pageTitle")
    s = QLabel(subtitle)
    s.setObjectName("pageSubtitle")
    s.setWordWrap(True)
    lay.addWidget(t)
    lay.addWidget(s)
    return box


def hbox(*widgets, stretch_last: bool = False, spacing: int = 10) -> QWidget:
    w = QWidget()
    lay = QHBoxLayout(w)
    lay.setContentsMargins(0, 0, 0, 0)
    lay.setSpacing(spacing)
    for item in widgets:
        if item is None:
            lay.addStretch(1)
        else:
            lay.addWidget(item)
    if stretch_last:
        lay.addStretch(1)
    return w


# ---------------------------------------------------------------------------
# Display widgets
# ---------------------------------------------------------------------------
class PlotCanvas(QWidget):
    """Matplotlib figure embedded in Qt, with zoom / pan / save toolbar."""

    def __init__(self, height: float = 4.0, toolbar: bool = True, parent=None) -> None:
        super().__init__(parent)
        self.figure = Figure(figsize=(6, height), dpi=100, layout="constrained")
        self.canvas = FigureCanvasQTAgg(self.figure)
        self.canvas.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.canvas.setMinimumHeight(int(height * 70))
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)
        if toolbar:
            bar = NavigationToolbar2QT(self.canvas, self)
            bar.setIconSize(bar.iconSize() * 0.8)
            lay.addWidget(bar)
        lay.addWidget(self.canvas)

    def clear(self) -> Figure:
        self.figure.clear()
        return self.figure

    def draw(self) -> None:
        self.canvas.draw_idle()


class KpiCard(QFrame):
    """A headline value: small label, big number, optional coloured note."""

    TONES = {"good": COLORS["good"], "bad": COLORS["critical"], "warn": COLORS["warn"],
             "muted": COLORS["muted"]}

    def __init__(self, label: str, tooltip: str = "", parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("card")
        lay = QVBoxLayout(self)
        lay.setContentsMargins(14, 10, 14, 10)
        lay.setSpacing(2)
        self.label = QLabel(label)
        self.label.setObjectName("cardLabel")
        self.value = QLabel("—")
        self.value.setObjectName("cardValue")
        self.note = QLabel("")
        self.note.setObjectName("cardNote")
        for w in (self.label, self.value, self.note):
            lay.addWidget(w)
        if tooltip:
            self.setToolTip(tooltip)

    def set(self, value: str, note: str = "", tone: str = "muted") -> None:
        self.value.setText(value)
        self.note.setText(note)
        self.note.setStyleSheet(f"color: {self.TONES.get(tone, COLORS['muted'])};")


class Banner(QLabel):
    """Coloured message strip."""

    STYLES = {"info": ("#e8f1fc", COLORS["accent"]), "success": (COLORS["good_bg"], COLORS["good"]),
              "warning": (COLORS["warn_bg"], COLORS["warn"]),
              "error": (COLORS["critical_bg"], COLORS["critical"])}

    def __init__(self, text: str = "", kind: str = "info", parent=None) -> None:
        super().__init__(parent)
        self.setWordWrap(True)
        self.setTextFormat(Qt.RichText)
        self.show_message(text, kind)

    def show_message(self, text: str, kind: str = "info") -> None:
        bg, fg = self.STYLES.get(kind, self.STYLES["info"])
        self.setStyleSheet(f"background:{bg}; color:{fg}; border:1px solid {fg}33;"
                           "border-radius:6px; padding:8px 12px; font-weight:500;")
        self.setText(text)
        self.setVisible(bool(text))


class StatusBadge(QLabel):
    """Pressure-window status pill."""

    TEXT = {"safe": ("● Safe — BHP inside the pressure window", "good"),
            "kick_risk": ("▲ Kick risk — BHP below pore pressure", "critical"),
            "loss_risk": ("▲ Loss risk — BHP above fracture pressure", "critical")}

    def set_status(self, status: Optional[str]) -> None:
        text, tone = self.TEXT.get(status or "", ("", "muted"))
        fg = COLORS.get(tone, COLORS["muted"])
        bg = COLORS.get(f"{tone}_bg", "white")
        self.setStyleSheet(f"background:{bg}; color:{fg}; border-radius:11px;"
                           "padding:3px 12px; font-weight:600;")
        self.setText(text)


class DataFrameModel(QAbstractTableModel):
    """Read-only Qt model for a pandas DataFrame (numbers right-aligned, formatted)."""

    def __init__(self, df: Optional[pd.DataFrame] = None, decimals: int = 3) -> None:
        super().__init__()
        self.df = df if df is not None else pd.DataFrame()
        self.decimals = decimals

    def set_frame(self, df: pd.DataFrame) -> None:
        self.beginResetModel()
        self.df = df.reset_index(drop=True)
        self.endResetModel()

    def rowCount(self, parent=QModelIndex()) -> int:
        return len(self.df)

    def columnCount(self, parent=QModelIndex()) -> int:
        return len(self.df.columns)

    def data(self, index, role=Qt.DisplayRole):
        if not index.isValid():
            return None
        value = self.df.iat[index.row(), index.column()]
        is_num = isinstance(value, (int, float, np.integer, np.floating)) and not isinstance(value, bool)
        if role == Qt.DisplayRole:
            if is_num:
                if isinstance(value, (float, np.floating)) and math.isnan(value):
                    return "—"
                if isinstance(value, (int, np.integer)):
                    return f"{value:,d}"
                return f"{value:,.{self.decimals}f}" if abs(value) < 1e6 else f"{value:.4e}"
            return str(value)
        if role == Qt.TextAlignmentRole and is_num:
            return int(Qt.AlignRight | Qt.AlignVCenter)
        return None

    def headerData(self, section, orientation, role=Qt.DisplayRole):
        if role != Qt.DisplayRole:
            return None
        if orientation == Qt.Horizontal:
            return str(self.df.columns[section])
        return str(section + 1)


class DataTable(QTableView):
    """Table view bound to a DataFrameModel."""

    def __init__(self, decimals: int = 3, stretch: bool = False, parent=None) -> None:
        super().__init__(parent)
        self.model_ = DataFrameModel(decimals=decimals)
        self.setModel(self.model_)
        self.setAlternatingRowColors(True)
        self.verticalHeader().setVisible(False)
        self.horizontalHeader().setSectionResizeMode(
            QHeaderView.Stretch if stretch else QHeaderView.ResizeToContents)
        self.horizontalHeader().setStretchLastSection(True)
        self.setSelectionBehavior(QTableView.SelectRows)

    def set_frame(self, df: pd.DataFrame) -> None:
        self.model_.set_frame(df)


# ---------------------------------------------------------------------------
# Inputs bound to the case configuration
# ---------------------------------------------------------------------------
def unit_label(tag: str) -> str:
    return UNIT_TAG_LABELS.get(tag, tag)


def _spin(value: float, minimum: float, maximum: float, step: float, decimals: int,
          tooltip: str) -> QDoubleSpinBox:
    box = QDoubleSpinBox()
    box.setDecimals(decimals)
    box.setRange(minimum, maximum)
    box.setSingleStep(step)
    box.setValue(value)
    box.setKeyboardTracking(False)          # update after typing finishes
    box.setMinimumWidth(110)
    if tooltip:
        box.setToolTip(tooltip)
    return box


def quantity_spin(state, section: Dict[str, Any], base: str, kind: str, label: str,
                  default_unit: str, default: float = 0.0, minimum: float = 0.0,
                  maximum: float = 1e9, step: float = 1.0, decimals: int = 2,
                  tooltip: str = "", on_change: Optional[Callable] = None):
    """
    Spin box editing ``section[f"{base}_{unit}"]`` in place (unit kept as in the file).

    Returns (label text with unit, spin box).
    """
    unit = find_unit_key(section, base, kind) or default_unit
    key = f"{base}_{unit}"
    section.setdefault(key, default)
    box = _spin(float(section[key]), minimum, maximum, step, decimals, tooltip)

    def changed(v: float) -> None:
        section[key] = float(v)
        state.touch()
        if on_change:
            on_change(v)
    box.valueChanged.connect(changed)
    return f"{label} [{unit_label(unit)}]", box


def plain_spin(state, section: Dict[str, Any], key: str, default: float = 0.0,
               minimum: float = 0.0, maximum: float = 1e9, step: float = 1.0,
               decimals: int = 3, tooltip: str = "", integer: bool = False) -> QDoubleSpinBox:
    """Spin box for a dimensionless config value."""
    section.setdefault(key, default)
    box = _spin(float(section[key]), minimum, maximum, step, 0 if integer else decimals, tooltip)

    def changed(v: float) -> None:
        section[key] = int(v) if integer else float(v)
        state.touch()
    box.valueChanged.connect(changed)
    return box


def combo_input(state, section: Dict[str, Any], key: str, options: Dict[str, str],
                tooltip: str = "", on_change: Optional[Callable] = None) -> QComboBox:
    """Combo box; ``options`` maps config value → display text."""
    combo = QComboBox()
    for value, text in options.items():
        combo.addItem(text, value)
    current = section.get(key, next(iter(options)))
    idx = combo.findData(current)
    combo.setCurrentIndex(max(idx, 0))
    section[key] = combo.currentData()
    if tooltip:
        combo.setToolTip(tooltip)

    def changed(_i: int) -> None:
        section[key] = combo.currentData()
        state.touch()
        if on_change:
            on_change(combo.currentData())
    combo.currentIndexChanged.connect(changed)
    return combo


def check_input(state, section: Dict[str, Any], key: str, text: str,
                default: bool = False) -> QCheckBox:
    box = QCheckBox(text)
    box.setChecked(bool(section.get(key, default)))

    def changed(v: bool) -> None:
        section[key] = bool(v)
        state.touch()
    box.toggled.connect(changed)
    return box


# ---------------------------------------------------------------------------
# Background work
# ---------------------------------------------------------------------------
class _Job(QObject):
    progress = Signal(float)
    finished = Signal(object)
    failed = Signal(str)

    def __init__(self, fn: Callable, *args) -> None:
        super().__init__()
        self.fn, self.args = fn, args

    def run(self) -> None:
        try:
            self.finished.emit(self.fn(self.progress.emit, *self.args))
        except Exception as exc:                       # surfaced in the UI
            self.failed.emit(f"{type(exc).__name__}: {exc}")


class Worker(QObject):
    """
    Run ``fn(report_progress, *args)`` in a QThread.

    Signals: progress(float 0–1), finished(result), failed(message).
    """

    progress = Signal(float)
    finished = Signal(object)
    failed = Signal(str)

    def __init__(self, fn: Callable, *args, parent=None) -> None:
        super().__init__(parent)
        self.thread = QThread()
        self.job = _Job(fn, *args)
        self.job.moveToThread(self.thread)
        self.thread.started.connect(self.job.run)
        self.job.progress.connect(self.progress)
        self.job.finished.connect(self._done)
        self.job.failed.connect(self._fail)

    def start(self) -> None:
        self.thread.start()

    def _done(self, result) -> None:
        self.thread.quit()
        self.thread.wait()
        self.finished.emit(result)

    def _fail(self, message: str) -> None:
        self.thread.quit()
        self.thread.wait()
        self.failed.emit(message)
