"""
Build the SYNTHETIC demonstration reference dataset by INDEPENDENT hand calculation.

The reference values are computed here with the classical FIELD-UNIT
Bingham-plastic equations of Bourgoyne, Millheim, Chenevert & Young (1986),
"Applied Drilling Engineering", SPE Textbook Series Vol. 2, Ch. 4 —
deliberately NOT with the simulator code — for the vertical well defined in
config/validation_demo_case.yaml:

    mean velocity       v̄ = q / (2.448 d²)                 [ft/s, gpm, in]
    pipe, turbulent     dp/dL = ρ^.75 v̄^1.75 μp^.25 / (1800 d^1.25)
    annulus, laminar    dp/dL = μp v̄ /(1000 (d2−d1)²) + τy /(200 (d2−d1))
    bit                 Δp = 8.311e-5 ρ q² / (Cd² At²)
    hydrostatic         p = 0.052 ρ D          (rounded constant, as in ADE)

Regime checks use the ADE apparent-viscosity Reynolds number (N_Re > 2100 →
turbulent) — a different criterion from the simulator's Hanks method.

Status: "Demonstration only — not experimental validation." Differences
between model and these values reflect correlation/approximation choices
(exact vs linearised laminar Bingham, 0.052 vs 0.051948, regime criterion),
which is exactly what a verification exercise should expose.

Run:  python examples/build_demo_reference.py
"""

from __future__ import annotations

import csv
import math
from pathlib import Path

OUT = Path(__file__).resolve().parents[1] / "data" / "validation" / "demo_reference_steady_state.csv"

# --- Case data (field units, identical to config/validation_demo_case.yaml) ---
MW, PV, YP = 10.0, 20.0, 15.0           # ppg, cP, lbf/100ft²
Q = 350.0                               # gpm
HOLE = 8.5                              # in
DP_OD, DP_ID, DP_L = 5.0, 4.276, 9500.0  # in, in, ft
DC_OD, DC_ID, DC_L = 6.5, 2.8125, 500.0  # in, in, ft
TVD = 10000.0                           # ft
NOZZLES = [12, 12, 12]                  # 32nds in
CD = 0.95
SBP = 100.0                             # psi


def pipe_reynolds_apparent(v, d):
    """ADE apparent viscosity for pipe: μa = μp + 6.66 τy d / v̄; N_Re = 928 ρ v̄ d / μa."""
    mu_a = PV + 6.66 * YP * d / v
    return 928.0 * MW * v * d / mu_a


def pipe_loss(d, length):
    v = Q / (2.448 * d ** 2)
    re = pipe_reynolds_apparent(v, d)
    if re < 2100:
        grad = PV * v / (1500 * d ** 2) + YP / (225 * d)
    else:
        grad = MW ** 0.75 * v ** 1.75 * PV ** 0.25 / (1800 * d ** 1.25)
    return grad * length, re


def annulus_loss(d1, length):
    v = Q / (2.448 * (HOLE ** 2 - d1 ** 2))
    dh = HOLE - d1
    mu_a = PV + 5.0 * YP * dh / v
    re = 757.0 * MW * v * dh / mu_a
    if re < 2100:
        grad = PV * v / (1000 * dh ** 2) + YP / (200 * dh)
    else:
        grad = MW ** 0.75 * v ** 1.75 * PV ** 0.25 / (1396 * dh ** 1.25)
    return grad * length, re


def main() -> None:
    dp_dp, re1 = pipe_loss(DP_ID, DP_L)
    dp_dc, re2 = pipe_loss(DC_ID, DC_L)
    ann_dp, re3 = annulus_loss(DP_OD, DP_L)
    ann_dc, re4 = annulus_loss(DC_OD, DC_L)
    at = sum(math.pi / 4 * (n / 32) ** 2 for n in NOZZLES)
    bit = 8.311e-5 * MW * Q ** 2 / (CD ** 2 * at ** 2)
    hydro = 0.052 * MW * TVD
    ann = ann_dp + ann_dc
    bhp = SBP + hydro + ann
    spp = SBP + dp_dp + dp_dc + bit + ann
    ecd = MW + ann / (0.052 * TVD)
    print(f"Re (apparent): DP {re1:.0f}, DC {re2:.0f}, ann-DP {re3:.0f}, ann-DC {re4:.0f}")
    rows = [
        ("drill_pipe_loss", dp_dp, "psi"), ("bha_loss", dp_dc, "psi"),
        ("bit_loss", bit, "psi"), ("annulus_loss", ann, "psi"),
        ("bhp", bhp, "psi"), ("spp", spp, "psi"), ("ecd_conventional", ecd, "ppg"),
    ]
    OUT.parent.mkdir(parents=True, exist_ok=True)
    with open(OUT, "w", newline="", encoding="utf-8") as fh:
        fh.write("# SYNTHETIC DEMONSTRATION REFERENCE — independent ADE field-unit hand calculation.\n")
        fh.write("# Demonstration only — not experimental validation. Case: config/validation_demo_case.yaml\n")
        w = csv.writer(fh)
        w.writerow(["case", "quantity", "reference_value", "unit", "data_type", "source"])
        for name, value, unit in rows:
            w.writerow(["vertical_well_hand_calc_demo", name, f"{value:.4f}", unit,
                        "synthetic_demonstration",
                        "Hand calc, Bourgoyne et al. (1986) ADE Ch.4 field equations"])
    print(f"Wrote {OUT}")
    for name, value, unit in rows:
        print(f"  {name:18s} {value:10.2f} {unit}")


if __name__ == "__main__":
    main()
