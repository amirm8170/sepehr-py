"""
Example: one-at-a-time sensitivity of BHP, SPP and ECD (±10 %).

Run:  python examples/run_sensitivity.py
"""

from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from mpd_sim.analysis.sensitivity import one_at_a_time  # noqa: E402
from mpd_sim.io.loaders import load_setup  # noqa: E402
from mpd_sim.logging_config import setup_logging  # noqa: E402
from mpd_sim.units import BAR_TO_PA, PPG_TO_KGM3  # noqa: E402


def main() -> None:
    setup_logging("WARNING")
    setup = load_setup(ROOT / "config" / "base_case.yaml")
    table = one_at_a_time(setup, relative_change=0.10)
    print(f"{'parameter':18s} {'ΔBHP −/+ [bar]':>20s} {'ΔSPP −/+ [bar]':>20s} {'ΔECD −/+ [ppg]':>20s}")
    for _, r in table.iterrows():
        print(f"{r.parameter:18s} "
              f"{r.bhp_low_change_pa / BAR_TO_PA:9.2f} {r.bhp_high_change_pa / BAR_TO_PA:9.2f} "
              f"{r.spp_low_change_pa / BAR_TO_PA:10.2f} {r.spp_high_change_pa / BAR_TO_PA:9.2f} "
              f"{r.ecd_low_change_kg_m3 / PPG_TO_KGM3:10.3f} {r.ecd_high_change_kg_m3 / PPG_TO_KGM3:9.3f}")
    print("\n(Use `python main.py --scenario base --sensitivity` for CSV + tornado plots.)")


if __name__ == "__main__":
    main()
