"""
Example: Stage A steady-state hydraulics, built directly in Python (no YAML).

Shows how to assemble the objects by hand, solve, and read the pressure
accounting. Synthetic demonstration well.

Run:  python examples/run_steady_state.py
"""

from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from mpd_sim.hydraulics.hydraulics import SteadyStateHydraulicsSolver  # noqa: E402
from mpd_sim.logging_config import setup_logging  # noqa: E402
from mpd_sim.models.mud import MudProperties  # noqa: E402
from mpd_sim.models.operations import OperatingConditions  # noqa: E402
from mpd_sim.models.trajectory import Trajectory  # noqa: E402
from mpd_sim.models.well import (BitNozzles, DrillStringComponent,  # noqa: E402
                                 HoleSection, WellGeometry)
from mpd_sim.units import (cp_to_pas, gpm_to_m3s, in_to_m, kgm3_to_ppg,  # noqa: E402
                           lbf100ft2_to_pa, nozzle_32nds_to_m, pa_to_psi, ppg_to_kgm3,
                           psi_to_pa)
from mpd_sim.visualization.plots import plot_pressure_profile  # noqa: E402


def main() -> None:
    setup_logging("INFO")
    # 1) Trajectory: vertical to 1000 m, then 30° tangent to 3000 m MD
    trajectory = Trajectory.from_stations(md=[0, 1000, 1300, 3000],
                                          inclination=[0, 0, 30, 30],
                                          azimuth=[0, 0, 90, 90])
    # 2) Geometry (SI) — conversions are explicit
    well = WellGeometry(
        trajectory=trajectory,
        hole_sections=[HoleSection("casing", 0, 1500, in_to_m(8.681), "cased"),
                       HoleSection("open_hole", 1500, 3000, in_to_m(8.5), "open_hole")],
        drill_string=[DrillStringComponent("dp", 2850, in_to_m(5.0), in_to_m(4.276), "drill_pipe"),
                      DrillStringComponent("bha", 150, in_to_m(6.5), in_to_m(2.8125), "bha")],
        bit=BitNozzles([nozzle_32nds_to_m(13)] * 4, discharge_coefficient=0.95))
    mud = MudProperties(density=ppg_to_kgm3(10.0), plastic_viscosity=cp_to_pas(20),
                        yield_point=lbf100ft2_to_pa(15))
    solver = SteadyStateHydraulicsSolver(well, mud, segment_length=30.0)

    # 3) Solve at 500 gpm with 150 psi surface back pressure
    cond = OperatingConditions(pump_rate=gpm_to_m3s(500), surface_back_pressure=psi_to_pa(150))
    res = solver.solve(cond)

    print("\nPressure accounting (psi):")
    for _, row in res.pressure_breakdown().iterrows():
        print(f"  {row.component:28s} {pa_to_psi(row.pressure_pa):9.1f}")
    print(f"\nBHP              {pa_to_psi(res.bhp):9.1f} psi")
    print(f"Static BHP       {pa_to_psi(res.bhp_static):9.1f} psi")
    print(f"ECD conventional {kgm3_to_ppg(res.ecd_conventional):9.3f} ppg")
    print(f"EMW of BHP       {kgm3_to_ppg(res.emw_bhp):9.3f} ppg")

    out = ROOT / "outputs" / "examples"
    out.mkdir(parents=True, exist_ok=True)
    res.segment_table().to_csv(out / "example_segments.csv", index=False)
    plot_pressure_profile(res, out / "example_pressure_profile.png")
    print(f"\nWrote {out}")


if __name__ == "__main__":
    main()
