"""
Example: closed-loop PID BHP control (scenario 10) and comparison with open loop.

Runs the 'pid_control' scenario twice — controller ON and OFF — and prints
the control-performance metrics side by side.

Run:  python examples/run_pid_control.py
"""

from __future__ import annotations

import copy
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from mpd_sim.io.loaders import load_yaml  # noqa: E402
from mpd_sim.logging_config import setup_logging  # noqa: E402
from mpd_sim.scenarios.runner import (load_scenario_catalog,  # noqa: E402
                                      run_dynamic_scenario)

KEYS = ("min_bhp_pa", "max_bhp_pa", "max_overshoot_pa", "max_undershoot_pa",
        "time_outside_window_s", "steady_state_error_pa", "iae_pa_s")


def main() -> None:
    setup_logging("WARNING")
    base = load_yaml(ROOT / "config" / "base_case.yaml")
    scen = load_scenario_catalog(ROOT / "config" / "scenarios.yaml")["scenarios"]["pid_control"]
    out = ROOT / "outputs" / "examples"
    closed = run_dynamic_scenario(base, "pid_closed_loop", scen, out, ROOT)
    open_scen = copy.deepcopy(scen)
    open_scen["controller"] = {"enabled": False}
    opened = run_dynamic_scenario(base, "pid_open_loop", open_scen, out, ROOT)
    print(f"{'metric':26s} {'closed loop':>14s} {'open loop':>14s}")
    for k in KEYS:
        scale = 1e5 if k.endswith("_pa") else (1e5 if k.endswith("pa_s") else 1.0)
        unit = "bar" if k.endswith("_pa") else ("bar·s" if k.endswith("pa_s") else "s")
        print(f"{k:26s} {closed.metrics[k] / scale:12.2f} {unit:5s}"
              f"{opened.metrics[k] / scale:12.2f} {unit}")
    print(f"\nPlots and CSVs in {out}")


if __name__ == "__main__":
    main()
