"""
Example: the validation workflow with the SYNTHETIC demonstration dataset.

1. (Re)builds the hand-calculation reference with examples/build_demo_reference.py
2. Solves config/validation_demo_case.yaml with the simulator
3. Prints absolute / relative / percentage errors

"Demonstration only — not experimental validation."
To validate for real, replace the CSV with field/laboratory/literature data
(set data_type accordingly) and the YAML with the matching case.

Run:  python examples/run_validation_demo.py
"""

from __future__ import annotations

import runpy
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from mpd_sim.io.loaders import load_reference_csv, load_setup  # noqa: E402
from mpd_sim.logging_config import setup_logging  # noqa: E402
from mpd_sim.validation.validation import (DEMO_DISCLAIMER, summarize,  # noqa: E402
                                           validate_steady_state)


def main() -> None:
    setup_logging("WARNING")
    runpy.run_path(str(ROOT / "examples" / "build_demo_reference.py"), run_name="__main__")
    setup = load_setup(ROOT / "config" / "validation_demo_case.yaml")
    result = setup.solver.solve(setup.conditions)
    ref = load_reference_csv(ROOT / "data" / "validation" / "demo_reference_steady_state.csv")
    table = validate_steady_state(result, ref)
    print("\n" + DEMO_DISCLAIMER)
    print(table[["quantity", "unit", "reference_value", "model_value", "absolute_error",
                 "percentage_error"]].to_string(index=False, float_format="%.3f"))
    print("\n" + summarize(table).to_string(index=False, float_format="%.3f"))


if __name__ == "__main__":
    main()
