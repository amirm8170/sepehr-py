"""Validation error definitions."""

import numpy as np
import pytest

from mpd_sim.validation.validation import (ValidationPoint, absolute_error,
                                           compare_profiles, compare_time_series,
                                           percentage_error, relative_error, validation_table)


def test_error_definitions():
    assert absolute_error(105.0, 100.0) == pytest.approx(5.0)
    assert relative_error(95.0, 100.0) == pytest.approx(0.05)
    assert percentage_error(110.0, 100.0) == pytest.approx(10.0)
    with pytest.raises(ValueError):
        relative_error(1.0, 0.0)


def test_point_requires_provenance():
    with pytest.raises(ValueError):
        ValidationPoint("bhp", 100, 101, "bar", "made_up", "x")


def test_synthetic_data_gets_disclaimer():
    table = validation_table([ValidationPoint("bhp", 100, 102, "bar",
                                              "synthetic_demonstration", "demo")])
    assert "not experimental validation" in table["disclaimer"].iloc[0]
    assert table["percentage_error"].iloc[0] == pytest.approx(2.0)


def test_profile_and_time_series_comparison():
    depth = np.linspace(0, 1000, 11)
    prof = compare_profiles(depth, 2 * depth, np.array([500.0]), np.array([1000.0]))
    assert prof["percentage_error"].iloc[0] == pytest.approx(0.0)
    t = np.linspace(0, 10, 101)
    stats = compare_time_series(t, t + 1.0, t, t + 2.0)
    assert stats["rmse"] == pytest.approx(1.0)
