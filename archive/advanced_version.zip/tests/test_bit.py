"""Bit hydraulics vs the ADE field-unit equation."""

import pytest

from mpd_sim.hydraulics.bit import (bit_pressure_drop, jet_impact_force, nozzle_velocity,
                                    total_flow_area)
from mpd_sim.units import gpm_to_m3s, nozzle_32nds_to_m, pa_to_psi, ppg_to_kgm3


def test_tfa_three_12s():
    # 3 × 12/32": TFA = 3 π/4 (0.375)² = 0.3313 in²
    tfa = total_flow_area([nozzle_32nds_to_m(12)] * 3)
    assert tfa / 0.0254 ** 2 == pytest.approx(0.33134, rel=1e-4)


def test_bit_pressure_drop_matches_ade_field_formula():
    # ADE: Δp [psi] = 8.311e-5 ρ[ppg] q[gpm]² / (Cd² A[in²]²)
    tfa = total_flow_area([nozzle_32nds_to_m(12)] * 3)
    a_in2 = tfa / 0.0254 ** 2
    expected = 8.311e-5 * 10.0 * 350.0 ** 2 / (0.95 ** 2 * a_in2 ** 2)
    model = bit_pressure_drop(ppg_to_kgm3(10.0), gpm_to_m3s(350.0), tfa, 0.95)
    assert pa_to_psi(model) == pytest.approx(expected, rel=1e-3)


def test_nozzle_velocity_field_formula():
    # v_n [ft/s] = 0.3208 q / A[in²]
    tfa = total_flow_area([nozzle_32nds_to_m(12)] * 3)
    v = nozzle_velocity(gpm_to_m3s(350.0), tfa)
    assert v / 0.3048 == pytest.approx(0.3208 * 350.0 / (tfa / 0.0254 ** 2), rel=1e-3)


def test_discharge_coefficient_effect_and_validation():
    tfa = 3e-4
    dp1 = bit_pressure_drop(1200.0, 0.03, tfa, 1.0)
    dp2 = bit_pressure_drop(1200.0, 0.03, tfa, 0.5)
    assert dp2 == pytest.approx(4 * dp1)
    with pytest.raises(ValueError):
        bit_pressure_drop(1200.0, 0.03, tfa, 0.0)


def test_impact_force_equals_ade_formula():
    # F [lbf] = 0.01823 Cd q sqrt(ρ Δp)  with Δp from Cd = 0.95
    tfa = total_flow_area([nozzle_32nds_to_m(12)] * 3)
    rho, q = ppg_to_kgm3(10.0), gpm_to_m3s(350.0)
    dp_psi = pa_to_psi(bit_pressure_drop(rho, q, tfa, 0.95))
    ade = 0.01823 * 0.95 * 350.0 * (10.0 * dp_psi) ** 0.5
    assert jet_impact_force(rho, q, tfa) / 4.4482216 == pytest.approx(ade, rel=0.01)
