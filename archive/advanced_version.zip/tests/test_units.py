"""Unit conversions checked against NIST SP 811 values (independent constants)."""

import pytest

from mpd_sim import units as u


@pytest.mark.parametrize("func, value, expected, rel", [
    (u.ft_to_m, 1.0, 0.3048, 1e-12),
    (u.in_to_m, 1.0, 0.0254, 1e-12),
    (u.mm_to_m, 1000.0, 1.0, 1e-12),
    (u.psi_to_pa, 1.0, 6894.757, 1e-6),
    (u.gpm_to_m3s, 1.0, 6.309020e-5, 1e-6),
    (u.ppg_to_kgm3, 1.0, 119.8264, 1e-6),
    (u.cp_to_pas, 1.0, 1.0e-3, 1e-12),
    (u.lbf100ft2_to_pa, 1.0, 0.4788026, 1e-6),
    (u.bar_to_pa, 1.0, 1.0e5, 1e-12),
])
def test_conversion_factors(func, value, expected, rel):
    assert func(value) == pytest.approx(expected, rel=rel)


@pytest.mark.parametrize("fwd, back", [
    (u.ft_to_m, u.m_to_ft), (u.in_to_m, u.m_to_in), (u.psi_to_pa, u.pa_to_psi),
    (u.gpm_to_m3s, u.m3s_to_gpm), (u.ppg_to_kgm3, u.kgm3_to_ppg),
    (u.cp_to_pas, u.pas_to_cp), (u.lbf100ft2_to_pa, u.pa_to_lbf100ft2)])
def test_round_trip(fwd, back):
    assert back(fwd(123.456)) == pytest.approx(123.456, rel=1e-12)


def test_field_hydrostatic_constant_is_rounded_0052():
    # Exact constant 0.051948 psi/(ft·ppg); the oilfield 0.052 is a rounding.
    assert u.FIELD_HYDROSTATIC_CONSTANT_EXACT == pytest.approx(0.051948, rel=1e-4)


def test_field_hydrostatic_matches_si():
    # 10 ppg × 10 000 ft: 0.052 rule gives 5200 psi; SI ρgh must agree within 0.2 %.
    si = u.ppg_to_kgm3(10.0) * 9.80665 * u.ft_to_m(10000.0)
    assert u.pa_to_psi(si) == pytest.approx(5200.0, rel=2e-3)
    assert u.pa_to_psi(si) == pytest.approx(u.field_hydrostatic_psi(10, 10000, rounded=False),
                                            rel=1e-9)


def test_to_si_rejects_unknown_unit():
    with pytest.raises(u.UnitError):
        u.to_si(1.0, "furlong", "length")


def test_nozzle_32nds():
    assert u.nozzle_32nds_to_m(16) == pytest.approx(0.0127)   # 16/32" = 0.5"
