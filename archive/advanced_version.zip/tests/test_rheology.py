"""Bingham plastic rheology and the strategy interface."""

import pytest

from mpd_sim.hydraulics.rheology import (BinghamPlastic, HerschelBulkley, PowerLaw,
                                         build_rheology)
from mpd_sim.units import LBF100FT2_TO_PA


def test_fann_interpretation():
    b = BinghamPlastic.from_fann(theta_600=60, theta_300=40)
    assert b.plastic_viscosity == pytest.approx(0.020)          # 20 cP
    assert b.yield_stress == pytest.approx(20 * LBF100FT2_TO_PA)  # 20 lbf/100 ft²


def test_bingham_reproduces_dial_readings():
    # The Bingham line through the 300/600 rpm points must reproduce the measured
    # stresses there (dial reading × 1.0678 lbf/100 ft² per degree). The API
    # PV/YP convention ignores the 1.0678 factor, so agreement is only ±5 %.
    th600, th300 = 60.0, 40.0
    b = BinghamPlastic.from_fann(th600, th300)
    for theta, rate in ((th600, 1022.0), (th300, 511.0)):
        measured = theta * 1.0678 * LBF100FT2_TO_PA
        assert b.shear_stress(rate) == pytest.approx(measured, rel=0.05)


def test_bingham_linear_and_yield():
    b = BinghamPlastic(plastic_viscosity=0.02, yield_stress=5.0)
    assert b.shear_stress(0.0) == pytest.approx(5.0)
    assert b.shear_stress(200.0) - b.shear_stress(100.0) == pytest.approx(2.0)
    assert b.apparent_viscosity(100.0) == pytest.approx(0.07)


def test_herschel_bulkley_reduces_to_bingham():
    hb = HerschelBulkley(yield_stress=5.0, consistency_index=0.02, flow_behavior_index=1.0)
    b = BinghamPlastic(0.02, 5.0)
    assert hb.shear_stress(300.0) == pytest.approx(b.shear_stress(300.0))


def test_power_law():
    pl = PowerLaw(consistency_index=0.5, flow_behavior_index=0.5)
    assert pl.shear_stress(100.0) == pytest.approx(5.0)


def test_invalid_inputs():
    with pytest.raises(ValueError):
        BinghamPlastic(-0.01, 1.0)
    with pytest.raises(ValueError):
        build_rheology("casson")
