"""Desktop GUI smoke tests (headless Qt). Skipped if PySide6 is not installed."""

import os
import time

import pytest

pytest.importorskip("PySide6")
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from gui.app import unhide_qt_plugins  # noqa: E402

unhide_qt_plugins()
from PySide6.QtWidgets import QApplication  # noqa: E402


@pytest.fixture(scope="module")
def window():
    app = QApplication.instance() or QApplication([])
    from gui.theme import apply_matplotlib_style
    apply_matplotlib_style()
    from gui.main_window import MainWindow
    w = MainWindow()
    w.show()
    app.processEvents()
    yield w, app
    w.close()


def _wait(app, predicate, timeout=180):
    start = time.time()
    while not predicate() and time.time() - start < timeout:
        app.processEvents()
        time.sleep(0.05)
    assert predicate(), "timed out"


def test_all_pages_open(window):
    w, app = window
    for row in range(w.nav.count()):
        w.nav.setCurrentRow(row)
        app.processEvents()
    assert w.stack.currentIndex() == w.nav.count() - 1


def test_dashboard_shows_results(window):
    w, _ = window
    dash = w.pages[0]
    assert dash.result is not None
    assert "psi" in dash.cards["bhp"].value.text()


def test_dynamic_run(window):
    w, app = window
    page = w.pages[1]
    page.combo.setCurrentIndex(page.combo.findData("pump_rate_increase"))
    page.run()
    _wait(app, page.run_btn.isEnabled)
    assert page.view.result is not None
    assert "Finished" in page.banner.text()


def test_pid_run(window):
    w, app = window
    page = w.pages[2]
    page.compare.setChecked(False)
    page.run()
    _wait(app, page.run_btn.isEnabled)
    assert page.data is not None
    assert page.data[0][0].metrics["maintained_within_window"]


def test_input_change_recomputes(window):
    w, app = window
    before = w.pages[0].result.bhp
    w.state.config["operations"]["back_pressure_mode"] = "specified"
    w.state.config["operations"]["surface_back_pressure_psi"] = 300.0
    w.state.config_edited.emit()
    app.processEvents()
    assert w.pages[0].result.bhp != before
    from gui.state import BASE_CASE
    w.state.load_case(BASE_CASE, "Base case")
    app.processEvents()


def test_units_switch(window):
    w, app = window
    w.state.set_units("Metric (bar, kg/m³, L/min, m)")
    app.processEvents()
    assert "bar" in w.pages[0].cards["bhp"].value.text()
