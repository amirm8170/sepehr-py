"""PID controller on simple plants with known analytic behaviour."""

import numpy as np
import pytest

from mpd_sim.dynamics.pid import PIDController


def simulate_first_order(pid, gain=1.0, tau=5.0, setpoint=1.0, t_end=200.0, dt=0.05):
    """Plant: tau dy/dt = −y + gain·u (forward Euler)."""
    y, ys, us = 0.0, [], []
    for _ in np.arange(0, t_end, dt):
        u = pid.update(setpoint, y, dt)
        y += dt / tau * (-y + gain * u)
        ys.append(y)
        us.append(u)
    return np.array(ys), np.array(us)


def test_p_only_steady_state_offset():
    # Classical result: P control of a type-0 plant leaves e_ss = 1 / (1 + Kp·K)
    pid = PIDController(kp=4.0)
    y, _ = simulate_first_order(pid)
    assert 1.0 - y[-1] == pytest.approx(1.0 / (1.0 + 4.0), rel=1e-3)


def test_pi_removes_offset():
    y, _ = simulate_first_order(PIDController(kp=2.0, ki=0.5))
    assert y[-1] == pytest.approx(1.0, abs=1e-4)


def test_output_saturation():
    _, u = simulate_first_order(PIDController(kp=50.0, ki=5.0, output_min=0.0, output_max=1.5))
    assert u.max() <= 1.5 + 1e-12 and u.min() >= 0.0


def test_rate_limit():
    pid = PIDController(kp=100.0, output_min=-10, output_max=10, rate_limit=0.5)
    outputs = [pid.update(1.0, 0.0, 0.1) for _ in range(10)]
    assert np.all(np.abs(np.diff(np.concatenate([[0.0], outputs]))) <= 0.05 + 1e-12)


def test_anti_windup_reduces_overshoot():
    kwargs = dict(kp=1.0, ki=1.0, output_min=0.0, output_max=1.2)
    y_none, _ = simulate_first_order(PIDController(anti_windup="none", **kwargs))
    y_clamp, _ = simulate_first_order(PIDController(anti_windup="clamping", **kwargs))
    y_back, _ = simulate_first_order(PIDController(anti_windup="back_calculation", **kwargs))
    assert y_clamp.max() < y_none.max()
    assert y_back.max() < y_none.max()


def test_reverse_acting_sign():
    pid = PIDController(kp=1.0, reverse_acting=True, bias=0.5)
    # Measurement below setpoint → reverse acting output DECREASES (e.g. close choke)
    assert pid.update(10.0, 9.0, 0.1) < 0.5


def test_derivative_on_measurement_has_no_setpoint_kick():
    pid = PIDController(kp=0.0, kd=1.0, derivative_on="measurement")
    pid.update(0.0, 0.0, 0.1)
    assert pid.update(5.0, 0.0, 0.1) == pytest.approx(0.0)
    pid_e = PIDController(kp=0.0, kd=1.0, derivative_on="error")
    pid_e.update(0.0, 0.0, 0.1)
    assert abs(pid_e.update(5.0, 0.0, 0.1)) > 1.0


def test_reset_and_set_limits():
    pid = PIDController(kp=1.0, ki=1.0)
    for _ in range(10):
        pid.update(1.0, 0.0, 0.1)
    assert pid.integral > 0
    pid.reset(bias=0.3)
    assert pid.integral == 0.0 and pid.bias == 0.3
    pid.set_limits(0.0, 0.5)
    assert pid.update(100.0, 0.0, 0.1) <= 0.5
    with pytest.raises(ValueError):
        pid.set_limits(1.0, 0.0)
