"""Shared fixtures: small, hand-checkable well cases (SI units)."""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from mpd_sim.dynamics.choke import LinearCharacteristic, SimpleCvChoke  # noqa: E402
from mpd_sim.hydraulics.hydraulics import SteadyStateHydraulicsSolver  # noqa: E402
from mpd_sim.models.mud import MudProperties  # noqa: E402
from mpd_sim.models.trajectory import Trajectory  # noqa: E402
from mpd_sim.models.well import (BitNozzles, DrillStringComponent,  # noqa: E402
                                 HoleSection, WellGeometry)
from mpd_sim.units import (cp_to_pas, ft_to_m, in_to_m, lbf100ft2_to_pa,  # noqa: E402
                           nozzle_32nds_to_m, ppg_to_kgm3)


@pytest.fixture
def vertical_well() -> WellGeometry:
    """10 000 ft vertical well, 8.5" hole, 5" DP + 6.5" collars, bit on bottom."""
    td = ft_to_m(10000.0)
    return WellGeometry(
        trajectory=Trajectory.vertical(td),
        hole_sections=[HoleSection("oh", 0.0, td, in_to_m(8.5), "open_hole")],
        drill_string=[
            DrillStringComponent("dp", ft_to_m(9500.0), in_to_m(5.0), in_to_m(4.276), "drill_pipe"),
            DrillStringComponent("dc", ft_to_m(500.0), in_to_m(6.5), in_to_m(2.8125), "bha")],
        bit=BitNozzles([nozzle_32nds_to_m(12)] * 3, 0.95))


@pytest.fixture
def mud() -> MudProperties:
    """10 ppg, PV 20 cP, YP 15 lbf/100 ft²."""
    return MudProperties(density=ppg_to_kgm3(10.0), plastic_viscosity=cp_to_pas(20.0),
                         yield_point=lbf100ft2_to_pa(15.0),
                         gel_10s=lbf100ft2_to_pa(5.0), gel_10min=lbf100ft2_to_pa(10.0))


@pytest.fixture
def choke() -> SimpleCvChoke:
    return SimpleCvChoke(LinearCharacteristic(cv_max=100.0, cv_leak=1.0), 0.02, 1.0)


@pytest.fixture
def solver(vertical_well, mud, choke) -> SteadyStateHydraulicsSolver:
    return SteadyStateHydraulicsSolver(vertical_well, mud, segment_length=30.0, choke=choke)
