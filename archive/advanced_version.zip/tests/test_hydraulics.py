"""Steady-state solver: pressure accounting, BHP, SPP, ECD, profile, segments."""

import numpy as np
import pytest

from mpd_sim.constants import GRAVITY
from mpd_sim.models.operations import OperatingConditions, PressureWindow
from mpd_sim.models.segment import build_md_grid
from mpd_sim.units import ft_to_m, gpm_to_m3s, psi_to_pa


def test_discretization_respects_breakpoints(solver):
    g = solver.grid
    assert np.all(g.length <= 30.0 + 1e-9)
    assert np.isclose(g.md_bottom[-1], ft_to_m(10000.0))
    # Component boundary at 9500 ft must be a node
    assert np.any(np.isclose(g.md_top, ft_to_m(9500.0)))
    assert set(g.string_category) == {"drill_pipe", "bha"}


def test_md_grid_simple():
    nodes = build_md_grid(np.array([0.0, 100.0]), 100.0, 30.0)
    assert len(nodes) == 5 and nodes[-1] == 100.0


def test_static_bhp_is_rho_g_h(solver, mud):
    res = solver.solve(OperatingConditions(pump_rate=0.0))
    assert res.bhp == pytest.approx(mud.density * GRAVITY * ft_to_m(10000.0))
    assert res.losses.total == 0.0
    assert res.spp == pytest.approx(0.0)


def test_sbp_adds_one_to_one(solver):
    q = gpm_to_m3s(350)
    r0 = solver.solve(OperatingConditions(pump_rate=q))
    r1 = solver.solve(OperatingConditions(pump_rate=q, surface_back_pressure=psi_to_pa(200)))
    assert r1.bhp - r0.bhp == pytest.approx(psi_to_pa(200))
    assert r1.spp - r0.spp == pytest.approx(psi_to_pa(200))


def test_spp_equals_sum_of_losses(solver):
    sbp = psi_to_pa(100)
    r = solver.solve(OperatingConditions(pump_rate=gpm_to_m3s(400), surface_back_pressure=sbp))
    L = r.losses
    assert r.spp == pytest.approx(sbp + L.drill_pipe + L.bha + L.bit + L.annulus)


def test_u_tube_consistency_at_bit(solver):
    # Pressure at the bit from inside the string minus the bit drop equals the annulus pressure.
    r = solver.solve(OperatingConditions(pump_rate=gpm_to_m3s(400)))
    p_string_bit = r.string_profile["pressure_pa"].iloc[-1]
    p_annulus_bit = r.annulus_profile["pressure_pa"].iloc[-1]
    assert p_string_bit - r.losses.bit == pytest.approx(p_annulus_bit, rel=1e-9)


def test_ecd_definitions(solver, mud):
    r = solver.solve(OperatingConditions(pump_rate=gpm_to_m3s(400),
                                         surface_back_pressure=psi_to_pa(150)))
    tvd = ft_to_m(10000.0)
    assert r.ecd_conventional > mud.density
    assert r.ecd_conventional == pytest.approx(mud.density + r.losses.annulus / (GRAVITY * tvd))
    assert r.emw_bhp == pytest.approx(r.bhp / (GRAVITY * tvd))
    assert r.emw_bhp > r.ecd_conventional          # includes SBP


def test_bhp_increases_with_flow(solver):
    bhps = [solver.solve(OperatingConditions(pump_rate=gpm_to_m3s(q))).bhp
            for q in (100, 200, 300, 400, 500)]
    assert np.all(np.diff(bhps) > 0)


def test_profile_contents(solver):
    r = solver.solve(OperatingConditions(pump_rate=gpm_to_m3s(400)))
    prof = r.annulus_profile
    for col in ("md_m", "tvd_m", "pressure_pa", "hydrostatic_contribution_pa",
                "friction_contribution_pa", "section", "velocity_m_s", "flow_regime"):
        assert col in prof.columns
    assert np.all(np.diff(prof["pressure_pa"]) > 0)
    rebuilt = (prof["surface_contribution_pa"] + prof["hydrostatic_contribution_pa"]
               + prof["friction_contribution_pa"])
    assert np.allclose(rebuilt, prof["pressure_pa"])


def test_segment_objects_complete(solver):
    r = solver.solve(OperatingConditions(pump_rate=gpm_to_m3s(400)))
    seg = r.segments[0]
    assert seg.segment.length > 0 and seg.friction_factor > 0 and seg.reynolds > 0
    table = r.segment_table()
    assert len(table) == 2 * solver.grid.n_segments
    assert table["friction_loss_pa"].sum() == pytest.approx(r.losses.drill_string + r.losses.annulus)


def test_hydrostatic_uses_tvd_not_md(mud, choke):
    # Same MD, deviated vs vertical: hydrostatic follows TVD, friction follows MD.
    from mpd_sim.hydraulics.hydraulics import SteadyStateHydraulicsSolver
    from mpd_sim.models.trajectory import Trajectory
    from mpd_sim.models.well import BitNozzles, DrillStringComponent, HoleSection, WellGeometry

    def make(inc):
        traj = Trajectory.from_stations([0, 100, 2000], [0, inc, inc], [0, 0, 0])
        return WellGeometry(traj, [HoleSection("oh", 0, 2000, 0.2159)],
                            [DrillStringComponent("dp", 2000, 0.127, 0.1086)],
                            BitNozzles([0.01] * 3))
    q = OperatingConditions(pump_rate=0.03)
    vert = SteadyStateHydraulicsSolver(make(0.0), mud).solve(q)
    dev = SteadyStateHydraulicsSolver(make(60.0), mud).solve(q)
    assert dev.losses.annulus == pytest.approx(vert.losses.annulus)
    assert dev.hydrostatic_td < vert.hydrostatic_td
    assert dev.hydrostatic_td == pytest.approx(
        mud.density * GRAVITY * dev.td_tvd)


def test_choke_mode_back_pressure(solver):
    c = OperatingConditions(pump_rate=gpm_to_m3s(400), back_pressure_mode="choke",
                            choke_opening=0.3)
    r = solver.solve(c)
    assert r.surface_back_pressure == pytest.approx(
        solver.choke.pressure_drop(0.3, gpm_to_m3s(400), solver.mud.density))
    closer = solver.solve(c.with_changes(choke_opening=0.2))
    assert closer.bhp > r.bhp


def test_surge_raises_and_swab_lowers_bhp(solver):
    base = OperatingConditions(pump_rate=gpm_to_m3s(300))
    b0 = solver.solve(base).bhp
    assert solver.solve(base.with_changes(pipe_velocity=0.5)).bhp > b0
    assert solver.solve(base.with_changes(pipe_velocity=-0.5)).bhp < b0


def test_window_classification(solver):
    tvd = ft_to_m(10000.0)
    rho_g = GRAVITY * tvd
    window = PressureWindow(pore_pressure=1100 * rho_g, fracture_pressure=1400 * rho_g,
                            target_bhp=1250 * rho_g, reference_tvd=tvd)
    assert solver.solve(OperatingConditions(pump_rate=0.0), window).window_status == "safe"


def test_invalid_operating_inputs():
    with pytest.raises(ValueError):
        OperatingConditions(pump_rate=-0.01)
    with pytest.raises(ValueError):
        OperatingConditions(pump_rate=0.01, choke_opening=1.5)
