"""End-to-end: configuration → steady state → scenarios → files."""

import json
from pathlib import Path

import pytest

from mpd_sim.io.loaders import ConfigError, load_setup, read_quantity
from mpd_sim.scenarios.runner import run_named
from mpd_sim.units import kgm3_to_ppg

ROOT = Path(__file__).resolve().parents[1]
CONFIG = ROOT / "config" / "base_case.yaml"
SCENARIOS = ROOT / "config" / "scenarios.yaml"


def test_read_quantity_units():
    assert read_quantity({"x_ft": 10}, "x", "length") == pytest.approx(3.048)
    with pytest.raises(ConfigError):
        read_quantity({"x_ft": 10, "x_m": 3}, "x", "length")
    with pytest.raises(ConfigError):
        read_quantity({}, "x", "length")


def test_base_case_auto_choke_hits_target():
    setup = load_setup(CONFIG)
    res = setup.solver.solve(setup.conditions, setup.window)
    assert res.bhp == pytest.approx(setup.window.target_bhp, rel=1e-4)
    assert res.window_status == "safe"
    assert 10.0 < kgm3_to_ppg(res.ecd_conventional) < 11.0


def test_steady_state_outputs(tmp_path):
    run_named("base", CONFIG, SCENARIOS, tmp_path)
    out = tmp_path / "steady_state"
    for f in ("pressure_profile.csv", "segments.csv", "pressure_breakdown.csv",
              "steady_state_summary.json", "pressure_profile.png"):
        assert (out / f).exists()
    summary = json.loads((out / "steady_state_summary.json").read_text())
    assert "Synthetic" in summary["data_status"]


def test_pid_scenario_end_to_end(tmp_path):
    res = run_named("pid_control", CONFIG, SCENARIOS, tmp_path)["pid_control"]
    assert res.metrics["maintained_within_window"]
    out = tmp_path / "pid_control"
    for f in ("timeseries.csv", "metrics.json", "bhp_vs_time.png", "spp_vs_time.png",
              "ecd_vs_time.png", "pump_rate_vs_bhp.png", "choke_response.png",
              "pid_response.png"):
        assert (out / f).exists()


def test_unknown_scenario():
    with pytest.raises(KeyError):
        run_named("does_not_exist", CONFIG, SCENARIOS, "unused")
