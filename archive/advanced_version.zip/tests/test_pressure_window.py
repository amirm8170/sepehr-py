"""Pressure-window logic."""

import numpy as np
import pytest

from mpd_sim.dynamics.pressure_window import classify_bhp, margin_flags
from mpd_sim.models.operations import PressureWindow


@pytest.fixture
def window():
    return PressureWindow(pore_pressure=300e5, fracture_pressure=400e5, target_bhp=350e5,
                          reference_tvd=3000.0, warning_margin=10e5)


def test_classification(window):
    status = classify_bhp(np.array([290e5, 300e5, 350e5, 400e5, 410e5]), window)
    assert list(status) == ["kick_risk", "safe", "safe", "safe", "loss_risk"]
    assert classify_bhp(250e5, window) == "kick_risk"


def test_margin_flags(window):
    near_pore, near_frac = margin_flags(np.array([305e5, 350e5, 395e5]), window)
    assert list(near_pore) == [True, False, False]
    assert list(near_frac) == [False, False, True]


def test_window_validation():
    with pytest.raises(ValueError):
        PressureWindow(400e5, 300e5, 350e5, 3000.0)
    with pytest.raises(ValueError):
        PressureWindow(300e5, 400e5, 450e5, 3000.0)
    w = PressureWindow(300e5, 400e5, 450e5, 3000.0, allow_target_outside_window=True)
    assert w.width == pytest.approx(100e5)
