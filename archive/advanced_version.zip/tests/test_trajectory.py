"""Trajectory: minimum curvature TVD and validation."""

import numpy as np
import pytest

from mpd_sim.models.trajectory import (Trajectory, minimum_curvature_coordinates,
                                      minimum_curvature_tvd)


def test_vertical_tvd_equals_md():
    tvd = minimum_curvature_tvd(np.array([0, 1000.0]), np.zeros(2), np.zeros(2))
    assert tvd[-1] == pytest.approx(1000.0)


def test_constant_inclination_tangent():
    # Straight hold at 60°: TVD = MD cos 60°
    tvd = minimum_curvature_tvd(np.array([0, 1000.0]), np.array([60.0, 60.0]), np.zeros(2))
    assert tvd[-1] == pytest.approx(500.0)


def test_circular_arc_build():
    # Build 0→90° over a quarter circle of radius R: ΔMD = πR/2, ΔTVD = R
    r = 500.0
    tvd = minimum_curvature_tvd(np.array([0, np.pi * r / 2]), np.array([0.0, 90.0]), np.zeros(2))
    assert tvd[-1] == pytest.approx(r, rel=1e-9)


def test_tvd_greater_than_md_rejected():
    with pytest.raises(ValueError):
        Trajectory.from_stations([0, 100], [0, 0], [0, 0], [0, 120])


def test_non_increasing_md_rejected():
    with pytest.raises(ValueError):
        Trajectory.from_stations([0, 100, 100], [0, 0, 0], [0, 0, 0])


def test_interpolation_and_range():
    traj = Trajectory.from_stations([0, 1000, 2000], [0, 0, 60], [0, 0, 45])
    assert traj.tvd_at(500.0) == pytest.approx(500.0)
    assert traj.inclination_at(1500.0) == pytest.approx(30.0)
    with pytest.raises(ValueError):
        traj.tvd_at(2500.0)


def test_coordinates_quarter_circle_due_east():
    # Build 0→90° toward azimuth 90° over radius R: horizontal departure = R, all East.
    r = 500.0
    north, east = minimum_curvature_coordinates(np.array([0, np.pi * r / 2]),
                                                np.array([0.0, 90.0]), np.array([90.0, 90.0]))
    assert east[-1] == pytest.approx(r, rel=1e-9)
    assert north[-1] == pytest.approx(0.0, abs=1e-9)
