"""Dimensionless numbers and friction factors vs independent references."""

import numpy as np
import pytest
from scipy.integrate import quad

from mpd_sim.hydraulics.friction import (ANNULUS, PIPE, blasius_friction_factor,
                                         colebrook_smooth_fanning,
                                         darby_blended_friction_factor,
                                         darby_turbulent_friction_factor,
                                         laminar_bingham_friction_factor,
                                         laminar_bingham_wall_stress)
from mpd_sim.hydraulics.pressure_loss import BourgoyneBinghamFriction, DarbyBinghamFriction
from mpd_sim.hydraulics.reynolds import (hanks_critical_reynolds, hedstrom_number,
                                         reynolds_number)
from mpd_sim.hydraulics.rheology import BinghamPlastic


def test_reynolds_water():
    assert reynolds_number(1000.0, 1.0, 0.1, 1e-3) == pytest.approx(1.0e5)


def test_hedstrom_hand_value():
    # ρ τy D² / μ² = 1200 × 10 × 0.01 / 4e-4 = 3.0e5
    assert hedstrom_number(1200.0, 10.0, 0.1, 0.02) == pytest.approx(3.0e5)


def test_hanks_newtonian_limit():
    assert hanks_critical_reynolds(0.0)[0] == pytest.approx(2100.0)
    assert hanks_critical_reynolds(1e-3)[0] == pytest.approx(2100.0, rel=1e-3)


def test_hanks_increases_with_hedstrom():
    re_c = hanks_critical_reynolds(np.array([1e3, 1e4, 1e5, 1e6]))
    assert np.all(np.diff(re_c) > 0)
    # Published Hanks curve: Re_c ≈ 3000–3500 at He = 1e4 and ≈ 7000–9000 at He = 1e5
    assert 2800 < re_c[1] < 3600
    assert 6500 < re_c[2] < 9500


def test_newtonian_laminar_is_hagen_poiseuille():
    # τy = 0 → dP/dL = 32 μ v / D² (Hagen–Poiseuille, independent analytic result)
    tau_w = laminar_bingham_wall_stress(0.5, 0.05, 0.01, 0.0, PIPE)
    assert 4 * tau_w / 0.05 == pytest.approx(32 * 0.01 * 0.5 / 0.05 ** 2)
    assert laminar_bingham_friction_factor(1000.0, 0.0, PIPE) == pytest.approx(16 / 1000)


def test_buckingham_reiner_against_velocity_profile_integration():
    # Independent check: integrate the Bingham pipe velocity profile for a given
    # wall stress, compute the mean velocity, then ask the solver for τ_w.
    mu, tau_y, radius, tau_w = 0.02, 8.0, 0.05, 20.0
    r_plug = radius * tau_y / tau_w

    def u(r):  # velocity profile (r >= r_plug), from dP/dL = 2 τ_w / R
        grad = 2 * tau_w / radius
        return (grad / (4 * mu)) * (radius ** 2 - r ** 2) - (tau_y / mu) * (radius - r)

    q = 2 * np.pi * (quad(lambda r: u(r) * r, r_plug, radius)[0]
                     + u(r_plug) * r_plug ** 2 / 2)
    v_mean = q / (np.pi * radius ** 2)
    solved = laminar_bingham_wall_stress(v_mean, 2 * radius, mu, tau_y, PIPE)
    assert solved == pytest.approx(tau_w, rel=1e-6)


def test_slot_solution_against_profile_integration():
    # Bingham flow in a slot of gap h: integrate the velocity profile numerically.
    mu, tau_y, h, tau_w = 0.02, 6.0, 0.04, 15.0
    half = h / 2
    y_plug = half * tau_y / tau_w        # plug half-width measured from centre
    grad = tau_w / half

    def u(y):  # y measured from the centre line, y >= y_plug
        return (grad / (2 * mu)) * (half ** 2 - y ** 2) - (tau_y / mu) * (half - y)

    q_half = quad(u, y_plug, half)[0] + u(y_plug) * y_plug
    v_mean = q_half / half
    # D_h of a slot = 2 h
    solved = laminar_bingham_wall_stress(v_mean, 2 * h, mu, tau_y, ANNULUS)
    assert solved == pytest.approx(tau_w, rel=1e-6)


def test_slot_linearisation_matches_oilfield_formula_at_high_shear():
    # At high shear the exact slot solution approaches 48 μ v/D_h² + 6 τy/D_h
    mu, tau_y, dh, v = 0.02, 5.0, 0.0889, 5.0
    exact = 4 * laminar_bingham_wall_stress(v, dh, mu, tau_y, ANNULUS) / dh
    linear = 48 * mu * v / dh ** 2 + 6 * tau_y / dh
    assert exact == pytest.approx(linear, rel=0.01)
    assert exact <= linear


def test_blasius_against_colebrook_smooth():
    re = np.array([1e4, 3e4, 1e5])
    assert np.allclose(blasius_friction_factor(re), colebrook_smooth_fanning(re), rtol=0.05)


def test_darby_blend_limits():
    f_l, f_t = np.array([0.01]), np.array([0.005])
    assert darby_blended_friction_factor(f_l, f_t, np.array([100.0]))[0] == pytest.approx(0.01, rel=1e-6)
    assert darby_turbulent_friction_factor(1e5, 1e5) < darby_turbulent_friction_factor(1e4, 1e5)


@pytest.mark.parametrize("model", [BourgoyneBinghamFriction(), DarbyBinghamFriction()])
def test_friction_monotonic_in_velocity(model):
    rheo = BinghamPlastic(0.02, 7.0)
    v = np.linspace(0.05, 6.0, 200)
    res = model.evaluate(rheo, 1200.0, v, 0.1, PIPE)
    assert np.all(np.diff(res.pressure_gradient) > 0)


def test_friction_sign_follows_flow():
    rheo = BinghamPlastic(0.02, 7.0)
    res = BourgoyneBinghamFriction().evaluate(rheo, 1200.0, np.array([-1.0, 0.0, 1.0]), 0.1, PIPE)
    assert res.pressure_gradient[0] == pytest.approx(-res.pressure_gradient[2])
    assert res.pressure_gradient[1] == 0.0
    assert list(res.regime) == ["laminar", "static", "laminar"]
