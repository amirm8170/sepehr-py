"""Dynamic models, simulator and control metrics."""

import numpy as np
import pytest

from mpd_sim.dynamics.dynamic_model import FrictionTable, LumpedMPDModel, QuasiSteadyModel
from mpd_sim.dynamics.performance import compute_control_metrics
from mpd_sim.dynamics.pid import PIDController
from mpd_sim.dynamics.schedules import (ConstantSchedule, DynamicInputs,
                                        OperationalSchedule, PiecewiseLinearSchedule)
from mpd_sim.dynamics.simulator import Actuator, DynamicSimulator
from mpd_sim.models.operations import OperatingConditions, PressureWindow

Q = 0.025


@pytest.fixture
def table(solver):
    return FrictionTable(solver, q_max=0.06, n_points=121)


@pytest.fixture
def lumped(solver, choke, table):
    params = LumpedMPDModel.parameters_from(solver, surface_line_volume=1.0)
    return LumpedMPDModel(solver, choke, table, params)


def inputs(q=Q, u=0.3, bpp=0.0):
    return DynamicInputs(pump_rate=q, choke_opening=u, sbp_command=0.0,
                         backpressure_pump_rate=bpp)


def test_lumped_initial_state_matches_steady_solver(solver, lumped):
    out = lumped.initialize(inputs())
    ss = solver.solve(OperatingConditions(pump_rate=Q, back_pressure_mode="choke",
                                          choke_opening=0.3))
    assert out.bhp == pytest.approx(ss.bhp, rel=1e-3)
    assert out.spp == pytest.approx(ss.spp, rel=2e-3)


def test_lumped_constant_inputs_stay_at_equilibrium(lumped):
    out0 = lumped.initialize(inputs())
    for _ in range(50):
        out = lumped.step(inputs(), 0.1)
    assert out.bhp == pytest.approx(out0.bhp, rel=1e-4)


def test_lumped_converges_to_new_steady_state(solver, lumped):
    lumped.initialize(inputs())
    for _ in range(3000):           # 300 s
        out = lumped.step(inputs(u=0.25), 0.1)
    ss = solver.solve(OperatingConditions(pump_rate=Q, back_pressure_mode="choke",
                                          choke_opening=0.25))
    assert out.bhp == pytest.approx(ss.bhp, rel=2e-3)
    assert out.q_choke == pytest.approx(Q, rel=1e-3)      # mass conservation


def test_lumped_has_dynamics_quasi_steady_does_not(solver, choke, table, lumped):
    qs = QuasiSteadyModel(solver, choke, table)
    qs.initialize(inputs())
    lumped.initialize(inputs())
    b_qs = qs.step(inputs(u=0.2), 0.1).bhp
    b_lm = lumped.step(inputs(u=0.2), 0.1).bhp
    b0 = qs.step(inputs(), 0.1).bhp
    assert b_qs > b0
    assert b0 < b_lm < b_qs          # compressibility delays the pressure build-up


def test_back_pressure_pump_holds_sbp_when_pumps_stop(solver, choke, table):
    qs = QuasiSteadyModel(solver, choke, table)
    qs.initialize(inputs())
    no_bpp = qs.step(inputs(q=0.0, u=0.1), 0.1)
    with_bpp = qs.step(inputs(q=0.0, u=0.1, bpp=0.01), 0.1)
    assert no_bpp.sbp == pytest.approx(0.0, abs=1e-6)
    assert with_bpp.sbp > 1e5


def make_simulator(solver, choke, table, lumped, controller, target, duration=400.0):
    hydro = solver.hydrostatic_at_td()
    window = PressureWindow(pore_pressure=hydro, fracture_pressure=hydro + 80e5,
                            target_bhp=target, reference_tvd=solver.well.td_tvd)
    schedule = OperationalSchedule(
        pump_rate=PiecewiseLinearSchedule([0, 50, 110], [Q, Q, 0.0]),
        choke_opening=ConstantSchedule(0.3), surface_back_pressure=ConstantSchedule(0.0),
        backpressure_pump_rate=PiecewiseLinearSchedule([0, 40, 50], [0, 0, 0.008]),
        pipe_velocity=ConstantSchedule(0.0), target_bhp=ConstantSchedule(target))
    actuator = Actuator(choke.min_opening, choke.max_opening, rate_limit=0.05)
    return DynamicSimulator(lumped, schedule, window, actuator, dt=0.1, duration=duration,
                            controller=controller, settling_tolerance=1e5, event_time=50.0)


def test_closed_loop_pid_rejects_pump_stop(solver, choke, table, lumped):
    lumped.initialize(inputs())
    target = lumped.initialize(inputs()).bhp
    pid = PIDController(kp=0.03, ki=0.008, output_min=choke.min_opening,
                        output_max=choke.max_opening, rate_limit=0.05,
                        reverse_acting=True, error_scale=1e5)
    closed = make_simulator(solver, choke, table, lumped, pid, target).run()
    m = closed.metrics
    assert abs(m["steady_state_error_pa"]) < 0.5e5
    assert m["maintained_within_window"]

    params = LumpedMPDModel.parameters_from(solver, surface_line_volume=1.0)
    open_model = LumpedMPDModel(solver, choke, table, params)
    opened = make_simulator(solver, choke, table, open_model, None, target).run()
    # Without control the friction loss after pump stop is not compensated
    assert opened.metrics["steady_state_error_pa"] > 5e5
    assert {"bhp_pa", "spp_pa", "ecd_conventional_kg_m3", "window_status",
            "choke_opening", "pump_rate_m3_s"} <= set(closed.timeseries.columns)


def test_metrics_on_known_first_order_response():
    t = np.arange(0, 100, 0.1)
    tau = 5.0
    y = 100.0 + 10.0 * (1 - np.exp(-t / tau))
    m = compute_control_metrics(t, y, np.full_like(t, 110.0) * np.where(t >= 0, 1, 1),
                                np.array(["safe"] * len(t)), tolerance=0.2,
                                event_time=0.0, initial_bhp=100.0)
    # Target constant from the start → disturbance-type evaluation
    assert np.isnan(m["rise_time_s"])
    # Settling into ±0.2 of 110: 10 e^{-t/τ} = 0.2 → t = τ ln 50 = 19.56 s
    assert m["settling_time_s"] == pytest.approx(tau * np.log(50), abs=0.15)


def test_metrics_setpoint_step_rise_time():
    t = np.arange(0, 100, 0.1)
    tau = 5.0
    target = np.where(t >= 10, 110.0, 100.0)
    y = np.where(t >= 10, 100.0 + 10 * (1 - np.exp(-(t - 10) / tau)), 100.0)
    m = compute_control_metrics(t, y, target, np.array(["safe"] * len(t)), tolerance=0.2,
                                event_time=10.0)
    # 10–90 % rise time of a first-order lag = τ ln 9
    assert m["rise_time_s"] == pytest.approx(tau * np.log(9), abs=0.15)
    assert m["overshoot_percent"] == pytest.approx(0.0, abs=1e-9)


def test_actuator_limits():
    a = Actuator(0.0, 1.0, rate_limit=0.1, position=0.5)
    assert a.move(1.0, 1.0) == pytest.approx(0.6)
    assert a.move(-5.0, 100.0) == 0.0
