"""Segment pressure losses vs independent oilfield (ADE) field-unit formulas."""

import numpy as np
import pytest

from mpd_sim.hydraulics.pressure_loss import (AnnulusPressureLoss, BourgoyneBinghamFriction,
                                              PipePressureLoss, build_friction_model)
from mpd_sim.hydraulics.rheology import BinghamPlastic, PowerLaw
from mpd_sim.units import (cp_to_pas, ft_to_m, gpm_to_m3s, in_to_m, lbf100ft2_to_pa,
                           pa_to_psi, ppg_to_kgm3)

RHEO = BinghamPlastic(cp_to_pas(20.0), lbf100ft2_to_pa(15.0))
RHO = ppg_to_kgm3(10.0)


def test_turbulent_pipe_matches_ade_field_formula():
    # ADE: dp/dL [psi/ft] = ρ^.75 v^1.75 μp^.25 / (1800 d^1.25), v = q/(2.448 d²)
    q_gpm, d_in, length_ft = 500.0, 4.276, 1000.0
    v_fts = q_gpm / (2.448 * d_in ** 2)
    expected_psi = 10 ** 0.75 * v_fts ** 1.75 * 20 ** 0.25 / (1800 * d_in ** 1.25) * length_ft
    loss = PipePressureLoss(BourgoyneBinghamFriction())
    res, dp = loss.segment_losses(RHEO, RHO, gpm_to_m3s(q_gpm), np.array([in_to_m(d_in)]),
                                  np.array([ft_to_m(length_ft)]))
    assert res.regime[0] == "turbulent"
    assert pa_to_psi(dp[0]) == pytest.approx(expected_psi, rel=0.01)


def test_laminar_annulus_close_to_ade_slot_formula():
    # ADE (linearised slot): μp v/(1000 d²) + τy/(200 d) psi/ft. The model uses the
    # exact slot solution, which is LOWER than the linearised one by the plug
    # correction; at this shear rate the difference must be < 12 % and of that sign.
    q_gpm, d2, d1, length_ft = 350.0, 8.5, 5.0, 1000.0
    v_fts = q_gpm / (2.448 * (d2 ** 2 - d1 ** 2))
    ade = (20 * v_fts / (1000 * (d2 - d1) ** 2) + 15 / (200 * (d2 - d1))) * length_ft
    v_ms = gpm_to_m3s(q_gpm) / AnnulusPressureLoss.flow_area(in_to_m(d2), in_to_m(d1))
    loss = AnnulusPressureLoss(BourgoyneBinghamFriction())
    res, dp = loss.segment_losses(RHEO, RHO, np.array([v_ms]), np.array([in_to_m(d2)]),
                                  np.array([in_to_m(d1)]), np.array([ft_to_m(length_ft)]))
    assert res.regime[0] == "laminar"
    model = pa_to_psi(dp[0])
    assert model < ade
    assert model == pytest.approx(ade, rel=0.12)


def test_segment_loss_scales_with_length():
    loss = PipePressureLoss(BourgoyneBinghamFriction())
    _, dp = loss.segment_losses(RHEO, RHO, 0.03, np.array([0.1, 0.1]), np.array([10.0, 30.0]))
    assert dp[1] == pytest.approx(3 * dp[0])


def test_unsupported_rheology_gives_clear_error():
    loss = PipePressureLoss(BourgoyneBinghamFriction())
    with pytest.raises(NotImplementedError):
        loss.segment_losses(PowerLaw(0.5, 0.6), RHO, 0.03, np.array([0.1]), np.array([10.0]))


def test_models_are_interchangeable_and_agree_roughly():
    d = np.array([0.1086])
    res_b = build_friction_model("bourgoyne").evaluate(RHEO, RHO, np.array([3.4]), d, "pipe")
    res_d = build_friction_model("darby").evaluate(RHEO, RHO, np.array([3.4]), d, "pipe")
    # Two literature correlations for turbulent Bingham flow should agree within ~30 %
    assert res_d.pressure_gradient[0] == pytest.approx(res_b.pressure_gradient[0], rel=0.3)
