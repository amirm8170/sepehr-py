"""Geometry: areas, hydraulic diameter, velocity (hand-computed values)."""

import numpy as np
import pytest

from mpd_sim.hydraulics import geometry as g


def test_pipe_area_hand_value():
    assert g.pipe_area(0.1) == pytest.approx(7.853981634e-3)


def test_annulus_area_hand_value():
    # π/4 (0.2² − 0.1²) = 0.0235619449
    assert g.annulus_area(0.2, 0.1) == pytest.approx(0.0235619449)


def test_annulus_area_equals_difference_of_circles():
    assert g.annulus_area(0.3, 0.12) == pytest.approx(g.pipe_area(0.3) - g.pipe_area(0.12))


def test_hydraulic_diameter_from_4A_over_P():
    dh, dp = 0.2159, 0.127
    area = g.annulus_area(dh, dp)
    wetted = np.pi * (dh + dp)
    assert g.annulus_hydraulic_diameter(dh, dp) == pytest.approx(4 * area / wetted)


def test_velocity():
    # 0.01 m³/s through 0.1 m pipe → 1.2732 m/s
    assert g.mean_velocity(0.01, g.pipe_area(0.1)) == pytest.approx(1.2732395)


def test_field_annular_velocity_formula():
    # Oilfield: v[ft/min] = 24.51 q[gpm] / (d2² − d1²)  → 500 gpm, 8.5×5 in = 259.2 ft/min
    q = 500 * 6.30901964e-5
    v = g.mean_velocity(q, g.annulus_area(8.5 * 0.0254, 5 * 0.0254))
    assert v / 0.3048 * 60 == pytest.approx(24.51 * 500 / (8.5 ** 2 - 5 ** 2), rel=1e-3)


@pytest.mark.parametrize("hole, pipe", [(0.1, 0.1), (0.1, 0.12)])
def test_hole_smaller_than_pipe_rejected(hole, pipe):
    with pytest.raises(ValueError):
        g.annulus_area(hole, pipe)


def test_negative_diameter_rejected():
    with pytest.raises(ValueError):
        g.pipe_area(-0.1)
