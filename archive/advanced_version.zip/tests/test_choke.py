"""Choke model: Cv conversion, characteristics, inverse."""

import pytest

from mpd_sim.dynamics.choke import (CV_US_TO_SI, EqualPercentageCharacteristic,
                                    LinearCharacteristic, SimpleCvChoke,
                                    TabulatedCharacteristic, build_choke)
from mpd_sim.units import gpm_to_m3s, psi_to_pa


def test_cv_definition_water():
    # Cv = 10 passes 10 gpm of water (SG = 1) at 1 psi by definition.
    choke = SimpleCvChoke(LinearCharacteristic(cv_max=10.0), linearization_dp=1.0)
    q = choke.flow_rate(1.0, psi_to_pa(1.0), 1000.0)
    assert q == pytest.approx(gpm_to_m3s(10.0), rel=1e-6)


def test_conversion_constant():
    assert CV_US_TO_SI == pytest.approx(2.4027e-5, rel=1e-3)


def test_flow_and_pressure_are_inverse(choke):
    dp = choke.pressure_drop(0.4, 0.03, 1200.0)
    assert choke.flow_rate(0.4, dp, 1200.0) == pytest.approx(0.03)


def test_pressure_drop_quadratic_in_flow(choke):
    assert choke.pressure_drop(0.5, 0.04, 1200.0) == pytest.approx(
        4 * choke.pressure_drop(0.5, 0.02, 1200.0))


def test_opening_for_inverts(choke):
    u = choke.opening_for(0.03, 2.0e6, 1200.0)
    assert choke.pressure_drop(u, 0.03, 1200.0) == pytest.approx(2.0e6, rel=1e-6)


def test_characteristics():
    assert EqualPercentageCharacteristic(100, 50).cv(0.0) == pytest.approx(2.0)
    tab = TabulatedCharacteristic([0, 0.5, 1], [0, 30, 100])
    assert tab.cv(0.75) == pytest.approx(65.0)
    with pytest.raises(ValueError):
        TabulatedCharacteristic([0, 0.5, 1], [0, 50, 40])


def test_closed_choke_without_leak_rejected():
    choke = build_choke("linear", cv_max=100.0, cv_leak=0.0)
    with pytest.raises(ValueError):
        choke.pressure_drop(0.0, 0.01, 1200.0)


def test_no_reverse_flow(choke):
    assert choke.flow_rate(0.5, -1e5, 1200.0) == 0.0
