# Development of a Well Hydraulics Simulation Model for Managed Pressure Drilling Systems and Dynamic Bottomhole Pressure Control

A research-grade, modular Python simulator for **steady-state well hydraulics**, **dynamic MPD simulation** and **closed-loop bottomhole-pressure (BHP) control**, developed for a graduate thesis at the University of Tehran.

> **DISCLAIMER.** This is a research and educational simulator. It is **not** field-certified drilling-control software and must not be used to make operational decisions on a real well. All bundled data are **synthetic demonstration data**: plausible values, but not from a real well. Nothing in this repository is validated against field or laboratory measurements.

---

## Contents

1. [Model Status and Assumptions](#1-model-status-and-assumptions)
2. [Project objective and thesis context](#2-project-objective-and-thesis-context)
3. [MPD in brief and problem statement](#3-mpd-in-brief-and-problem-statement)
4. [System and software architecture](#4-system-and-software-architecture)
5. [Installation](#5-installation)
6. [Quick start: commands and expected outputs](#6-quick-start-commands-and-expected-outputs)
7. [Input data format](#7-input-data-format)
8. [Mathematical model](#8-mathematical-model)
9. [Dynamic model, choke and PID controller](#9-dynamic-model-choke-and-pid-controller)
10. [Pressure window and control metrics](#10-pressure-window-and-control-metrics)
11. [Validation framework](#11-validation-framework)
12. [Sensitivity analysis](#12-sensitivity-analysis)
13. [Scenarios](#13-scenarios)
14. [Testing](#14-testing)
15. [Extending the simulator](#15-extending-the-simulator)
16. [Limitations, calibration and supervisor discussion points](#16-limitations-calibration-and-supervisor-discussion-points)
17. [References](#17-references)

---

## 1. Model Status and Assumptions

The thesis proposal PDF was **not available** when this code was written. Scope and terminology follow the written project specification, which summarises the proposal. Every item below is classified so that a reader can see what is mandated and what is a choice open to revision.

### A. Specified by the thesis proposal / project specification

| Item | Where in code |
|---|---|
| Bingham Plastic as the initial rheological model, τ = τ_y + μ_p γ̇ | `hydraulics/rheology.py` |
| Segment-based discretisation of the well (MD, TVD, inclination, azimuth per segment) | `models/segment.py` |
| Outputs: flow area, velocity, Re, He, regime, friction factor, segment ΔP, hydrostatic, profile, SPP, BHP, ECD | `hydraulics/hydraulics.py` |
| Time-domain extension: pump rate, pump start/stop, choke, back pressure, pipe movement | `dynamics/` |
| PID BHP controller with limits, rate limits, anti-windup, pressure-window constraints | `dynamics/pid.py`, `dynamics/simulator.py` |
| Pore/fracture/target pressure-window logic and control metrics | `dynamics/pressure_window.py`, `dynamics/performance.py` |
| Python implementation, SI internally | everywhere |

### B. Standard engineering equations (textbook, not open to debate)

A = πD²/4; A_ann = π/4(D_hole² − OD²); D_h = D_hole − OD; v = Q/A; ΔP_h = ρgΔTVD; Re = ρvD/μ_p; He = ρτ_yD²/μ_p²; Fanning definition ΔP/L = 2fρv²/D_h; bit TFA, nozzle velocity, ΔP_bit = ρv_n²/(2C_d²); minimum-curvature TVD; discrete PID law; error metrics.

### C. Correlations selected from the literature (each is a **modeling choice requiring validation**)

| Correlation | Used for | Why selected |
|---|---|---|
| Buckingham–Reiner (exact) | laminar pipe flow, Bingham | exact analytical solution for the proposal's model |
| Bingham narrow-slot solution (exact; its linearisation is the ADE Eq. 4.67) | laminar annular flow | standard oilfield approach (Bourgoyne et al. 1986) |
| Hanks (1963) critical Reynolds number from the Hedstrom number | laminar/turbulent boundary | Hedstrom-based criterion for Bingham fluids, the one ADE uses |
| Blasius-type f = 0.0791 Re^-0.25 on μ_p, annulus D_eff = 0.816 D_h (Bourgoyne et al. 1986) | turbulent flow, **default** model | the standard SPE-textbook Bingham procedure, traceable for a drilling thesis |
| Darby, Mun & Boger (1992) turbulent + blending | turbulent flow, **alternative** model | second opinion, shows how sensitive results are to the correlation choice |
| Burkhardt (1961) clinging-constant swab/surge velocity | pipe movement | simplest literature model for steady swab/surge |
| Kaasa et al. (2012) lumped MPD hydraulics | dynamic model | the standard control-oriented MPD model in the literature |
| Valve equation Q = K(u)√(ΔP/ρ) with a Cv curve | choke | generic incompressible valve relation; the curve must come from the real choke |

### D. Engineering assumptions

* Single-phase, single-density, **incompressible** mud for hydrostatics and friction; isothermal; properties independent of P and T.
* Concentric annulus (no eccentricity), smooth walls, no tool-joint losses, no surface-line losses.
* Gauge pressures; the boundary condition is the annulus pressure at the wellhead = SBP. BHP is referenced at well TD.
* Steady, fully developed flow in each segment (friction is quasi-steady even in the dynamic model).
* Bulk modulus β (default 1.5 GPa) is an effective mud-plus-wellbore value and must be calibrated.
* The controller measures BHP ideally, with a one-sample delay. PWD telemetry delay and noise are not modelled.
* No influx/loss: the formation is impermeable. Kick/loss is only *flagged*, not simulated.

### E. Simplifications

* TVD, inclination and azimuth are linearly interpolated in MD between survey stations. Hydrostatics is exact at the stations.
* Friction is pre-tabulated over flow rate (and pipe velocity) for the dynamic model. Linear interpolation also smooths the Bingham yield-stress jump at Q → 0.
* The choke √ΔP law is linearised below `linearization_dp` (default 0.1 bar) to avoid an infinite slope. Choke reverse flow is blocked.
* Pressures are not allowed below atmospheric/downstream pressure: U-tubing and free-fall level dynamics are not modelled.
* Swab/surge is steady-state: all displaced fluid goes up the annulus, and string-interior friction ignores pipe motion.
* Gel strength is used only to report a break-circulation pressure. It is not used in the dynamics.

### F. Future extensions (architecture ready, not implemented)

* Power-law and Herschel–Bulkley friction models. The constitutive classes exist; friction strategies still need to be added.
* A distributed transient PDE solver (continuity + momentum): an interface plus documentation in `dynamics/transient.py`.
* A physical choke model (trim geometry, cavitation, two-phase flow), behind the `ChokeModel` interface.
* Temperature- and pressure-dependent density and rheology; multiphase flow; influx/loss models; PWD measurement delay; MPC or other controllers.

---

## 2. Project objective and thesis context

**Objective.** Build a transparent, extensible simulator that:

1. **Stage A** computes steady-state circulating hydraulics of a deviated well, segment by segment, giving SPP, BHP, ECD and the full pressure profile. Every pressure contribution is visible.
2. **Stage B** extends this to the time domain for MPD operations (pump changes, connections, choke and back-pressure manipulation, pipe movement) and closes the loop with a PID controller that keeps BHP inside the pore–fracture window.

The architecture lets the work grow from steady-state hydraulics, to dynamic simulation, to closed-loop control **without rewriting the hydraulic core**. The Stage-A solver is reused, unchanged, as the friction "engine" of every dynamic model.

## 3. MPD in brief and problem statement

In conventional drilling the annulus is open to atmosphere, so BHP = hydrostatic + annular friction. BHP then drops by the whole annular friction loss every time the pumps stop (for example at connections). **Managed Pressure Drilling** closes the annulus with a rotating control device and routes returns through an automated **choke**. Adjusting the choke, plus a **back-pressure pump** when the rig pumps are off, applies **surface back pressure (SBP)**:

    BHP = SBP + ρ g TVD + ΔP_annulus friction

MPD keeps BHP almost constant within a narrow window: above pore pressure (no kick) and below fracture pressure (no losses).

**Problem statement.** Predicting BHP during transient operations needs (i) an accurate steady-state friction model, (ii) a dynamic model of how pressure propagates through the compressible mud system and the choke, and (iii) a controller design that respects actuator limits and the pressure window. This project provides all three in one consistent, documented framework.

---

## 4. System and software architecture

### Physical system (circulation path and pressure accounting)

```
 mud pump ──► standpipe (SPP) ──► drill pipe ──► BHA ──► bit nozzles
                                                            │
     separator ◄── MPD choke ◄── wellhead (SBP) ◄── annulus ◄┘   (BHP at TD)
                      ▲
          back-pressure pump (optional)

 SPP = SBP + ΔP_annulus + ΔP_bit + ΔP_BHA + ΔP_drill-pipe
 BHP = SBP + ρ g TVD_TD + ΔP_annulus
```

### Control loop (Stage B)

```
 Target BHP ─►(+)─ error ─► PID ─► command ─► actuator limits ─► choke / SBP ─► well hydraulics ─► BHP
              ▲(−)                                                                                  │
              └───────────────────────────── measured BHP (feedback) ◄──────────────────────────────┘
```

### Software layers

```
config/*.yaml ──► io/loaders.py (units → SI) ──► models/ (well, mud, trajectory, operations, segments)
                                                    │
                                     hydraulics/ (Stage A solver) ◄── rheology / friction / bit strategies
                                                    │  (friction tables)
                                     dynamics/ (Quasi-steady | Lumped MPD model) + choke + PID + window
                                                    │
                       scenarios/runner.py ──► io/exporters.py (CSV/JSON) + visualization/plots.py (PNG)
                                                    │
                          analysis/sensitivity.py   validation/validation.py
```

Design patterns:

* **Strategy** for the interchangeable parts: `RheologyModel`, `FrictionModel`, `ChokeCharacteristic` / `ChokeModel`, `DynamicHydraulicModel`.
* **Dataclasses** with `__post_init__` validation for the physical inputs. Pydantic was not used, to keep the dependency count and the learning curve low.
* Plain functions for equations (each is a few lines and documented with units, source and validity), with classes only where state or interchangeability is needed.

### Folder structure

```
sepehr-py/
├── main.py                         CLI entry point
├── gui.py                          desktop application entry point (python gui.py)
├── gui/                            PySide6 app: app.py, main_window.py, state.py, widgets.py, plots.py, theme.py, pages/
├── README.md  CLAUDE.md  requirements.txt  pytest.ini
├── config/
│   ├── base_case.yaml              synthetic base case (well, mud, ops, window, choke, numerics, PID)
│   ├── scenarios.yaml              11 dynamic scenarios
│   └── validation_demo_case.yaml   vertical well for the hand-calculation comparison
├── data/
│   ├── trajectory_example.csv      J-type survey (synthetic)
│   └── validation/demo_reference_steady_state.csv   synthetic reference (hand calc)
├── mpd_sim/
│   ├── constants.py  units.py  logging_config.py
│   ├── models/        trajectory.py well.py mud.py segment.py operations.py
│   ├── hydraulics/    geometry.py rheology.py reynolds.py friction.py pressure_loss.py
│   │                  bit.py hydrostatics.py hydraulics.py
│   ├── dynamics/      schedules.py choke.py pid.py dynamic_model.py simulator.py
│   │                  pressure_window.py performance.py transient.py
│   ├── validation/    validation.py
│   ├── analysis/      sensitivity.py
│   ├── visualization/ plots.py
│   ├── io/            loaders.py exporters.py
│   └── scenarios/     runner.py
├── examples/          run_steady_state.py run_pid_control.py run_sensitivity.py
│                      run_validation_demo.py build_demo_reference.py
├── tests/             15 test modules (123 tests, incl. headless desktop-GUI tests)
└── outputs/           generated results (git-ignored)
```

---

## 5. Installation

* **Python ≥ 3.9** (developed and tested with 3.9.6)
* Dependencies (`requirements.txt`): numpy, pandas, scipy, matplotlib, PyYAML, pytest; PySide6 for the desktop application

```bash
git clone <repo-url> sepehr-py && cd sepehr-py
python3 -m venv .venv
source .venv/bin/activate            # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

---

## 6. Quick start: commands and expected outputs

```bash
python main.py                          # steady state + all dynamic scenarios
python main.py --scenario base          # steady-state base case only
python main.py --scenario pump_change   # pump-rate increase (alias)
python main.py --scenario pid_control   # closed-loop PID BHP control
python main.py --list                   # list scenarios and aliases
python main.py --scenario base --sensitivity     # + sensitivity analysis
python main.py --scenario base --validate        # + demonstration validation workflow
python main.py --config my_case.yaml --output-dir results/ --no-plots
```

A full run (`python main.py --sensitivity --validate`) takes about 20 s on a laptop.

### Desktop application

```bash
python gui.py                 # opens the desktop window (PySide6 / Qt)
```

A native desktop application (`gui.py`, `gui/`) built with PySide6 (Qt), with matplotlib charts embedded in the window. Every chart has the standard toolbar: zoom, pan and save as PNG. Long simulations run in a background thread with a progress bar, so the window never freezes.

| Page (left navigation, Ctrl+1 … Ctrl+7) | What it does |
|---|---|
| Dashboard | KPI cards (BHP, SPP, SBP, both ECDs, margin to the nearest limit), pressure-window gauge, pressure profile vs MD / TVD, SPP build-up, pressure accounting, segment table, flow-regime map; pump-rate and choke/SBP controls recalculate instantly |
| Dynamic scenarios | pick any scenario from `scenarios.yaml`, edit its schedules in tables, run; BHP/SPP/SBP, ECD, flows and choke, window status, depth profiles over time, metrics, CSV export |
| PID control lab | tune Kp/Ki/Kd, anti-windup and derivative filter, choke or SBP actuation; closed loop vs open loop, metrics comparison, control error, PID terms, per-event metrics |
| Sensitivity | one-at-a-time tornado charts for BHP/SPP/ECD, normalised-sensitivity table, parameter sweeps |
| Validation | bundled hand-calculation demo or your own reference CSV; parity plot, error bars, provenance warning |
| Case setup | geometry and drill-string tables, survey (table, CSV import, vertical-section / plan / 3D / inclination views), drilling fluid (Fann calculator, flow curve), operations, pressure window, choke, PID, numerics; live input check |
| Model & assumptions | the assumption, equation and limitation sections of this README |

Menus: **File** (open / save case YAML, load a bundled case), **View** (oilfield or metric units, page shortcuts) and **Help**.

Note for macOS: recent macOS versions mark files inside a dot-folder such as `.venv` as "hidden", and Qt then reports "Could not find the Qt platform plugin 'cocoa'". `gui/app.py` clears that flag on PySide6's plugin files automatically at start-up.

### Expected outputs

`outputs/steady_state/`

| File | Content |
|---|---|
| `pressure_profile.png` | pressure vs **MD** and vs **TVD** side by side (string, annulus, hydrostatic line, pore/frac at TD) |
| `pressure_breakdown.png` / `.csv` | SPP build-up: drill pipe, BHA, bit, annulus, SBP, total |
| `pressure_profile.csv` | per node: flow path, MD, TVD, pressure, surface/hydrostatic/friction contributions, section, velocity, regime, Re, f |
| `segments.csv` | per segment, both flow paths: full geometry plus hydraulic results |
| `steady_state_summary.json` | headline values (SI) |

`outputs/<scenario>/`: `timeseries.csv`, `metrics.json`, `pressure_profiles_vs_time.csv`, `events.log`, plus `bhp_vs_time.png`, `spp_vs_time.png`, `ecd_vs_time.png`, `pump_rate_vs_bhp.png`, `choke_response.png`, `window_status.png`, `pressure_profile_vs_time.png`, and `pid_response.png` for closed-loop runs.

`outputs/sensitivity/`: OAT table, tornado plots for BHP/SPP/ECD, pump-rate and mud-weight sweeps.
`outputs/validation/`: comparison tables, parity plot, dynamic model-to-model comparison.

Every CSV keeps the **SI columns** (`*_pa`, `*_kg_m3`, `*_m3_s`) and **adds** field-unit columns (`*_psi`, `*_bar`, `*_ppg`, `*_gpm`). Units are never mixed within a column.

### Example output (base case, synthetic)

```
[steady_state] BHP 380.36 bar | SPP 172.61 bar | SBP 11.10 bar | ECD(conv) 1279.6 kg/m³ | status safe
       drill_pipe_friction   54.73 bar
              bha_friction   24.27 bar
         bit_pressure_drop   59.04 bar
          annulus_friction   23.48 bar
     surface_back_pressure   11.10 bar
                       spp  172.61 bar
[pid_control] BHP 377.87–385.59 bar, outside window 0.0 s, settling 426.0 s (PID)
```

Closed loop vs open loop for the connection scenario (`python examples/run_pid_control.py`):

| metric | closed loop | open loop |
|---|---|---|
| min BHP | 377.9 bar | 347.1 bar (below pore pressure, 359.6 bar) |
| max undershoot | 4.9 bar | 33.3 bar |
| time outside window | 0 s | 194 s |

---

## 7. Input data format

### Unit convention

**Every numeric configuration key ends with its unit**, and the loader converts to SI exactly once (`io/loaders.py::read_quantity`). Giving the same quantity in two units is an error.

| Quantity | Accepted suffixes |
|---|---|
| length | `_m _ft _in _mm _32nds` |
| pressure | `_pa _kpa _mpa _bar _psi` |
| flow rate | `_m3_s _m3_min _gpm _lpm` |
| density | `_kg_m3 _ppg _sg` |
| viscosity | `_pa_s _cp` |
| yield point / gel | `_pa _lbf_100ft2` |
| velocity | `_m_s _ft_s _ft_min _m_min` |
| time | `_s _min _h` |
| pressure as EMW | `<name>_emw_ppg`, `<name>_emw_kg_m3` |

Exact conversion factors (NIST SP 811): 1 ft = 0.3048 m; 1 in = 0.0254 m; 1 psi = 6894.757 Pa; 1 gpm = 6.309020×10⁻⁵ m³/s; 1 ppg = 119.8264 kg/m³; 1 cP = 10⁻³ Pa·s; 1 lbf/100 ft² = 0.478803 Pa. The oilfield 0.052 psi/(ft·ppg) is a rounding of 0.051948.

### Example input (excerpt of `config/base_case.yaml`)

```yaml
well:
  trajectory: {file: data/trajectory_example.csv}
  hole_sections:
    - {name: casing_9_5_8in, kind: cased, top_md_m: 0, bottom_md_m: 1800, diameter_in: 8.681}
    - {name: open_hole_8_5in, kind: open_hole, top_md_m: 1800, bottom_md_m: 3500, diameter_in: 8.5}
  drill_string:            # surface → bit
    - {name: drill_pipe_5in, category: drill_pipe, length_m: 3300, outer_diameter_in: 5.0, inner_diameter_in: 4.276}
    - {name: bha_6_5in_collars, category: bha, length_m: 200, outer_diameter_in: 6.5, inner_diameter_in: 2.8125}
  bit: {nozzle_diameters_32nds: [13, 13, 13, 13], discharge_coefficient: 0.95}
mud: {density_ppg: 10.0, plastic_viscosity_cp: 20, yield_point_lbf_100ft2: 15, gel_10min_lbf_100ft2: 12}
operations: {pump_rate_gpm: 500, back_pressure_mode: choke, choke_opening_frac: auto}
pressure_window: {pore_pressure_emw_ppg: 10.4, fracture_pressure_emw_ppg: 11.8, target_bhp_emw_ppg: 11.0}
```

`choke_opening_frac: auto` solves the inverse choke curve for the opening that gives the target BHP at the initial flow rate.

### Trajectory CSV

```
md_m,tvd_m,inclination_deg,azimuth_deg      (tvd optional; lines starting with # are comments)
0.00,0.000,0.00,0.00
830.00,829.937,2.50,45.00
...
```

If TVD is given it is used, and cross-checked against minimum curvature (a warning is logged if they differ by more than 1 m). If it is omitted, it is computed by minimum curvature. Inline `stations:` lists are also accepted.

### Scenario schedules

Piecewise-linear `[[time_s, value], ...]` in the unit given by the key:

```yaml
pump_rate_gpm: [[0, 500], [30, 500], [90, 0]]       # ramp down between 30 and 90 s
choke_opening_delta_frac: [[0, 0], [30, 0], [35, 0.15]]  # relative to the initial opening
target_bhp_emw_ppg: [[0, 11.0], [450, 11.0], [451, 11.15]]
```

Keys: `pump_rate_*`, `backpressure_pump_rate_*`, `surface_back_pressure_*`, `pipe_velocity_*`, `choke_opening_frac` or `choke_opening_delta_frac`, `target_bhp_*` / `target_bhp_emw_*`.

---

## 8. Mathematical model

### 8.1 Geometry

| Quantity | Equation |
|---|---|
| Pipe flow area | A = πD_i²/4 |
| Annular flow area | A = π/4 (D_hole² − D_o²) |
| Annular hydraulic diameter | D_h = 4A/P_wet = D_hole − D_o (concentric) |
| Mean velocity | v = Q/A |

The code keeps four distinct diameters: pipe **ID** (string flow), pipe **OD** (annulus inner wall), **hole diameter** (casing ID or open hole) and **hydraulic diameter**. The constructor rejects a hole diameter ≤ OD.

### 8.2 Rheology: Bingham Plastic

τ = τ_y + μ_p γ̇ (γ̇ > 0). From a Fann VG meter (API RP 13B-1): PV = θ600 − θ300 [cP], YP = θ300 − PV [lbf/100 ft²]. Internally μ_p [Pa·s] = PV × 10⁻³ and τ_y [Pa] = YP × 0.4788.

### 8.3 Dimensionless numbers and flow regime

* Re = ρ|v|D_h/μ_p
* He = ρτ_yD_h²/μ_p²
* **Hanks (1963)**: solve x_c/(1−x_c)³ = He/16800, then Re_c = He/(8x_c)·(1 − 4x_c/3 + x_c⁴/3). Re_c = 2100 as He → 0.
* Laminar if Re < Re_c, otherwise turbulent; "static" if v = 0.

### 8.4 Friction (Fanning factor f, τ_w = fρv²/2, dP/dL = 4τ_w/D_h = 2fρv²/D_h)

**Laminar, pipe (Buckingham–Reiner, exact):**
8μ_p v/D = τ_w (1 − 4ξ/3 + ξ⁴/3), with ξ = τ_y/τ_w. Equivalently f = 16/Re[1 + He/(6Re) − He⁴/(3f³Re⁷)].

**Laminar, annulus (Bingham slot, exact):**
12μ_p v/D_h = τ_w (1 − 3ξ/2 + ξ³/2). Its linearisation is the familiar oilfield
dP/dL = 48μ_p v/D_h² + 6τ_y/D_h (ADE Eq. 4.67; field form μ_p v/(1000d²) + τ_y/(200d)).
The exact form is used because it is consistent with the exact pipe solution. It gives *lower* losses than the linearised oilfield formula at low shear: 9 % lower for the validation demo case, see §11.

Both laminar equations are solved for τ_w by a monotone Newton iteration. Their convergence and accuracy are tested against numerically integrated velocity profiles.

**Turbulent, default (`bourgoyne`):** f = 0.0791 Re_eff^-0.25 with Re_eff based on μ_p and D_eff = D (pipe) or 0.816 D_h (annulus). Because Blasius can be lower than the laminar value just above Re_c, f = max(f_L, f_T) in the turbulent regime, so friction never drops discontinuously at the transition (a documented modeling choice).

**Turbulent, alternative (`darby`):** f_T = 10^a Re^-0.193 with a = −1.47[1 + 0.146 exp(−2.9×10⁻⁵ He)], blended as f = (f_L^m + f_T^m)^{1/m}, m = 1.7 + 40000/Re. It was fitted for pipe slurries with He ≈ 10³–10⁷ and is **not** suitable for near-Newtonian fluids.

Segment loss: ΔP_i = (dP/dL)_i L_i, with L_i the **MD** length of the segment. Sign follows the flow direction.

### 8.5 Hydrostatic pressure

ΔP_h = ρ g ΔTVD (SI; g = 9.80665 m/s²). It uses **TVD only**, while friction uses MD path length. A field-unit helper, P = 0.052 × MW × TVD, is provided for reporting.

### 8.6 Bit

TFA = Σπd_n²/4; v_n = Q/TFA; ΔP_bit = ρv_n²/(2C_d²); hydraulic power = ΔP_bit·Q; impact force = ρQv_n. C_d is an input (default 0.95) and must be calibrated.

### 8.7 Pressure convention, SPP, BHP and ECD (exact definitions used)

* Gauge pressure; boundary condition: **annulus pressure at the wellhead, upstream of the choke = SBP**.
* SBP is either *specified*, or computed from the choke: SBP = P₀ + ρ(Q_choke/K(u))², with Q_choke = Q_pump + Q_bpp + v_p·A_disp.
* **BHP reference point = annulus at well TD.** If the bit is off bottom, the mud below the bit is static.

| Quantity | Definition in the software |
|---|---|
| Static BHP | ρ g TVD_TD (pumps off, SBP = 0) |
| Static BHP with SBP | ρ g TVD_TD + SBP |
| Circulating BHP | SBP + ρ g TVD_TD + ΣΔP_annulus |
| SPP | SBP + ΔP_annulus + ΔP_bit + ΔP_BHA + ΔP_drill-pipe (single density: hydrostatic columns cancel in the U-tube) |
| Conventional ECD | ρ + ΔP_annulus/(g TVD_TD); **excludes SBP**, the classic definition (ECD = MW + ΔP_f/(0.052 TVD)) |
| EMW of BHP | BHP/(g TVD_TD); **includes SBP**, the figure often called "ECD" in MPD practice |
| ESD | (ρ g TVD_TD + SBP)/(g TVD_TD) |

Both ECD variants are reported and plotted, because the MPD literature uses both names.

Profiles: annulus P(z) = SBP + ρg·TVD(z) + Σ_{above z} ΔP_ann; string P(z) = SPP + ρg·TVD(z) − Σ_{above z} ΔP_string. The tests check the U-tube consistency at the bit: P_string,bit − ΔP_bit = P_annulus,bit.

### 8.8 Simplified swab/surge

v_eff(z) = [Q_bit + v_p A_disp(z)]/A_ann(z) + K_c v_p, with A_disp = πOD²/4 (closed end) or π(OD²−ID²)/4 (open end) and K_c ≈ 0.45 (Burkhardt 1961). v_p > 0 is downward (surge).

---

## 9. Dynamic model, choke and PID controller

### 9.1 Time-stepping framework (`dynamics/simulator.py`)

At each step dt (default 0.1 s):

1. Read the scheduled inputs.
2. Run the PID if enabled (error → output).
3. Apply actuator limits (range and rate).
4. Advance the hydraulic model.
5. Compute BHP, SPP, ECD and the window status.
6. Store the results, plus full depth profiles every `profile_interval_s`.

### 9.2 Quasi-steady vs dynamic (kept separate on purpose)

| Model | `dynamics.model` | Physics |
|---|---|---|
| `QuasiSteadyModel` | `quasi_steady` | sequence of Stage-A steady states; instantaneous response |
| `LumpedMPDModel` | `lumped` (default) | Kaasa et al. (2012) 3-state ODE with compressibility and inertia |
| `TransientConservationModel` | n/a | **future** distributed PDE solver: interface only, raises `NotImplementedError` |

Lumped model (states p_p = pump pressure, p_c = choke pressure, q_b = bit flow):

```
(V_d/β) dp_p/dt = q_pump − q_b
(V_a/β) dp_c/dt = q_b + q_bpp + v_p A_disp,surf − q_choke(u, p_c)
     M dq_b/dt  = p_p − p_c − ΔP_ds(q_b) − ΔP_bit(q_b) − ΔP_ann(q_b, v_p)
BHP = p_c + ρ g TVD_TD + ΔP_ann(q_b, v_p) + M_a dq_b/dt ,   SPP = p_p
M = ρ(Σ L/A_string + Σ L/A_annulus)
```

The friction terms come from the Stage-A segment solver, tabulated against q_b and v_p (`FrictionTable`). The model is integrated with `scipy.integrate.solve_ivp` (LSODA) inside each control interval, with zero-order hold on the inputs. Tests verify that it starts at, and converges back to, the Stage-A steady state, and that it conserves mass (Q_choke → Q_pump).

For a future full transient formulation the architecture targets:

```
∂(ρA)/∂t + ∂(ρvA)/∂z = 0
∂(ρvA)/∂t + ∂(ρv²A)/∂z + A∂P/∂z + ρgA cos θ + F_friction = 0
```

with ρ(P) from β and F_friction from the same `FrictionModel` strategies (see `dynamics/transient.py`).

### 9.3 Choke model

Q = K(u)√(ΔP/ρ) with K [m²] = Cv × 2.4027×10⁻⁵, where Cv is the industry US flow coefficient (gpm/√psi, SG-based). Characteristics: `linear` (Cv_leak + (Cv_max − Cv_leak)u), `equal_percentage` (Cv_max R^(u−1)) or a user/measured `table`.

**The characteristic is choke-specific and is NOT universally valid.** Replace it with the manufacturer's or a measured curve. Actuation modes:

* `choke`: the PID drives the choke opening. This is reverse acting, since closing the choke raises BHP.
* `back_pressure`: an idealised SBP regulator with a first-order lag τ; the PID drives the SBP set-point (direct acting).

### 9.4 PID controller (`dynamics/pid.py`)

e = BHP_target − BHP. Discrete positional form: output = bias + Kp e + Ki Σe dt + Kd de/dt. Features:

* output saturation (choke min/max opening, SBP min/max)
* actuator rate limit
* anti-windup by clamping (default), back-calculation, or none
* derivative on measurement (no setpoint kick) with a first-order filter
* reverse/direct acting
* error scaling, so gains are "per bar"
* methods `update()`, `reset()`, `set_limits()`, `set_gains()`

Bumpless start: the bias is set to the initial actuator position.

Base-case gains (choke mode) Kp = 0.03 /bar, Ki = 0.008 /(bar·s), Kd = 0 were tuned by trial on scenario 10 of the **synthetic** well. The plant gain dBHP/du ≈ −2·SBP/u is strongly non-linear, so **gains must be re-tuned for any real case** (gain scheduling is a natural thesis extension).

---

## 10. Pressure window and control metrics

At every time step: BHP < P_pore gives `kick_risk`; BHP > P_frac gives `loss_risk`; otherwise `safe`. `near_pore` and `near_fracture` flags are raised within `warning_margin` of a limit. All flags are stored in `timeseries.csv` and transitions go to `events.log`.

Metrics (`dynamics/performance.py`, definitions in the docstring):

| Metric | Meaning |
|---|---|
| steady-state error | mean error over the last 10 % of the run |
| rise time | 10–90 %, only when the target steps |
| settling time | stays within ±tolerance (default 15 psi) |
| overshoot | % of step |
| max overshoot / undershoot | Pa above / below target |
| max and min BHP | |
| time outside window | |
| IAE / ISE | integrated absolute / squared error |

With several `event_time_s` the metrics are also computed per event interval (`event1_*`, `event2_*`, …).

---

## 11. Validation framework

`validation/validation.py` provides absolute, relative and percentage error (Error % = |Model − Ref|/|Ref| × 100), profile comparison (interpolated in depth), time-series comparison (RMSE, MAE, max error, mean/max %), summary tables, and parity and overlay plots.

**Every reference dataset must declare `data_type`:** `field`, `laboratory`, `literature` or `synthetic_demonstration`. Synthetic rows automatically carry the text *"Demonstration only — not experimental validation."*

Bundled demonstration (`python main.py --scenario base --validate`):

* `data/validation/demo_reference_steady_state.csv` comes from independent **hand calculations** with ADE field-unit equations (`examples/build_demo_reference.py`) for `config/validation_demo_case.yaml`. This is a *verification* of the code against textbook formulas. It is not physical validation.

  | quantity | ref | model | error % |
  |---|---|---|---|
  | drill-pipe loss | 373.2 psi | 373.1 psi | 0.03 |
  | bit loss | 1027.5 psi | 1027.4 psi | 0.01 |
  | annulus loss | 281.2 psi | 255.8 psi | 9.0 (exact vs linearised slot equation) |
  | BHP | 5581.2 psi | 5550.6 psi | 0.55 (incl. 0.052 vs 0.051948) |
  | SPP | 1925.6 psi | 1899.9 psi | 1.3 |

* A dynamic **model-to-model** comparison (lumped vs quasi-steady, pump-rate increase). This shows the effect of compressibility and inertia. It is not validation either.

**To validate for real:** put measured SPP/BHP/PWD data into a CSV with the same columns, with `data_type: field` (or `laboratory`/`literature`) and `source`, build the matching case YAML, and run the same workflow.

---

## 12. Sensitivity analysis

`analysis/sensitivity.py` runs a one-at-a-time ±10 % perturbation of pump rate, mud weight, PV, YP, hole diameter, pipe OD, back pressure, choke opening and target BHP. For the target it reports the *required* SBP and choke opening. Outputs are BHP, SPP and conventional ECD, plus normalised sensitivity (ΔY/Y)/(ΔX/X). Sweeps of pump rate and mud weight are also produced. OAT ignores interactions between parameters; a Sobol or Morris analysis is a possible extension.

---

## 13. Scenarios

All scenarios use the synthetic base well (3500 m MD / 2943 m TVD J-well, 10 ppg mud, window 10.4–11.8 ppg EMW, target 11.0 ppg) and the lumped dynamic model.

| # | name (`--scenario`) | what happens |
|---|---|---|
| 1 | `constant_pump_rate` | equilibrium check: BHP stays exactly constant |
| 2 | `pump_rate_increase` (alias `pump_change`) | 500 → 650 gpm, fixed choke: BHP rises (friction + choke ΔP ∝ Q²) |
| 3 | `pump_rate_decrease` | 500 → 350 gpm |
| 4 | `pump_start` | 0 → 500 gpm; starts underbalanced (static BHP < pore) |
| 5 | `pump_stop` | 500 → 0 gpm without a back-pressure pump: friction and SBP are lost, so **kick risk** |
| 6 | `choke_opening` | +15 % opening: BHP falls |
| 7 | `choke_closing` | −10 % opening: BHP rises |
| 8 | `back_pressure_change` | SBP 150 → 300 psi (idealised back-pressure actuator) |
| 9 | `pipe_movement` | surge (0.5 m/s down) then swab (0.5 m/s up) |
| 10 | `pid_control` (alias `pid_control`) | connection: pumps off with a back-pressure pump, pumps on, then +0.15 ppg target step, with PID on the choke |
| 10b | `pid_control_back_pressure` | the same, with PID on an idealised SBP actuator |

Each scenario produces BHP, SPP, ECD, pump-rate, choke/SBP and window-status plots, plus time-series CSV and metrics JSON.

---

## 14. Testing

```bash
pytest                 # 123 tests (incl. headless GUI tests), about 25 s
pytest tests/test_pid.py -v
```

The tests check **independent** expected results, not a copy of the implementation formula:

| Area | Independent reference |
|---|---|
| units | NIST factors; 0.052 rule vs SI ρgh |
| geometry | hand values; 4A/P; oilfield annular-velocity formula (24.51 q/(d₂²−d₁²)) |
| trajectory | vertical, tangent and quarter-circle analytic TVD |
| rheology | Fann dial readings reproduced; HB → Bingham limit |
| friction | Hagen–Poiseuille; numerically integrated Bingham pipe and slot velocity profiles; Colebrook smooth-pipe; published Hanks curve; monotonicity; sign |
| pressure loss | ADE turbulent pipe and laminar annulus field equations |
| bit | ADE Δp, nozzle-velocity and impact-force field equations |
| hydraulics | static BHP = ρgh; SPP = Σ losses; U-tube at bit; SBP adds 1:1; ECD > MW; TVD-vs-MD (deviated well); surge/swab sign |
| choke | Cv definition (10 gpm water at 1 psi); inverse consistency |
| PID | P-only offset 1/(1+K); PI zero offset; saturation; rate limit; anti-windup reduces overshoot; no derivative kick |
| dynamics | lumped model = Stage-A steady state; convergence and mass conservation; quasi-steady vs compressible lag; closed vs open loop on a pump stop |
| metrics | analytic first-order settling (τ ln 50) and rise time (τ ln 9) |
| end-to-end | config → steady state → PID scenario → files |

---

## 15. Extending the simulator

### Add a new rheology model (e.g. Herschel–Bulkley friction)
1. The constitutive class already exists in `hydraulics/rheology.py` (`HerschelBulkley`). For a new model, subclass `RheologyModel`, implement `shear_stress()`, and register it in `RHEOLOGY_REGISTRY`.
2. Add a friction strategy that supports it (next section) and list the rheology in `supported_rheologies`.
3. Set `mud.rheology_model` in the YAML (and extend `build_mud` with the new parameters, e.g. `consistency_index_*`).
The solver, dynamic model and plots need no change. An unsupported combination raises a clear `NotImplementedError`.

### Add a new pressure-loss correlation
```python
class MyFriction(FrictionModel):
    name = "my_corr"
    supported_rheologies = (BinghamPlastic,)
    def _combine(self, f_laminar, density, speed, d_h, re, he, re_c, geometry):
        ...  # return the Fanning factor array
FRICTION_MODELS["my_corr"] = MyFriction
```
Then set `numerics.friction_model: my_corr`. Override `evaluate()` instead if the laminar part differs, for example for a non-Bingham fluid. Document the name, equation, regime, assumptions, units, limitations and source in the docstring, following the existing ones.

### Add a new controller
Implement an object with `update(setpoint, measurement, dt) -> float`, `reset(bias)` and `terms`, mirroring `PIDController`. Build it in `scenarios/runner.py::build_controller`. The simulator only calls `update`, `reset` and `terms`, so gain-scheduled PID, MPC or similar controllers plug in directly.

### Add a choke characteristic or physical choke
Subclass `ChokeCharacteristic` (Cv(u)) or `ChokeModel` (`flow_rate`, `pressure_drop`), and add it to `build_choke`.

### Add a dynamic model
Subclass `DynamicHydraulicModel` (`initialize`, `step`), and register it in `build_dynamic_model`.

---

## 16. Limitations, calibration and supervisor discussion points

### Known limitations
* Bingham Plastic tends to over-predict low-shear stresses, so annular losses may be overestimated. Herschel–Bulkley is not yet wired.
* Single-phase, isothermal, incompressible friction. No temperature/pressure effects on ρ or rheology.
* Concentric annulus; no eccentricity, pipe rotation, cuttings or tool-joint effects.
* Lumped dynamics: no pressure-wave propagation (the wave transit time over 3.5 km is about 3 s). No U-tubing or free-fall.
* Swab/surge is steady and simplified, with no inertia or elasticity.
* The choke curve is generic; PWD delay and noise are not modelled; there is no kick/loss flow model.
* PID gains are tuned on synthetic data only.

### Parameters to calibrate with real or reference data
1. PV/YP (or full Fann curve), gel strengths. Ideally fit HB as well.
2. Friction correlation choice (Bourgoyne vs Darby vs future HB) against measured SPP/PWD over a range of flow rates.
3. Bit nozzle discharge coefficient C_d, from SPP minus string and annulus losses.
4. Choke Cv(u) curve (manufacturer or step tests) and leakage.
5. Effective bulk modulus β and surface-line volume, from pump start/stop SPP transients.
6. Clinging constant K_c, from tripping PWD data.
7. PID gains, actuator rate limits, back-pressure actuator time constant.
8. Pore/fracture pressure profile, and the warning margin.

### Discuss with the thesis supervisor before treating as final
* The **friction correlation** for each regime, and whether annulus losses should use the exact slot or the linearised ADE equation (a 9 % difference in the demo case).
* The **flow-regime criterion** (Hanks vs apparent-viscosity Re = 2100), and how the transition zone is handled (max(f_L, f_T)).
* The **BHP reference depth** (TD vs bit) and which "ECD" definition the thesis will report (conventional vs EMW including SBP).
* Whether the **lumped Kaasa-type model** is sufficient for the dynamic part, or a distributed transient model is required.
* The **choke model** form and which choke data are available.
* The **swab/surge model** (Burkhardt steady vs a dynamic surge model).
* **PID design**: tuning method, gain scheduling, and the use of a back-pressure pump during connections.
* Source of **validation data** (field PWD, literature cases, flow loop).

---

## 17. References

* Bourgoyne, A.T., Millheim, K.K., Chenevert, M.E., Young, F.S. (1986). *Applied Drilling Engineering*. SPE Textbook Series Vol. 2. Ch. 4 (Bingham hydraulics, bit hydraulics, swab/surge), Ch. 8 (directional surveying).
* Buckingham, E. (1921). On plastic flow through capillary tubes. *Proc. ASTM* 21, 1154–1156.
* Hedström, B.O.A. (1952). Flow of plastic materials in pipes. *Ind. Eng. Chem.* 44(3), 651–656.
* Hanks, R.W. (1963). The laminar–turbulent transition for fluids with a yield stress. *AIChE J.* 9(3), 306–309.
* Blasius, H. (1913). Das Ähnlichkeitsgesetz bei Reibungsvorgängen in Flüssigkeiten. *VDI Forschungsheft* 131.
* Colebrook, C.F. (1939). Turbulent flow in pipes… *J. Inst. Civil Eng.* 11, 133–156.
* Darby, R., Mun, R., Boger, D.V. (1992). Predict friction loss in slurry pipes. *Chem. Eng.* 99(9), 116–119.
* Burkhardt, J.A. (1961). Wellbore pressure surges produced by pipe movement. *JPT* 13(6), SPE-1546-G.
* Kaasa, G.-O., Stamnes, Ø.N., Aamo, O.M., Imsland, L.S. (2012). Simplified hydraulics model used for intelligent estimation of downhole pressure for a managed-pressure-drilling control system. *SPE Drill. & Compl.* 27(1), SPE-143097-PA.
* Godhavn, J.-M. (2010). Control requirements for automatic managed pressure drilling system. *SPE Drill. & Compl.* 25(3), SPE-119442-PA.
* API RP 13B-1 (field testing of water-based drilling fluids); API RP 13D (rheology and hydraulics of oil-well drilling fluids).
* Åström, K.J., Hägglund, T. (2006). *Advanced PID Control*. ISA (anti-windup, derivative filtering).
* Taylor, B.N., Thompson, A. (2008). NIST SP 811, *Guide for the Use of the International System of Units*.
